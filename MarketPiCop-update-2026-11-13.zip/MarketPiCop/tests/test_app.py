"""Integration tests: the real app (HTTP server + scheduler + bot polling) against a fake Telegram server.

Run:  python3 -m unittest discover -s tests -v
"""
import hashlib
import hmac
import struct
import http.cookiejar
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
import zlib
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from tests.fake_telegram import BOT_ID, FakeTelegram
from tests.fake_yookassa import FakeYooKassa

FAKE = FakeTelegram()
TG_URL = FAKE.start()
FAKE_YK = FakeYooKassa()
YK_URL = FAKE_YK.start()


def _free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


PORT = _free_port()
TMP = tempfile.mkdtemp(prefix="mp_test_")
os.environ.update({
    "MP_NO_DOTENV": "1", "DB_PATH": os.path.join(TMP, "test.db"), "PORT": str(PORT), "HOST": "127.0.0.1",
    "BOT_TOKEN": "1:TESTTOKEN", "TG_API_BASE": TG_URL, "DEMO_MODE": "1", "SNAPSHOT_INTERVAL_MIN": "360",
    "PUBLIC_URL": "https://mp.example.test",
    "YOOKASSA_SHOP_ID": "test-shop", "YOOKASSA_SECRET_KEY": "test-secret",
    "YOOKASSA_API_URL": YK_URL, "YOOKASSA_MARKETPLACE_ENABLED": "1",
    "COMMUNITY_PAYMENTS_ENABLED": "1", "PLATFORM_COMMISSION_BPS": "150",
})

from marketpilot import api, bot, db, marketplace, scheduler, security, server, telegram  # noqa: E402,F401
from marketpilot.config import cfg  # noqa: E402

BASE = f"http://127.0.0.1:{PORT}"
_threads = {}
_stop = {}


def start_scheduler():
    _stop["sched"] = threading.Event()
    _threads["sched"] = threading.Thread(target=scheduler.run_forever, args=(_stop["sched"],), daemon=True)
    _threads["sched"].start()


def stop_scheduler():
    _stop["sched"].set()
    _threads["sched"].join(5)


def setUpModule():
    db.init()
    _stop["bot"] = threading.Event()
    _threads["bot"] = threading.Thread(target=bot.poll_forever, args=(_stop["bot"],), daemon=True)
    _threads["bot"].start()
    start_scheduler()
    srv = server.make_server()
    _threads["http"] = server.serve_in_thread(srv)
    _stop["srv"] = srv
    wait_for(lambda: telegram.state["connected"], 10, "bot did not connect to the fake Telegram")


def tearDownModule():
    _stop["bot"].set()
    _stop["sched"].set()
    _stop["srv"].shutdown()
    FAKE.stop()
    FAKE_YK.stop()


def wait_for(cond, timeout=10, msg="timeout"):
    end = time.time() + timeout
    while time.time() < end:
        v = cond()
        if v:
            return v
        time.sleep(0.1)
    raise AssertionError(msg)


class Client:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def call(self, method, path, body=None, headers=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(BASE + "/api/v1" + path, data=data, method=method,
                                     headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with self.opener.open(req, timeout=15) as r:
                return r.status, json.loads(r.read() or b"{}")
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def get(self, p): return self.call("GET", p)
    def post(self, p, b=None): return self.call("POST", p, b if b is not None else {})
    def upload(self, path, data, filename="image.png", mime="image/png"):
        req = urllib.request.Request(BASE + "/api/v1" + path, data=data, method="POST",
                                     headers={"Content-Type": mime, "X-File-Name": urllib.parse.quote(filename)})
        try:
            with self.opener.open(req, timeout=15) as response:
                return response.status, json.loads(response.read() or b"{}")
        except urllib.error.HTTPError as error:
            return error.code, json.loads(error.read() or b"{}")
    def put(self, p, b): return self.call("PUT", p, b)
    def delete(self, p): return self.call("DELETE", p)


def tiny_png() -> bytes:
    def chunk(kind, payload):
        value = kind + payload
        return struct.pack(">I", len(payload)) + value + struct.pack(">I", zlib.crc32(value) & 0xFFFFFFFF)

    header = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00")) + chunk(b"IEND", b"")


_uid_counter = [5000]


def new_tg_user():
    _uid_counter[0] += 1
    return {"id": _uid_counter[0], "first_name": f"User{_uid_counter[0]}", "language_code": "ru"}


def login_via_bot(client, tg_user):
    st, r = client.post("/auth/web/start")
    assert st == 200, r
    token = r["token"]
    FAKE.push(message={"message_id": 1, "from": tg_user, "chat": {"id": tg_user["id"], "type": "private"},
                       "text": f"/start login_{token}"})

    def confirmed():
        s, p = client.post("/auth/web/poll", {"token": token})
        return p if p.get("status") == "confirmed" else None

    return wait_for(confirmed, 10, "web login was not confirmed")


_chat = [-1001000]


def connect_channel(client, tg_user, title="Test channel", ctype="channel"):
    _chat[0] -= 1
    chat = {"id": _chat[0], "type": ctype, "title": title}
    st, r = client.post("/resources/link-code")
    assert st == 200 and r["live"], r
    msg_key = "channel_post" if ctype == "channel" else "message"
    payload = {"message_id": 2, "chat": chat, "text": f"/connect {r['code']}"}
    if ctype != "channel":
        payload["from"] = tg_user
        FAKE.set_member(chat["id"], tg_user["id"], {"status": "creator"})
    FAKE.push(**{msg_key: payload})
    res = wait_for(lambda: next((x for x in client.get("/resources")[1]["items"] if x["title"] == title and not x["is_demo"]), None), 10, "resource was not linked")
    # the bot also answers in the chat via sendMessage; wait for it so it cannot consume a scripted failure meant for a test
    wait_for(lambda: any(m["chat_id"] == chat["id"] for m in list(FAKE.sent)), 10, "bot confirmation was not sent")
    return chat, res


def target_of(client, post_id):
    return client.get(f"/posts/{post_id}")[1]["targets"][0]


def make_user_with_channel(title="Test channel", ctype="channel"):
    c, u = Client(), new_tg_user()
    login_via_bot(c, u)
    chat, res = connect_channel(c, u, title, ctype)
    return c, u, chat, res


# =============================================================================================
class AuthTests(unittest.TestCase):
    def test_status_reports_connected_bot(self):
        st, r = Client().get("/status")
        self.assertEqual(st, 200)
        self.assertTrue(r["telegram"]["connected"])
        self.assertEqual(r["telegram"]["username"], "FakePilotBot")

    def test_protected_routes_require_auth(self):
        c = Client()
        for method, pattern, fn, public in server.ROUTES:
            if public:
                continue
            path = re.sub(r"\(\?P<[^>]+>\\d\+\)", "1", pattern.pattern.strip("^$"))
            st, _ = c.call(method, path[len("/api/v1"):], {} if method in ("POST", "PUT") else None)
            self.assertEqual(st, 401, f"{method} {path} must require auth")

    def test_web_login_via_bot_and_session(self):
        c, u = Client(), new_tg_user()
        r = login_via_bot(c, u)
        self.assertEqual(r["user"]["first_name"], u["first_name"])
        st, me = c.get("/me")
        self.assertEqual(st, 200)
        self.assertFalse(me["is_demo"])
        # the one-time token cannot be reused
        st, r2 = Client().post("/auth/web/poll", {"token": "garbage"})
        self.assertEqual(r2["status"], "expired")

    def test_login_token_is_one_time(self):
        c, u = Client(), new_tg_user()
        st, r = c.post("/auth/web/start")
        FAKE.push(message={"message_id": 1, "from": u, "chat": {"id": u["id"], "type": "private"}, "text": f"/start login_{r['token']}"})
        wait_for(lambda: c.post("/auth/web/poll", {"token": r["token"]})[1]["status"] == "confirmed", 10)
        self.assertEqual(Client().post("/auth/web/poll", {"token": r["token"]})[1]["status"], "expired")

    def _init_data(self, user, age=0, token="1:TESTTOKEN", tamper=False):
        f = {"user": json.dumps(user, separators=(",", ":")), "auth_date": str(int(time.time()) - age), "query_id": "AAH"}
        dcs = "\n".join(f"{k}={v}" for k, v in sorted(f.items()))
        secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
        f["hash"] = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
        if tamper:
            f["user"] = f["user"].replace(str(user["id"]), "1")
        return urllib.parse.urlencode(f)

    def test_miniapp_init_data(self):
        u = new_tg_user()
        st, r = Client().post("/auth/miniapp", {"init_data": self._init_data(u)})
        self.assertEqual(st, 200, r)
        for bad in (self._init_data(u, tamper=True), self._init_data(u, age=10 * 86400), self._init_data(u, token="9:OTHER"), "garbage"):
            st, r = Client().post("/auth/miniapp", {"init_data": bad})
            self.assertEqual(st, 401, r)

    def test_cross_origin_post_rejected(self):
        st, r = Client().call("POST", "/auth/demo", {}, headers={"Origin": "https://evil.example"})
        self.assertEqual(st, 403)


class ResourceAndPublishingTests(unittest.TestCase):
    def test_group_migration_updates_the_connected_resource_to_supergroup(self):
        client, _, chat, resource = make_user_with_channel("Convertible group", "group")
        new_chat = {"id": -1007000001, "type": "supergroup", "title": "Convertible group"}
        FAKE.push(message={"message_id": 88, "chat": new_chat, "migrate_from_chat_id": chat["id"]})
        migrated = wait_for(
            lambda: next((item for item in client.get("/resources")[1]["items"] if item["id"] == resource["id"]), None)
            if any(row["chat_id"] == new_chat["id"] for row in db.q("SELECT chat_id FROM resources WHERE id=?", resource["id"]))
            else None,
            10, "connected resource did not follow Telegram group migration",
        )
        self.assertEqual(migrated["type"], "supergroup")

    def test_check_syncs_stale_group_type_from_telegram(self):
        client, _, chat, resource = make_user_with_channel("Stale group type", "supergroup")
        db.run("UPDATE resources SET type='group' WHERE id=?", resource["id"])
        FAKE.set_chat_type(chat["id"], "supergroup")
        status, refreshed = client.post(f"/resources/{resource['id']}/check")
        self.assertEqual(status, 200)
        self.assertEqual(refreshed["type"], "supergroup")

    def test_scheduler_syncs_public_username_without_type_change(self):
        _, _, chat, resource = make_user_with_channel("Group privacy refresh", "supergroup")
        db.run("UPDATE resources SET username='stale_public_name' WHERE id=?", resource["id"])
        FAKE.chats[chat["id"]]["username"] = None
        scheduler.refresh_resource(db.one("SELECT * FROM resources WHERE id=?", resource["id"]))
        self.assertIsNone(db.one("SELECT username FROM resources WHERE id=?", resource["id"])["username"])

    def test_connect_channel_checks_rights(self):
        c, u, chat, res = make_user_with_channel("Rights channel")
        self.assertEqual(res["status"], "active")
        self.assertIn("publish", res["capabilities"])
        self.assertEqual(res["members"], FAKE.member_count)

    def test_connect_without_post_right_gives_missing_rights(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        _chat[0] -= 1
        chat = {"id": _chat[0], "type": "channel", "title": "No-post channel"}
        FAKE.set_member(chat["id"], BOT_ID, {"status": "administrator", "can_post_messages": False})
        code = c.post("/resources/link-code")[1]["code"]
        FAKE.push(channel_post={"message_id": 2, "chat": chat, "text": f"/connect {code}"})
        res = wait_for(lambda: next((x for x in c.get("/resources")[1]["items"] if x["title"] == "No-post channel"), None), 10)
        wait_for(lambda: any(m["chat_id"] == chat["id"] for m in list(FAKE.sent)), 10)
        self.assertEqual(res["status"], "missing_rights")
        self.assertIn("can_post_messages", res["missing_rights"])
        st, r = c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 422)
        self.assertEqual(r["error"], "no_rights")
        st, r = c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual(st, 201)  # drafts are allowed

    def test_publish_now_reaches_telegram_once(self):
        c, u, chat, res = make_user_with_channel("Publish channel")
        text = f"hello {time.time()}"
        st, p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 201, p)
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "published" and x, 10, "not published")
        self.assertIsNotNone(t["message_id"])
        time.sleep(2.5)  # give the scheduler time to (wrongly) send again
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_scheduled_post_waits_for_its_time(self):
        c, u, chat, res = make_user_with_channel("Scheduled channel")
        when = (datetime.now(timezone.utc) + timedelta(seconds=3)).isoformat()
        text = f"later {time.time()}"
        st, p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})
        self.assertEqual(st, 201, p)
        time.sleep(1)
        self.assertEqual(target_of(c, p["id"])["status"], "scheduled")
        self.assertNotIn(text, FAKE.sent_texts())
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10, "did not publish at the scheduled time")

    def test_cancel_scheduled(self):
        c, u, chat, res = make_user_with_channel("Cancel channel")
        when = (datetime.now(timezone.utc) + timedelta(seconds=2)).isoformat()
        text = f"cancel me {time.time()}"
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})[1]
        tid = p["targets"][0]["id"]
        self.assertEqual(c.post(f"/post-targets/{tid}/cancel")[0], 200)
        time.sleep(3.5)
        self.assertEqual(target_of(c, p["id"])["status"], "cancelled")
        self.assertNotIn(text, FAKE.sent_texts())

    def test_rate_limit_429_is_retried_without_duplicates(self):
        c, u, chat, res = make_user_with_channel("429 channel")
        text = f"429 {time.time()}"
        FAKE.script_send(("error", 429, "Too Many Requests: retry after 1", {"retry_after": 1}))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 15, "429 was not retried")
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_permanent_error_fails_then_manual_retry_works(self):
        c, u, chat, res = make_user_with_channel("400 channel")
        text = f"400 {time.time()}"
        FAKE.script_send(("error", 400, "Bad Request: can't parse entities", {}))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "failed" and x, 10)
        self.assertIn("can't parse entities", t["error"])
        time.sleep(2)
        self.assertNotIn(text, FAKE.sent_texts())  # no automatic retry for permanent errors
        self.assertEqual(c.post(f"/post-targets/{t['id']}/retry")[0], 200)
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)
        self.assertEqual(FAKE.sent_texts().count(text), 1)

    def test_ambiguous_network_failure_becomes_unknown_never_auto_retried(self):
        c, u, chat, res = make_user_with_channel("Unknown channel")
        text = f"drop {time.time()}"
        FAKE.script_send(("drop",))
        p = c.post("/posts", {"text": text, "resource_ids": [res["id"]], "mode": "now"})[1]
        t = wait_for(lambda: (x := target_of(c, p["id"]))["status"] == "unknown" and x, 10, "connection drop must become 'unknown'")
        time.sleep(2.5)
        self.assertEqual(target_of(c, p["id"])["status"], "unknown")
        self.assertNotIn(text, FAKE.sent_texts())
        self.assertEqual(c.post(f"/post-targets/{t['id']}/retry")[0], 200)  # explicit user decision
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)

    def test_forbidden_403_marks_resource_missing_rights(self):
        c, u, chat, res = make_user_with_channel("403 channel")
        FAKE.script_send(("error", 403, "Forbidden: bot is not a member of the channel chat", {}))
        p = c.post("/posts", {"text": "403", "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, p["id"])["status"] == "failed", 10)
        self.assertEqual(c.get(f"/resources/{res['id']}")[1]["status"], "missing_rights")

    def test_bot_rights_change_and_removal(self):
        c, u, chat, res = make_user_with_channel("Rights change channel")
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "administrator", "can_post_messages": False, "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "missing_rights", 10)
        # restore, schedule a post, then remove the bot: the future post must be cancelled
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "administrator", "can_post_messages": True, "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "active", 10)
        when = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        p = c.post("/posts", {"text": "future", "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})[1]
        FAKE.push(my_chat_member={"chat": chat, "from": u, "old_chat_member": {"status": "administrator"},
                                  "new_chat_member": {"status": "kicked", "user": {"id": BOT_ID}}})
        wait_for(lambda: c.get(f"/resources/{res['id']}")[1]["status"] == "disconnected", 10)
        self.assertEqual(target_of(c, p["id"])["status"], "cancelled")

    def test_group_counters_from_events(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Counter group", "supergroup")
        for _ in range(3):
            FAKE.push(message={"message_id": 9, "from": {"id": 42, "first_name": "m"}, "chat": chat, "text": "private text must not be stored"})
        FAKE.push(chat_member={"chat": chat, "old_chat_member": {"status": "left"}, "new_chat_member": {"status": "member"}})
        FAKE.push(chat_member={"chat": chat, "old_chat_member": {"status": "member"}, "new_chat_member": {"status": "left"}})
        day = db.now().strftime("%Y-%m-%d")

        def stats():
            r = db.one("SELECT * FROM group_stats WHERE resource_id=? AND day=?", res["id"], day)
            return r if r and r["messages"] == 3 and r["joins"] == 1 and r["leaves"] == 1 else None

        wait_for(stats, 10, "group counters are wrong")
        a = c.get("/analytics?days=7")[1]
        self.assertIsNotNone(a["group_activity"])

    def test_validation(self):
        c, u, chat, res = make_user_with_channel("Validation channel")
        ok = {"resource_ids": [res["id"]], "mode": "draft"}
        self.assertEqual(c.post("/posts", {**ok, "text": "x" * 5000})[1]["error"], "too_long")
        self.assertEqual(c.post("/posts", {**ok, "text": "<b>open"})[1]["error"], "bad_format")
        self.assertEqual(c.post("/posts", {**ok, "text": "<script>x</script>"})[1]["error"], "bad_format")
        self.assertEqual(c.post("/posts", {**ok, "text": ""})[0], 422)
        self.assertEqual(c.post("/posts", {"text": "x", "resource_ids": [], "mode": "draft"})[0], 422)
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "mode": "schedule", "scheduled_at": past})[1]["error"], "past")
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "mode": "schedule", "scheduled_at": "2030-01-01T10:00:00"})[0], 422)  # no tz
        self.assertEqual(c.post("/posts", {**ok, "text": "x", "image_url": "javascript:alert(1)"})[0], 422)
        self.assertEqual(c.post("/posts", {**ok, "text": "x" * 1100, "image_url": "https://example.com/a.jpg"})[1]["error"], "too_long")

    def test_edit_duplicate_delete(self):
        c, u, chat, res = make_user_with_channel("Edit channel")
        p = c.post("/posts", {"text": "v1", "resource_ids": [res["id"]], "mode": "draft"})[1]
        st, p2 = c.put(f"/posts/{p['id']}", {"text": "v2", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual((st, p2["text"]), (200, "v2"))
        st, dup = c.post(f"/posts/{p['id']}/duplicate")
        self.assertEqual(st, 201)
        self.assertEqual(dup["targets"][0]["status"], "draft")
        self.assertEqual(c.delete(f"/posts/{dup['id']}")[0], 200)
        # published posts are locked for editing
        pub = c.post("/posts", {"text": f"pub {time.time()}", "resource_ids": [res["id"]], "mode": "now"})[1]
        wait_for(lambda: target_of(c, pub["id"])["status"] == "published", 10)
        st, r = c.put(f"/posts/{pub['id']}", {"text": "edit", "resource_ids": [res["id"]], "mode": "draft"})
        self.assertEqual((st, r["error"]), (409, "locked"))


class MarketplaceTests(unittest.TestCase):
    def test_plan_creation_refreshes_stale_public_username(self):
        owner, _, chat, resource = make_user_with_channel("Stale public group", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        db.run("UPDATE resources SET username='old_public_name' WHERE id=?", resource["id"])
        FAKE.chats[chat["id"]]["username"] = None

        status, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Private access", "amount_minor": 10000, "duration_days": 30,
        })
        self.assertEqual(status, 201, plan)
        self.assertIsNone(db.one("SELECT username FROM resources WHERE id=?", resource["id"])["username"])

    def test_public_group_can_sell_privileges_without_an_invite_admin_right(self):
        owner, _, chat, resource = make_user_with_channel("Public group plan", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        FAKE.chats[chat["id"]]["username"] = "public_group_plan"
        FAKE.set_member(chat["id"], BOT_ID, {
            "status": "administrator", "can_invite_users": False, "can_restrict_members": True,
        })

        status, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Members", "amount_minor": 10000, "duration_days": 30,
            "permissions": {"max_messages_per_day": 17},
        })
        self.assertEqual(status, 201, plan)

        buyer, _ = Client(), new_tg_user()
        login_via_bot(buyer, _)
        catalog = buyer.get("/marketplace/plans")[1]["items"]
        self.assertIn(plan["id"], [item["id"] for item in catalog])
        status, checkout = buyer.post(f"/community-plans/{plan['id']}/checkout")
        self.assertEqual(status, 201, checkout)
        payment = db.one("SELECT provider_payment_id FROM community_payments WHERE id=?",
                         checkout["payment"]["id"])
        FAKE_YK.set_payment_status(payment["provider_payment_id"], "succeeded")
        self.assertEqual(Client().post("/webhooks/yookassa", {
            "event": "payment.succeeded", "object": {"id": payment["provider_payment_id"]},
        })[0], 200)
        marketplace.process_access_jobs()
        subscription_id = checkout["payment"]["subscription_id"]
        wait_for(lambda: db.one("SELECT status FROM community_access_jobs WHERE subscription_id=? AND action='invite'",
                                subscription_id)["status"] == "done", 10, "public group link was not sent")
        self.assertFalse(any(method == "createChatInviteLink" and payload.get("chat_id") == chat["id"]
                             for method, payload in FAKE.calls))
        self.assertTrue(any(method == "sendMessage" and payload.get("chat_id") == buyer.get("/me")[1]["telegram_id"]
                            and "https://t.me/public_group_plan" in payload.get("text", "")
                            for method, payload in FAKE.calls))

    def test_public_group_expiry_resets_paid_rights_without_removing_member(self):
        owner, owner_tg, chat, resource = make_user_with_channel("Public expiry", "supergroup")
        FAKE.chats[chat["id"]]["username"] = "public_expiry"
        group_defaults = {key: key != "can_send_photos" for key in marketplace.telegram.CHAT_PERMISSION_FIELDS}
        FAKE.chats[chat["id"]]["permissions"] = group_defaults
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        status, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Temporary privileges", "amount_minor": 10000, "duration_days": 30,
            "permissions": {"can_send_photos": False},
        })
        self.assertEqual(status, 201, plan)
        buyer, buyer_tg = Client(), new_tg_user()
        login_via_bot(buyer, buyer_tg)
        owner_id = db.one("SELECT id FROM users WHERE telegram_id=?", owner_tg["id"])["id"]
        buyer_id = db.one("SELECT id FROM users WHERE telegram_id=?", buyer_tg["id"])["id"]
        workspace_id = db.one("SELECT workspace_id FROM resources WHERE id=?", resource["id"])["workspace_id"]
        subscription_id = db.insert(
            "community_subscriptions", workspace_id=workspace_id, resource_id=resource["id"], plan_id=plan["id"],
            buyer_user_id=buyer_id, owner_user_id=owner_id, status="expired",
            starts_at=db.now_iso(), ends_at=db.now_iso(), created_at=db.now_iso(), updated_at=db.now_iso(),
        )
        db.insert("community_access_jobs", workspace_id=workspace_id, subscription_id=subscription_id,
                  action="revoke", status="pending", created_at=db.now_iso(), updated_at=db.now_iso())
        FAKE.set_member(chat["id"], buyer_tg["id"], {"status": "restricted"})
        before = len(FAKE.calls)

        marketplace.process_access_jobs()
        self.assertEqual(db.one("SELECT status FROM community_access_jobs WHERE subscription_id=? AND action='revoke'",
                                subscription_id)["status"], "done")
        calls = FAKE.calls[before:]
        reset = next(payload for method, payload in calls
                     if method == "restrictChatMember" and payload.get("user_id") == buyer_tg["id"])
        self.assertEqual(reset["permissions"], group_defaults)
        self.assertFalse(any(method in ("banChatMember", "unbanChatMember") and
                             payload.get("user_id") == buyer_tg["id"] for method, payload in calls))

    def test_unknown_checkout_is_reconciled_without_creating_a_second_payment(self):
        owner, _, _, resource = make_user_with_channel("Ambiguous checkout community", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        _, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Monthly", "amount_minor": 10000, "duration_days": 30,
        })
        buyer, _ = Client(), new_tg_user()
        login_via_bot(buyer, _)
        first_call = True
        real_create_payment = marketplace.payments.create_payment

        def create_then_timeout(*args, **kwargs):
            nonlocal first_call
            if first_call:
                first_call = False
                raise marketplace.payments.PaymentProviderError("timeout", ambiguous=True)
            return real_create_payment(*args, **kwargs)

        with patch.object(marketplace.payments, "create_payment", side_effect=create_then_timeout):
            status, checkout = buyer.post(f"/community-plans/{plan['id']}/checkout")
        self.assertEqual(status, 202)
        self.assertEqual(checkout["payment"]["status"], "unknown")
        payment_id = checkout["payment"]["id"]

        status, payment = buyer.get(f"/community-payments/{payment_id}")
        self.assertEqual(status, 200)
        self.assertEqual(payment["status"], "pending")
        self.assertTrue(payment["confirmation_url"].startswith("https://checkout.example.test/"))
        row = db.one("SELECT provider_payment_id FROM community_payments WHERE id=?", payment_id)
        self.assertTrue(row["provider_payment_id"])

    def test_yookassa_checkout_webhook_commission_and_refund(self):
        owner, owner_tg, chat, resource = make_user_with_channel("Paid community", "supergroup")
        st, merchant = owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        self.assertEqual((st, merchant["status"]), (200, "active"))
        db.run("UPDATE community_merchants SET status='pending' WHERE resource_id=?", resource["id"])
        st, merchant = owner.get(f"/communities/{resource['id']}/merchant")
        self.assertEqual((st, merchant["status"]), (200, "active"))
        workspace_id = owner.get("/workspaces")[1]["items"][0]["id"]
        st, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Monthly", "description": "Private access", "amount_minor": 10000,
            "duration_days": 30, "max_members": 25,
            "permissions": {"can_send_messages": True, "can_send_photos": False, "can_invite_users": False,
                            "max_messages_per_day": 17},
        })
        self.assertEqual(st, 201, plan)
        self.assertEqual(plan["currency"], "RUB")
        self.assertEqual(plan["permissions"]["can_send_photos"], False)
        self.assertEqual(plan["permissions"]["can_send_messages"], True)
        self.assertEqual(plan["permissions"]["max_messages_per_day"], 17)
        self.assertEqual(db.one("SELECT workspace_id FROM community_plans WHERE id=?", plan["id"])["workspace_id"], workspace_id)

        buyer, buyer_tg = Client(), new_tg_user()
        login_via_bot(buyer, buyer_tg)
        st, checkout = buyer.post(f"/community-plans/{plan['id']}/checkout", {"auto_renew": True})
        self.assertEqual(st, 201, checkout)
        payment_id = checkout["payment"]["id"]
        payment = db.one("SELECT * FROM community_payments WHERE id=?", payment_id)
        self.assertEqual(payment["commission_minor"], 150)
        self.assertEqual(payment["owner_amount_minor"], 9850)
        self.assertEqual(payment["workspace_id"], workspace_id)
        self.assertTrue(checkout["payment"]["confirmation_url"].startswith("https://checkout.example.test/"))

        FAKE_YK.set_payment_status(payment["provider_payment_id"], "succeeded")
        webhook = {"event": "payment.succeeded", "object": {"id": payment["provider_payment_id"]}}
        self.assertEqual(Client().post("/webhooks/yookassa", webhook)[0], 200)
        self.assertEqual(Client().post("/webhooks/yookassa", webhook)[0], 200)
        active = buyer.get("/community-subscriptions")[1]["items"][0]
        self.assertEqual(active["status"], "active")
        self.assertTrue(active["auto_renew"])
        self.assertEqual(db.one("SELECT COUNT(*) n FROM community_ledger WHERE payment_id=?", payment_id)["n"], 3)
        self.assertEqual(db.one("SELECT COUNT(*) n FROM community_ledger WHERE payment_id=? AND workspace_id=?",
                    payment_id, workspace_id)["n"], 3)
        marketplace.process_access_jobs()
        self.assertEqual(db.one("SELECT status FROM community_access_jobs WHERE subscription_id=? AND action='invite'",
                    active["id"])["status"], "done")

        FAKE.push(chat_member={
            "chat": chat,
            "from": {"id": BOT_ID, "is_bot": True, "first_name": "FakePilotBot"},
            "date": int(time.time()),
            "old_chat_member": {"status": "left", "user": buyer_tg},
            "new_chat_member": {"status": "member", "user": buyer_tg},
        })
        wait_for(lambda: db.one("SELECT id FROM community_permission_jobs WHERE subscription_id=?", active["id"]),
                 10, "member permissions were not queued after joining")
        wait_for(lambda: any(method == "restrictChatMember" and body.get("user_id") == buyer_tg["id"]
                             for method, body in FAKE.calls),
                 10, "member permissions were not applied after joining")
        permission_call = next((body for method, body in reversed(FAKE.calls)
                                if method == "restrictChatMember" and body.get("user_id") == buyer_tg["id"]), None)
        self.assertIsNotNone(permission_call)
        self.assertEqual(db.one("SELECT status FROM community_permission_jobs WHERE subscription_id=?", active["id"])["status"], "done")
        self.assertEqual(permission_call["permissions"], {
            "can_send_messages": True, "can_send_photos": False, "can_invite_users": False,
        })

        st, refund = buyer.post(f"/community-subscriptions/{active['id']}/refunds", {"reason": "Duplicate purchase"})
        self.assertEqual(st, 201)
        self.assertEqual(db.one("SELECT workspace_id FROM community_refunds WHERE id=?", refund["id"])["workspace_id"], workspace_id)
        st, approved = owner.post(f"/community-refunds/{refund['id']}/approve")
        self.assertEqual(st, 200)
        refund_row = db.one("SELECT provider_refund_id FROM community_refunds WHERE id=?", refund["id"])
        FAKE_YK.set_refund_status(refund_row["provider_refund_id"], "succeeded")
        self.assertEqual(Client().post("/webhooks/yookassa", {
            "event": "refund.succeeded", "object": {"id": refund_row["provider_refund_id"]},
        })[0], 200)
        self.assertEqual(db.one("SELECT status FROM community_subscriptions WHERE id=?", active["id"])["status"], "refunded")
        self.assertEqual(db.one("SELECT action FROM community_access_jobs WHERE subscription_id=? AND action='revoke'",
                                active["id"])["action"], "revoke")
        self.assertEqual(db.one("SELECT workspace_id FROM community_access_jobs WHERE subscription_id=? AND action='revoke'",
                    active["id"])["workspace_id"], workspace_id)
        marketplace.process_access_jobs()
        self.assertEqual(db.one("SELECT status FROM community_access_jobs WHERE subscription_id=? AND action='revoke'",
                    active["id"])["status"], "done")

    def test_stars_are_not_accepted_until_supported_payout_exists(self):
        owner, _, _, resource = make_user_with_channel("RUB only community", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        _, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Access", "amount_minor": 10000, "duration_days": 30,
        })
        buyer, _ = Client(), new_tg_user()
        login_via_bot(buyer, _)
        status, response = buyer.post(f"/community-plans/{plan['id']}/checkout", {"payment_method": "telegram_stars"})
        self.assertEqual(status, 422)
        self.assertEqual(response["error"], "payment_method_unavailable")

    def test_checkout_is_rejected_when_community_payments_are_disabled(self):
        owner, _, _, resource = make_user_with_channel("Disabled checkout community", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        _, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Access", "amount_minor": 10000, "duration_days": 30,
        })
        buyer, buyer_tg = Client(), new_tg_user()
        login_via_bot(buyer, buyer_tg)
        previous = cfg.COMMUNITY_PAYMENTS_ENABLED
        payment_calls = sum(method == "POST" and path == "payments" for method, path, _ in FAKE_YK.calls)
        try:
            cfg.COMMUNITY_PAYMENTS_ENABLED = False
            self.assertFalse(buyer.get("/marketplace/plans")[1]["checkout_enabled"])
            status, response = buyer.post(f"/community-plans/{plan['id']}/checkout")
            self.assertEqual(status, 503)
            self.assertEqual(response["error"], "payments_disabled")
            buyer_id = db.one("SELECT id FROM users WHERE telegram_id=?", buyer_tg["id"])["id"]
            owner_id = db.one("SELECT user_id FROM resources WHERE id=?", resource["id"])["user_id"]
            workspace_id = db.one("SELECT workspace_id FROM resources WHERE id=?", resource["id"])["workspace_id"]
            subscription_id = db.insert(
                "community_subscriptions", workspace_id=workspace_id, resource_id=resource["id"],
                plan_id=plan["id"], buyer_user_id=buyer_id, owner_user_id=owner_id,
                status="active", starts_at=db.now_iso(), ends_at=db.iso(db.now() - timedelta(days=1)),
                auto_renew=1, payment_method_id="saved-method",
                created_at=db.now_iso(), updated_at=db.now_iso(),
            )
            self.assertEqual(marketplace.renew_due_subscriptions(), 0)
            self.assertEqual(sum(method == "POST" and path == "payments" for method, path, _ in FAKE_YK.calls),
                             payment_calls)
        finally:
            if "subscription_id" in locals():
                db.run("DELETE FROM community_subscriptions WHERE id=?", subscription_id)
            cfg.COMMUNITY_PAYMENTS_ENABLED = previous

    def test_owner_can_set_default_permissions_on_a_basic_group(self):
        owner, _, chat, resource = make_user_with_channel("Group defaults", "group")
        permissions = {key: key == "can_send_messages" for key in marketplace.telegram.CHAT_PERMISSION_FIELDS}
        status, result = owner.put(f"/communities/{resource['id']}/permissions", {"permissions": permissions})
        self.assertEqual(status, 200, result)
        self.assertEqual(result["permissions"], permissions)
        method, payload = next((method, payload) for method, payload in reversed(FAKE.calls)
                               if method == "setChatPermissions" and payload.get("chat_id") == chat["id"])
        self.assertEqual(payload["permissions"], permissions)
        self.assertTrue(payload["use_independent_chat_permissions"])
        self.assertEqual(owner.get(f"/communities/{resource['id']}/permissions")[1]["permissions"], permissions)

    def test_plan_message_quota_deletes_over_limit_messages_without_global_quota(self):
        owner, _, chat, resource = make_user_with_channel("Tier message quota", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        status, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Limited", "amount_minor": 10000, "duration_days": 30,
            "permissions": {"max_messages_per_day": 2},
        })
        self.assertEqual(status, 201, plan)

        buyer, buyer_tg = Client(), new_tg_user()
        login_via_bot(buyer, buyer_tg)
        buyer_id = db.one("SELECT id FROM users WHERE telegram_id=?", buyer_tg["id"])["id"]
        workspace_id = db.one("SELECT workspace_id FROM resources WHERE id=?", resource["id"])["workspace_id"]
        db.insert("community_subscriptions", workspace_id=workspace_id, resource_id=resource["id"],
                  plan_id=plan["id"], buyer_user_id=buyer_id, owner_user_id=db.one(
                      "SELECT id FROM users WHERE telegram_id=?", owner.get("/me")[1]["telegram_id"])["id"],
                  status="active", starts_at=db.now_iso(), ends_at=db.iso(db.now() + timedelta(days=2)),
                  created_at=db.now_iso(), updated_at=db.now_iso())
        FAKE.set_member(chat["id"], buyer_tg["id"], {"status": "member"})
        before = len(FAKE.calls)
        for message_id in (301, 302, 303):
            bot.handle_message({"message_id": message_id, "from": buyer_tg, "chat": chat, "text": "member message"})
        deleted = [payload["message_id"] for method, payload in FAKE.calls[before:]
                   if method == "deleteMessage"]
        self.assertEqual(deleted, [303])
        self.assertIsNone(db.one("SELECT id FROM message_limits WHERE resource_id=?", resource["id"]))

    def test_opt_in_subscription_renews_from_saved_method(self):
        owner, owner_tg, _, resource = make_user_with_channel("Renewal community", "supergroup")
        owner.put(f"/communities/{resource['id']}/merchant", {"yookassa_account_id": "123456789"})
        _, plan = owner.post(f"/communities/{resource['id']}/plans", {
            "name": "Monthly", "amount_minor": 15000, "duration_days": 30,
        })
        buyer, buyer_tg = Client(), new_tg_user()
        login_via_bot(buyer, buyer_tg)
        _, checkout = buyer.post(f"/community-plans/{plan['id']}/checkout", {"auto_renew": True})
        first = db.one("SELECT * FROM community_payments WHERE id=?", checkout["payment"]["id"])
        FAKE_YK.set_payment_status(first["provider_payment_id"], "succeeded")
        self.assertEqual(Client().post("/webhooks/yookassa", {
            "event": "payment.succeeded", "object": {"id": first["provider_payment_id"]},
        })[0], 200)
        subscription = db.one("SELECT * FROM community_subscriptions WHERE id=?", first["subscription_id"])
        self.assertTrue(subscription["payment_method_id"])
        db.run("UPDATE community_subscriptions SET ends_at=? WHERE id=?",
               db.iso(db.now() - __import__("datetime").timedelta(seconds=1)), subscription["id"])

        self.assertEqual(marketplace.renew_due_subscriptions(), 1)
        renewal = db.one("SELECT * FROM community_payments WHERE subscription_id=? AND is_recurring=1", subscription["id"])
        self.assertEqual(renewal["status"], "pending")
        request = next(body for method, path, body in reversed(FAKE_YK.calls) if method == "POST" and path == "payments")
        self.assertEqual(request["payment_method_id"], subscription["payment_method_id"])
        self.assertNotIn("confirmation", request)
        FAKE_YK.set_payment_status(renewal["provider_payment_id"], "succeeded")
        self.assertEqual(Client().post("/webhooks/yookassa", {
            "event": "payment.succeeded", "object": {"id": renewal["provider_payment_id"]},
        })[0], 200)
        renewed = db.one("SELECT * FROM community_subscriptions WHERE id=?", subscription["id"])
        self.assertEqual(renewed["status"], "active")
        self.assertTrue(renewed["auto_renew"])
        self.assertGreater(db.parse_iso(renewed["ends_at"]), db.now() + __import__("datetime").timedelta(days=28))


class WorkspaceTests(unittest.TestCase):
    def test_workspace_migration_attaches_user_data(self):
        for table in db.WORKSPACE_USER_TABLES + db.WORKSPACE_RESOURCE_TABLES:
            columns = {row["name"] for row in db.conn().execute(f"PRAGMA table_info({table})")}
            self.assertIn("workspace_id", columns, table)
        owner_id = db.insert("users", first_name="Workspace migration test", created_at=db.now_iso())
        workspace_id = db.ensure_workspace(owner_id)
        member = db.one("SELECT role FROM workspace_members WHERE workspace_id=? AND user_id=?",
                        workspace_id, owner_id)
        self.assertEqual(member["role"], "owner")

    def test_legacy_database_migration_preserves_existing_rows(self):
        path = os.path.join(TMP, "legacy_workspace_migration.db")
        script = """
from marketpilot import db
schema = db.SCHEMA
start = schema.index('CREATE TABLE IF NOT EXISTS workspaces(')
end = schema.index('CREATE TABLE IF NOT EXISTS sessions(', start)
db.conn().executescript(schema[:start] + schema[end:])
user_id = db.insert('users', first_name='Legacy owner', created_at=db.now_iso())
resource_id = db.insert('resources', user_id=user_id, chat_id=-9001, title='Legacy channel', type='channel', connected_at=db.now_iso())
post_id = db.insert('posts', user_id=user_id, text='keep me', created_at=db.now_iso(), updated_at=db.now_iso())
db.init()
workspace_id = db.one('SELECT id FROM workspaces WHERE owner_user_id=?', user_id)['id']
assert db.one('SELECT workspace_id FROM resources WHERE id=?', resource_id)['workspace_id'] == workspace_id
assert db.one('SELECT workspace_id FROM posts WHERE id=?', post_id)['workspace_id'] == workspace_id
assert db.one('SELECT role FROM workspace_members WHERE user_id=?', user_id)['role'] == 'owner'
db.init()
assert db.one('SELECT COUNT(*) AS n FROM workspaces WHERE owner_user_id=?', user_id)['n'] == 1
print('legacy rows preserved and workspace backfill is idempotent')
"""
        env = {**os.environ, "DB_PATH": path, "MP_NO_DOTENV": "1"}
        result = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True, env=env)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("legacy rows preserved", result.stdout)

    def test_invitation_shares_data_and_enforces_member_role(self):
        owner, owner_tg, _, resource = make_user_with_channel("Shared workspace channel")
        workspace = owner.get("/workspaces")[1]["items"][0]
        workspace_id = workspace["id"]
        st, invitation = owner.post(f"/workspaces/{workspace_id}/invitations", {"role": "viewer"})
        self.assertEqual(st, 201, invitation)
        stored = db.one("SELECT token_hash FROM workspace_invitations WHERE id=?", invitation["id"])
        self.assertNotEqual(stored["token_hash"], invitation["token"])

        member, member_tg = Client(), new_tg_user()
        login_via_bot(member, member_tg)
        st, joined = member.post("/workspaces/join", {"token": invitation["token"]})
        self.assertEqual(st, 200)
        self.assertEqual(joined["workspace"]["role"], "viewer")
        headers = {"X-Workspace-ID": str(workspace_id)}

        st, resources = member.call("GET", "/resources", headers=headers)
        self.assertEqual(st, 200)
        self.assertEqual([row["id"] for row in resources["items"]], [resource["id"]])
        self.assertEqual(member.call("POST", "/posts", {"text": "blocked", "resource_ids": [resource["id"]]}, headers)[0], 403)
        self.assertEqual(member.call("POST", "/moderation/rules", {"resource_id": resource["id"]}, headers)[0], 403)

        member_id = db.one("SELECT id FROM users WHERE telegram_id=?", member_tg["id"])["id"]
        self.assertEqual(owner.put(f"/workspaces/{workspace_id}/members/{member_id}", {"role": "moderator"})[0], 200)
        st, _ = member.call("POST", "/moderation/rules", {
            "resource_id": resource["id"], "name": "Team rule", "match_type": "keyword", "match_text": "spam",
        }, headers)
        self.assertEqual(st, 201)
        self.assertEqual(member.call("POST", "/posts", {"text": "blocked", "resource_ids": [resource["id"]]}, headers)[0], 403)
        self.assertEqual(member.call("POST", "/subscriptions", {"plan": "pro"}, headers)[0], 403)

        outsider, _ = Client(), new_tg_user()
        login_via_bot(outsider, _)
        self.assertEqual(outsider.call("GET", "/resources", headers=headers)[0], 403)

    def test_workspace_invitation_cannot_be_reused_or_self_promoted(self):
        owner, owner_tg = Client(), new_tg_user()
        login_via_bot(owner, owner_tg)
        workspace_id = owner.get("/workspaces")[1]["items"][0]["id"]
        _, invitation = owner.post(f"/workspaces/{workspace_id}/invitations", {"role": "viewer"})
        member, member_tg = Client(), new_tg_user()
        login_via_bot(member, member_tg)
        self.assertEqual(member.post("/workspaces/join", {"token": invitation["token"]})[0], 200)
        self.assertEqual(member.post("/workspaces/join", {"token": invitation["token"]})[0], 404)
        self.assertEqual(member.put(f"/workspaces/{workspace_id}/members/{owner_tg['id']}", {"role": "viewer"})[0], 403)
        member_id = db.one("SELECT id FROM users WHERE telegram_id=?", member_tg["id"])["id"]
        self.assertEqual(member.put(f"/workspaces/{workspace_id}/members/{member_id}", {"role": "owner"})[0], 403)

    def test_admin_cannot_manage_billing_or_promote_another_admin(self):
        owner, _ = Client(), new_tg_user()
        login_via_bot(owner, _)
        workspace_id = owner.get("/workspaces")[1]["items"][0]["id"]
        _, invitation = owner.post(f"/workspaces/{workspace_id}/invitations", {"role": "admin"})
        admin, admin_tg = Client(), new_tg_user()
        login_via_bot(admin, admin_tg)
        self.assertEqual(admin.post("/workspaces/join", {"token": invitation["token"]})[0], 200)
        headers = {"X-Workspace-ID": str(workspace_id)}
        self.assertEqual(admin.call("POST", "/resources/link-code", {}, headers)[0], 200)
        self.assertEqual(admin.call("POST", "/subscriptions", {"plan": "pro"}, headers)[0], 403)
        self.assertEqual(admin.call("POST", f"/workspaces/{workspace_id}/invitations", {"role": "admin"})[0], 422)


class TenantIsolationTests(unittest.TestCase):
    def test_same_chat_cannot_be_connected_to_two_accounts(self):
        a, ua = Client(), new_tg_user()
        b, ub = Client(), new_tg_user()
        login_via_bot(a, ua)
        login_via_bot(b, ub)

        chat = {"id": -7777, "type": "group", "title": "Shared group"}
        FAKE.set_member(chat["id"], ua["id"], {"status": "creator"})
        FAKE.set_member(chat["id"], ub["id"], {"status": "creator"})
        code_a = a.post("/resources/link-code")[1]["code"]
        bot.link_resource(chat, code_a, ua)
        self.assertEqual(db.one("SELECT COUNT(*) n FROM resources WHERE chat_id=? AND user_id=?", chat["id"], db.one("SELECT id FROM users WHERE telegram_id=?", ua["id"])["id"])["n"], 1)

        code_b = b.post("/resources/link-code")[1]["code"]
        bot.link_resource(chat, code_b, ub)

        self.assertEqual(db.one("SELECT COUNT(*) n FROM resources WHERE chat_id=? AND user_id=?", chat["id"], db.one("SELECT id FROM users WHERE telegram_id=?", ub["id"])["id"])["n"], 0)
        self.assertEqual(db.one("SELECT COUNT(*) n FROM resources WHERE chat_id=? AND user_id=?", chat["id"], db.one("SELECT id FROM users WHERE telegram_id=?", ua["id"])["id"])["n"], 1)

    def test_users_cannot_see_or_touch_each_others_data(self):
        a, ua, chat_a, res_a = make_user_with_channel("A channel")
        b, ub, chat_b, res_b = make_user_with_channel("B channel")
        pa = a.post("/posts", {"text": "secret A", "resource_ids": [res_a["id"]], "mode": "draft"})[1]
        tid = pa["targets"][0]["id"]
        self.assertNotIn(res_a["id"], [x["id"] for x in b.get("/resources")[1]["items"]])
        self.assertEqual(b.get(f"/resources/{res_a['id']}")[0], 404)
        self.assertEqual(b.get(f"/posts/{pa['id']}")[0], 404)
        self.assertEqual(b.put(f"/posts/{pa['id']}", {"text": "x", "resource_ids": [res_b["id"]], "mode": "draft"})[0], 404)
        self.assertEqual(b.delete(f"/posts/{pa['id']}")[0], 404)
        self.assertEqual(b.post(f"/post-targets/{tid}/publish-now")[0], 404)
        self.assertEqual(b.post(f"/post-targets/{tid}/cancel")[0], 404)
        self.assertEqual(b.delete(f"/resources/{res_a['id']}")[0], 404)
        self.assertEqual(b.post(f"/resources/{res_a['id']}/check")[0], 404)
        # cannot publish own post into someone else's resource
        self.assertEqual(b.post("/posts", {"text": "x", "resource_ids": [res_a["id"]], "mode": "draft"})[0], 404)
        self.assertNotIn("secret A", json.dumps(b.get("/posts")[1]))
        self.assertNotIn("secret A", json.dumps(b.get("/dashboard")[1]))

    def test_link_code_cannot_be_reused(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Code channel")
        code = db.one("SELECT code FROM link_codes WHERE user_id=? ORDER BY rowid DESC", db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"])["code"]
        other = Client()
        login_via_bot(other, new_tg_user())
        _chat[0] -= 1
        FAKE.push(channel_post={"message_id": 3, "chat": {"id": _chat[0], "type": "channel", "title": "Hijack"}, "text": f"/connect {code}"})
        time.sleep(1.5)
        self.assertFalse([x for x in other.get("/resources")[1]["items"] if x["title"] == "Hijack"])


class AutoReplyTests(unittest.TestCase):
    def test_autoreplies_trigger_for_keyword_in_group(self):
        c, u, chat, res = make_user_with_channel("Auto channel")
        st, rule = c.post("/autoreplies", {
            "resource_id": res["id"],
            "name": "Welcome",
            "match_type": "keyword",
            "match_text": "hello",
            "reply_text": "Hi there! 👋",
            "enabled": True,
            "priority": 10,
        })
        self.assertEqual(st, 201)
        self.assertEqual(rule["reply_text"], "Hi there! 👋")

        FAKE.push(message={"message_id": 99, "from": {"id": 42, "first_name": "Guest"}, "chat": chat, "text": "hello marketpilot"})
        wait_for(lambda: "Hi there! 👋" in FAKE.sent_texts(), 10, "autoreply did not fire")

        st, items = c.get(f"/autoreplies?resource_id={res['id']}")
        self.assertEqual(st, 200)
        self.assertGreaterEqual(items["count"], 1)


class AutoCleanTests(unittest.TestCase):
    def test_autoclean_rule_deletes_matching_message(self):
        c, u, chat, res = make_user_with_channel("AutoClean channel")
        st, rule = c.post("/autoclean/rules", {
            "resource_id": res["id"],
            "name": "Spam keyword",
            "match_type": "keyword",
            "match_text": "spam",
            "enabled": True,
        })
        self.assertEqual(st, 201)
        self.assertEqual(rule["name"], "Spam keyword")

        FAKE.push(message={"message_id": 77, "from": {"id": 42, "first_name": "Guest"}, "chat": chat, "text": "spam promotion"})
        wait_for(lambda: any(call[0] == "deleteMessage" and call[1].get("chat_id") == chat["id"] and call[1].get("message_id") == 77 for call in FAKE.calls), 10, "autoclean did not delete")

    def test_link_autoclean_removes_hidden_telegram_link(self):
        c, u, chat, res = make_user_with_channel("Hidden link blocker")
        st, _ = c.post("/autoclean/rules", {
            "resource_id": res["id"], "name": "Block links", "match_type": "link", "match_text": "", "enabled": True,
        })
        self.assertEqual(st, 201)
        before = len(FAKE.calls)

        bot.handle_message({"message_id": 78, "from": {"id": 99078}, "chat": chat,
                            "text": "Откройте ссылку", "entities": [
                                {"type": "text_link", "offset": 0, "length": 15,
                                 "url": "https://unlisted.example/path"}]})

        self.assertTrue(any(method == "deleteMessage" and payload.get("message_id") == 78
                            for method, payload in FAKE.calls[before:]))


class BillingAndAdsTests(unittest.TestCase):
    def test_ads_exports_and_subscription_plans(self):
        c, u, chat, res = make_user_with_channel("Billing channel")

        st, plans = c.get("/billing/plans")
        self.assertEqual(st, 200)
        self.assertIn("free", plans["plans"])

        st, campaign = c.post("/ads", {
            "resource_id": res["id"],
            "title": "Launch campaign",
            "budget": 150,
            "status": "scheduled",
            "starts_at": "2030-01-01T12:00:00+00:00",
            "ends_at": "2030-01-03T12:00:00+00:00",
        })
        self.assertEqual(st, 201)
        self.assertEqual(campaign["title"], "Launch campaign")

        st, subs = c.get("/subscriptions")
        self.assertEqual(st, 200)
        self.assertIn("free", [x["plan"] for x in subs["items"]])

        st, export = c.get("/export?kind=resources")
        self.assertEqual(st, 200)
        self.assertIn("resources", export)
        self.assertIn("items", export)

    def test_plan_feature_gate_and_profile_settings(self):
        c, u, chat, res = make_user_with_channel("Profile checks")
        uid = db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"]

        st, me = c.get("/me")
        self.assertEqual(st, 200)
        self.assertIn("theme", me)
        self.assertEqual(me["theme"], "light")

        st, updated = c.put("/me", {"theme": "dark", "ui_density": "compact", "security_mode": "strict"})
        self.assertEqual(st, 200)
        self.assertEqual(updated["theme"], "dark")
        self.assertEqual(updated["ui_density"], "compact")
        self.assertEqual(updated["security_mode"], "strict")

        db.run("UPDATE users SET plan='free' WHERE id=?", uid)
        st, blocked = c.post("/ads", {
            "resource_id": res["id"],
            "title": "Blocked campaign",
            "budget": 10,
            "status": "draft",
        })
        self.assertEqual(st, 402)
        self.assertIn("ads", blocked["message"])

        st, export_blocked = c.get("/export?kind=ads")
        self.assertEqual(st, 402)
        self.assertIn("export", export_blocked["message"])

    def test_premium_subscription_lifecycle_and_history(self):
        c, u, chat, res = make_user_with_channel("Premium checks")

        st, created = c.post("/subscriptions", {"plan": "pro"})
        self.assertEqual(st, 201)
        self.assertEqual(created["plan"], "pro")

        st, summary = c.get("/premium/summary")
        self.assertEqual(st, 200)
        self.assertEqual(summary["plan"], "pro")
        self.assertIn("features", summary)

        st, renewed = c.post(f"/subscriptions/{created['id']}/renew", {"months": 1})
        self.assertEqual(st, 200)
        self.assertTrue(renewed["auto_renew"])
        self.assertEqual(renewed["status"], "active")

        st, cancelled = c.post(f"/subscriptions/{created['id']}/cancel")
        self.assertEqual(st, 200)
        self.assertEqual(cancelled["status"], "cancelled")

        st, history = c.get("/premium/history")
        self.assertEqual(st, 200)
        self.assertGreaterEqual(history["count"], 1)
        self.assertTrue(any(x["kind"].startswith("subscription_") for x in history["items"]))


class ModerationTests(unittest.TestCase):
    def test_moderation_rules_scan_and_log(self):
        c = Client()
        c.post("/auth/demo")
        res = c.get("/resources")[1]["items"][0]

        st, rule = c.post("/moderation/rules", {
            "resource_id": res["id"],
            "name": "Spam",
            "level": "strict",
            "match_type": "keyword",
            "match_text": "buy now",
            "action": "delete",
            "enabled": True,
        })
        self.assertEqual(st, 201)
        self.assertEqual(rule["name"], "Spam")

        st, scan = c.post("/moderation/scan", {
            "resource_id": res["id"],
            "text": "BUY NOW and join https://example.com"
        })
        self.assertEqual(st, 200)
        self.assertEqual(scan["status"], "delete")
        self.assertGreater(len(scan["matches"]), 0)

        st, log = c.get(f"/moderation/log?resource_id={res['id']}")
        self.assertEqual(st, 200)
        self.assertGreaterEqual(log["count"], 1)


class AntiScamTests(unittest.TestCase):
    def test_scam_domains_and_history_work(self):
        c = Client()
        c.post("/auth/demo")
        res = c.get("/resources")[1]["items"][0]

        st, blocked = c.post("/anti-scam/domains", {"domain": "pay-verify.xyz", "kind": "blocked"})
        self.assertEqual(st, 201)
        self.assertEqual(blocked["kind"], "blocked")

        st, trusted = c.post("/anti-scam/domains", {"domain": "example.com", "kind": "trusted"})
        self.assertEqual(st, 201)
        self.assertEqual(trusted["kind"], "trusted")

        st, report = c.post("/anti-scam/check", {
            "resource_id": res["id"],
            "text": "Urgent! Verify account: https://pay-verify.xyz/login?token=123"
        })
        self.assertEqual(st, 200)
        self.assertEqual(report["status"], "blocked")
        self.assertGreater(len(report["threats"]), 0)

        st, history = c.get("/anti-scam/history")
        self.assertEqual(st, 200)
        self.assertGreaterEqual(history["count"], 1)

    def test_blocked_domain_is_automatically_removed_from_group(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Auto scam group", "supergroup")
        st, _ = c.post("/anti-scam/domains", {"domain": "fraud.example", "kind": "blocked"})
        self.assertEqual(st, 201)

        before = len(FAKE.calls)
        bot.handle_message({"message_id": 991, "from": {"id": 99001}, "chat": chat,
                    "caption": "Verify your account https://fraud.example/login"})

        self.assertTrue(any(method == "deleteMessage" and payload.get("message_id") == 991
                            for method, payload in FAKE.calls[before:]))
        self.assertGreaterEqual(db.one("SELECT COUNT(*) n FROM scam_events WHERE resource_id=?", res["id"])["n"], 1)

    def test_hidden_link_is_scanned_and_risk_notifies_owner(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Hidden link group", "supergroup")
        st, _ = c.post("/anti-scam/domains", {"domain": "fraud.example", "kind": "blocked"})
        self.assertEqual(st, 201)
        before = len(FAKE.calls)

        bot.handle_message({"message_id": 995, "from": {"id": 99005}, "chat": chat,
                            "text": "Откройте подтверждение", "entities": [
                                {"type": "text_link", "offset": 0, "length": 19,
                                 "url": "https://fraud.example/verify"}]})

        self.assertTrue(any(method == "deleteMessage" and payload.get("message_id") == 995
                            for method, payload in FAKE.calls[before:]))
        self.assertTrue(any(m["chat_id"] == u["id"] and "fraud.example" in m["text"] for m in FAKE.sent))
        self.assertGreaterEqual(db.one("SELECT COUNT(*) n FROM scam_events WHERE resource_id=?", res["id"])["n"], 1)

    def test_unknown_links_notify_owner(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Risk alert group", "supergroup")
        before = len(FAKE.sent)

        bot.handle_message({"message_id": 996, "from": {"id": 99006}, "chat": chat,
                            "text": "Посмотрите https://unverified.example/path и www.different.example/claim"})

        self.assertTrue(any(m["chat_id"] == u["id"] and "unverified.example" in m["text"]
                            and "different.example" in m["text"]
                            for m in FAKE.sent[before:]))
        self.assertGreaterEqual(db.one("SELECT COUNT(*) n FROM scam_events WHERE resource_id=?", res["id"])["n"], 1)


class AutomaticModerationTests(unittest.TestCase):
    def test_moderation_rule_automatically_deletes_matching_group_message(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Auto moderation group", "supergroup")
        st, _ = c.post("/moderation/rules", {
            "resource_id": res["id"], "name": "Spam link", "level": "strict",
            "match_type": "keyword", "match_text": "buy now", "action": "delete", "enabled": True,
        })
        self.assertEqual(st, 201)

        before = len(FAKE.calls)
        bot.handle_message({"message_id": 992, "from": {"id": 99002}, "chat": chat, "text": "BUY NOW"})

        self.assertTrue(any(method == "deleteMessage" and payload.get("message_id") == 992
                            for method, payload in FAKE.calls[before:]))
        self.assertGreaterEqual(db.one("SELECT COUNT(*) n FROM moderation_events WHERE resource_id=?", res["id"])["n"], 1)

    def test_ban_action_is_applied_and_admins_are_exempt(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Auto ban group", "supergroup")
        st, _ = c.post("/moderation/rules", {
            "resource_id": res["id"], "name": "Ban phrase", "level": "standard",
            "match_type": "keyword", "match_text": "scam phrase", "action": "ban", "enabled": True,
        })
        self.assertEqual(st, 201)

        before = len(FAKE.calls)
        bot.handle_message({"message_id": 993, "from": {"id": 99003}, "chat": chat, "text": "scam phrase"})
        self.assertTrue(any(method == "banChatMember" and payload.get("user_id") == 99003
                            for method, payload in FAKE.calls[before:]))

        FAKE.set_member(chat["id"], 99004, {"status": "administrator"})
        before = len(FAKE.calls)
        bot.handle_message({"message_id": 994, "from": {"id": 99004}, "chat": chat, "text": "scam phrase"})
        self.assertFalse(any(method in ("deleteMessage", "banChatMember") and payload.get("message_id", 994) == 994
                             for method, payload in FAKE.calls[before:]))


class PublicationLimitsTests(unittest.TestCase):
    def test_publication_limit_blocks_second_post_for_the_day(self):
        c, u, chat, res = make_user_with_channel("Limit channel")

        st, rule = c.post("/publication-limits", {"resource_id": res["id"], "kind": "messages_per_day", "value": 1})
        self.assertEqual(st, 201)
        self.assertEqual(rule["kind"], "messages_per_day")

        st, p1 = c.post("/posts", {"text": "first", "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 201)
        wait_for(lambda: target_of(c, p1["id"])["status"] == "published", 10)

        st, r = c.post("/posts", {"text": "second", "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(st, 422)
        self.assertEqual(r["error"], "limit_exceeded")

    def test_limited_post_can_be_edited_without_counting_itself(self):
        c, u, chat, res = make_user_with_channel("Edit limited post")
        c.post("/publication-limits", {"resource_id": res["id"], "kind": "messages_per_day", "value": 1})
        when = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        st, post = c.post("/posts", {"text": "first", "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})
        self.assertEqual(st, 201)

        st, _ = c.put(f"/posts/{post['id']}", {"text": "updated", "resource_ids": [res["id"]], "mode": "schedule", "scheduled_at": when})
        self.assertEqual(st, 200)
        self.assertEqual(c.get(f"/posts/{post['id']}")[1]["text"], "updated")


class MediaUploadTests(unittest.TestCase):
    def test_device_upload_can_be_attached_only_by_its_owner(self):
        owner, owner_tg = Client(), new_tg_user()
        login_via_bot(owner, owner_tg)
        upload_status, media = owner.upload("/media", tiny_png(), "cover.png")
        self.assertEqual(upload_status, 201)
        self.assertEqual(media["mime"], "image/png")
        self.assertEqual(media["size"], len(tiny_png()))

        chat_owner, resource_owner = connect_channel(owner, owner_tg, "Media owner channel")
        post_status, post = owner.post("/posts", {"text": "uploaded photo", "image_url": f"upload:{media['id']}",
                                                   "resource_ids": [resource_owner["id"]], "mode": "draft"})
        self.assertEqual(post_status, 201)
        self.assertEqual(post["image_url"], f"upload:{media['id']}")

        other, other_tg = Client(), new_tg_user()
        login_via_bot(other, other_tg)
        chat_other, resource_other = connect_channel(other, other_tg, "Media other channel")
        foreign_status, _ = other.post("/posts", {"text": "foreign photo", "image_url": f"upload:{media['id']}",
                                                   "resource_ids": [resource_other["id"]], "mode": "draft"})
        self.assertEqual(foreign_status, 404)

    def test_uploaded_image_is_sent_as_telegram_photo_bytes(self):
        c, u, chat, res = make_user_with_channel("Uploaded photo delivery")
        upload_status, media = c.upload("/media", tiny_png(), "local-photo.png")
        self.assertEqual(upload_status, 201)

        post_status, post = c.post("/posts", {"text": "from device", "image_url": media["image_url"],
                                               "resource_ids": [res["id"]], "mode": "now"})
        self.assertEqual(post_status, 201)
        wait_for(lambda: target_of(c, post["id"])["status"] == "published", 10)
        photo_calls = [payload for method, payload in FAKE.calls if method == "sendPhoto" and payload.get("chat_id") == chat["id"]]
        self.assertTrue(photo_calls)
        self.assertEqual(photo_calls[-1]["_photo_size"], len(tiny_png()))

    def test_upload_rejects_non_image_payload(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        self.assertEqual(c.upload("/media", b"not an image", "note.txt", "text/plain")[0], 415)
        self.assertEqual(c.upload("/media", b"\x89PNG\r\n\x1a\n" + b"invalid", "broken.png")[0], 415)


class MemberMessageLimitsTests(unittest.TestCase):
    def test_daily_member_limit_deletes_only_messages_over_quota(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Member quota group", "supergroup")
        st, config = c.post("/message-limits", {
            "resource_id": res["id"], "max_messages": 2, "action": "delete", "exclude_admins": True,
        })
        self.assertEqual(st, 201)
        self.assertEqual(config["max_messages"], 2)

        sender = {"id": 99021, "first_name": "Member"}
        FAKE.set_member(chat["id"], sender["id"], {"status": "member"})
        before = len(FAKE.calls)
        for message_id in (101, 102, 103):
            bot.handle_message({"message_id": message_id, "from": sender, "chat": chat,
                                "text": f"private body {message_id}"})

        deletes = [payload["message_id"] for method, payload in FAKE.calls[before:]
                   if method == "deleteMessage"]
        self.assertEqual(deletes, [103])
        bot.handle_message({"message_id": 103, "from": sender, "chat": chat, "text": "replayed update"})
        other_id = 99022
        FAKE.set_member(chat["id"], other_id, {"status": "member"})
        bot.handle_message({"message_id": 104, "from": {"id": other_id}, "chat": chat, "text": "other member"})
        self.assertEqual(db.one("SELECT count FROM message_limit_counters WHERE resource_id=? AND sender_id=?",
                                res["id"], sender["id"])["count"], 3)
        self.assertEqual(db.one("SELECT count FROM message_limit_counters WHERE resource_id=? AND sender_id=?",
                    res["id"], other_id)["count"], 1)
        self.assertNotIn("private body", json.dumps([dict(r) for r in db.q(
            "SELECT * FROM message_limit_counters WHERE resource_id=?", res["id"])]))

    def test_warn_mode_keeps_message_and_excludes_admins(self):
        c, u = Client(), new_tg_user()
        login_via_bot(c, u)
        chat, res = connect_channel(c, u, "Warn quota group", "supergroup")
        st, _ = c.post("/message-limits", {"resource_id": res["id"], "max_messages": 1,
                                           "action": "warn", "exclude_admins": True})
        self.assertEqual(st, 201)
        admin_id = 99031
        FAKE.set_member(chat["id"], admin_id, {"status": "administrator"})
        before = len(FAKE.calls)
        for message_id in (201, 202, 203):
            bot.handle_message({"message_id": message_id, "from": {"id": admin_id}, "chat": chat,
                                "text": "admin message"})
        self.assertFalse(any(method == "deleteMessage" and payload.get("message_id") in (201, 202, 203)
                             for method, payload in FAKE.calls[before:]))
        self.assertEqual(db.one("SELECT COUNT(*) n FROM message_limit_counters WHERE resource_id=? AND sender_id=?",
                                res["id"], admin_id)["n"], 0)

        member_id = 99032
        FAKE.set_member(chat["id"], member_id, {"status": "member"})
        before = len(FAKE.calls)
        bot.handle_message({"message_id": 204, "from": {"id": member_id}, "chat": chat, "text": "first"})
        bot.handle_message({"message_id": 205, "from": {"id": member_id}, "chat": chat, "text": "second"})
        self.assertFalse(any(method == "deleteMessage" and payload.get("message_id") == 205
                             for method, payload in FAKE.calls[before:]))
        self.assertTrue(any(method == "sendMessage" and payload.get("chat_id") == chat["id"]
                            and "Лимит участника" in payload.get("text", "")
                            for method, payload in FAKE.calls[before:]))
        st, log = c.get("/message-limits/log")
        self.assertEqual(st, 200)
        self.assertEqual(log["items"][0]["sender_id"], member_id)


class DemoModeTests(unittest.TestCase):
    def test_demo_user_has_data_and_publishes_without_telegram(self):
        c = Client()
        st, r = c.post("/auth/demo")
        self.assertEqual(st, 200)
        self.assertTrue(r["user"]["is_demo"])
        res = c.get("/resources")[1]["items"]
        self.assertGreaterEqual(len(res), 4)
        self.assertTrue(all(x["is_demo"] for x in res))
        dash = c.get("/dashboard")[1]
        self.assertGreater(dash["kpis"]["members"]["value"], 0)
        self.assertEqual(len(dash["labels"]), 30)
        before = len(FAKE.sent)
        target = next(x for x in res if x["status"] == "active")
        st, p = c.post("/posts", {"text": "demo post", "resource_ids": [target["id"]], "mode": "now"})
        self.assertEqual(st, 201)
        wait_for(lambda: target_of(c, p["id"])["status"] == "published", 10)
        self.assertEqual(len(FAKE.sent), before, "demo publishing must not reach Telegram")
        a = c.get("/analytics?days=30")[1]
        self.assertTrue(a["table"] and a["limitations"])
        self.assertFalse(c.get("/dashboard")[1]["views_available"])

    def test_calendar_templates_settings_and_reset(self):
        c = Client()
        c.post("/auth/demo")
        now = datetime.now(timezone.utc)
        st, r = c.get(f"/targets?from={urllib.parse.quote((now - timedelta(days=40)).isoformat())}&to={urllib.parse.quote((now + timedelta(days=40)).isoformat())}")
        self.assertEqual(st, 200)
        self.assertGreater(len(r["items"]), 5)
        self.assertEqual(c.post("/templates", {"name": "T", "text": "<b>x</b>"})[0], 201)
        self.assertEqual(c.post("/templates", {"name": "T", "text": "<b>x"})[0], 422)
        self.assertGreaterEqual(len(c.get("/templates")[1]["items"]), 3)
        st, me = c.put("/me", {"language": "en", "timezone": "Asia/Tokyo", "notify": False, "first_name": "Neo"})
        self.assertEqual((st, me["language"], me["timezone"]), (200, "en", "Asia/Tokyo"))
        self.assertEqual(c.put("/me", {"timezone": "Mars/Base"})[0], 422)
        self.assertEqual(c.post("/me/reset-demo")[0], 200)
        self.assertGreaterEqual(len(c.get("/resources")[1]["items"]), 4)

    def test_templates_support_categories_favorites_and_variable_preview(self):
        c = Client()
        c.post("/auth/demo")
        st, created = c.post("/templates", {
            "name": "Приветствие",
            "text": "Привет, {name}! Сегодня {day}.",
            "category": "sales",
            "is_favorite": True,
            "variables": ["name", "day"],
        })
        self.assertEqual(st, 201)
        self.assertEqual(created["category"], "sales")
        self.assertTrue(created["is_favorite"])
        self.assertEqual(created["variables"], ["name", "day"])

        st, preview = c.post("/templates/preview", {"text": "Привет, {name}! Сегодня {day}.", "variables": {"name": "Алиса", "day": "среда"}})
        self.assertEqual(st, 200)
        self.assertEqual(preview["text"], "Привет, Алиса! Сегодня среда.")

        st, updated = c.put(f"/templates/{created['id']}", {"name": "Приветствие 2", "category": "vip", "is_favorite": False})
        self.assertEqual(st, 200)
        self.assertEqual(updated["category"], "vip")
        self.assertFalse(updated["is_favorite"])

        items = c.get("/templates")[1]["items"]
        self.assertTrue(any(x["id"] == created["id"] and x["category"] == "vip" for x in items))

    def test_demo_resource_rights_simulation_blocks_publishing(self):
        c = Client()
        c.post("/auth/demo")
        res = next(x for x in c.get("/resources")[1]["items"] if x["status"] == "active")
        self.assertEqual(c.post(f"/resources/{res['id']}/simulate-rights")[1]["status"], "missing_rights")
        self.assertEqual(c.post("/posts", {"text": "x", "resource_ids": [res["id"]], "mode": "now"})[1]["error"], "no_rights")
        self.assertEqual(c.post(f"/resources/{res['id']}/simulate-rights")[1]["status"], "active")

    def test_real_account_can_load_and_remove_demo_data(self):
        c, u, chat, res = make_user_with_channel("Real channel")
        self.assertEqual(c.post("/me/demo-data")[0], 200)
        items = c.get("/resources")[1]["items"]
        self.assertTrue(any(x["is_demo"] for x in items) and any(not x["is_demo"] for x in items))
        self.assertEqual(c.delete("/me/demo-data")[0], 200)
        items = c.get("/resources")[1]["items"]
        self.assertEqual([x["title"] for x in items], ["Real channel"])

    def test_account_deletion_removes_everything(self):
        c, u, chat, res = make_user_with_channel("Delete channel")
        c.post("/posts", {"text": "bye", "resource_ids": [res["id"]], "mode": "draft"})
        uid = db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"]
        self.assertEqual(c.delete("/me")[0], 200)
        for table in ("users", "resources", "posts", "post_targets", "sessions"):
            col = "id" if table == "users" else ("user_id")
            self.assertEqual(db.one(f"SELECT COUNT(*) n FROM {table} WHERE {col}=?", uid)["n"], 0, table)
        self.assertEqual(c.get("/me")[0], 401)


class ConcurrencyTests(unittest.TestCase):
    def test_parallel_claims_never_overlap(self):
        stop_scheduler()
        try:
            c = Client()
            c.post("/auth/demo")
            res = next(x for x in c.get("/resources")[1]["items"] if x["status"] == "active")
            ids = []
            for i in range(40):
                p = c.post("/posts", {"text": f"p{i}", "resource_ids": [res["id"]], "mode": "now"})[1]
                ids.append(p["targets"][0]["id"])
            claimed, lock = [], threading.Lock()

            def worker():
                while True:
                    got = scheduler.claim_due()
                    if not got:
                        return
                    with lock:
                        claimed.extend(got)

            ts = [threading.Thread(target=worker) for _ in range(6)]
            [t.start() for t in ts]
            [t.join() for t in ts]
            mine = [x for x in claimed if x in ids]
            self.assertEqual(len(mine), len(set(mine)), "a target was claimed twice")
            self.assertEqual(set(mine), set(ids))
            # simulate a crash mid-send: stuck 'publishing' becomes 'unknown'
            db.run("UPDATE post_targets SET started_at=? WHERE id=?", db.iso(db.now() - timedelta(minutes=10)), ids[0])
            self.assertGreaterEqual(scheduler.recover_stuck(), 1)
            self.assertEqual(db.one("SELECT status FROM post_targets WHERE id=?", ids[0])["status"], "unknown")
        finally:
            start_scheduler()


class MiniAppTests(unittest.TestCase):
    def _login(self):
        u = new_tg_user()
        data = AuthTests._init_data(self, u)
        c = Client()
        st, r = c.post("/auth/miniapp", {"init_data": data})
        self.assertEqual(st, 200, r)
        return u, r

    def test_start_sends_web_app_button(self):
        u = new_tg_user()
        FAKE.push(message={"message_id": 1, "from": u, "chat": {"id": u["id"], "type": "private"}, "text": "/start"})
        m = wait_for(lambda: next((x for x in FAKE.sent if x["chat_id"] == u["id"] and x["reply_markup"]), None), 10, "no welcome")
        btn = m["reply_markup"]["inline_keyboard"][0][0]
        self.assertEqual(btn["web_app"]["url"], "https://mp.example.test/app/")
        self.assertIn("Открыть приложение", btn["text"])

    def test_menu_button_and_commands_configured(self):
        names = [n for n, _ in FAKE.calls]
        self.assertIn("setMyCommands", names)
        self.assertIn("setChatMenuButton", names)
        body = next(b for n, b in FAKE.calls if n == "setChatMenuButton")
        self.assertEqual(body["menu_button"]["web_app"]["url"], "https://mp.example.test/app/")

    def test_bearer_token_and_notifications(self):
        u, r = self._login()
        self.assertTrue(r["token"])
        c = Client()  # no cookie: only the Bearer token
        h = {"Authorization": "Bearer " + r["token"]}
        st, me = c.call("GET", "/me", headers=h)
        self.assertEqual(st, 200)
        self.assertEqual(me["telegram_id"], u["id"])
        self.assertEqual(Client().get("/notifications")[0], 401)
        st, n = c.call("GET", "/notifications", headers=h)
        self.assertEqual((st, n["unread"]), (200, 0))
        c.call("POST", "/me/demo-data", {}, headers=h)
        st, n = c.call("GET", "/notifications", headers=h)
        db.event(me["id"], "published", "тест") if hasattr(db, "event") else None
        st, n = c.call("GET", "/notifications", headers=h)
        self.assertGreaterEqual(n["unread"], 1)
        self.assertEqual(c.call("POST", "/notifications/read", {}, headers=h)[1]["unread"], 0)
        self.assertEqual(c.call("GET", "/notifications", headers=h)[1]["unread"], 0)

    def test_notifications_isolated(self):
        _, a = self._login()
        _, b = self._login()
        ha, hb = {"Authorization": "Bearer " + a["token"]}, {"Authorization": "Bearer " + b["token"]}
        Client().call("POST", "/me/demo-data", {}, headers=ha)
        ids_a = {x["id"] for x in Client().call("GET", "/notifications", headers=ha)[1]["items"]}
        ids_b = {x["id"] for x in Client().call("GET", "/notifications", headers=hb)[1]["items"]}
        self.assertFalse(ids_a & ids_b)

    def test_static_miniapp(self):
        with urllib.request.urlopen(BASE + "/app/", timeout=10) as r:
            body = r.read().decode()
            self.assertEqual(r.status, 200)
            self.assertIn("telegram-web-app.js", body)
            self.assertIn("frame-ancestors", r.headers.get("Content-Security-Policy", ""))
        for p in ("/app/app.js", "/app/tg.js", "/app/app.css"):
            with urllib.request.urlopen(BASE + p, timeout=10) as r:
                self.assertEqual(r.status, 200)
        opener = urllib.request.build_opener(type("NoRedir", (urllib.request.HTTPRedirectHandler,), {"redirect_request": lambda *a, **k: None}))
        try:
            opener.open(BASE + "/app", timeout=10)
            self.fail("expected redirect")
        except urllib.error.HTTPError as e:
            self.assertIn(e.code, (301, 302, 307, 308))
            self.assertTrue(e.headers["Location"].endswith("/app/"))


class AuditAndBillingTests(unittest.TestCase):
    def test_audit_log_records_mutations_failures_and_is_isolated(self):
        c, u, chat, res = make_user_with_channel("Audit channel")
        st, tpl = c.post("/templates", {"name": "audit tpl", "text": "hello"})
        self.assertIn(st, (200, 201))
        st, _ = c.post("/subscriptions", {"plan": "nope"})
        self.assertEqual(st, 422)
        st, log = c.get("/audit-log")
        self.assertEqual(st, 200)
        actions = [i["action"] for i in log["items"]]
        self.assertIn("POST /api/v1/templates", actions)
        failed = [i for i in log["items"] if i["status"] == 422]
        self.assertTrue(failed and failed[0]["request_id"])
        for item in log["items"]:  # only metadata is stored, never bodies or texts
            self.assertNotIn("audit tpl", json.dumps(item))
        st, only_failed = c.get("/audit-log?failed=1")
        self.assertTrue(all(i["status"] >= 400 for i in only_failed["items"]))
        c2, *_ = make_user_with_channel("Other audit user")
        st, other = c2.get("/audit-log")
        self.assertFalse(any(i["id"] in {x["id"] for x in log["items"]} for i in other["items"]))

    def test_error_responses_carry_request_id(self):
        c, *_ = make_user_with_channel("Request id")
        st, body = c.post("/subscriptions", {"plan": "nope"})
        self.assertEqual(st, 422)
        self.assertTrue(body.get("request_id"))

    def test_public_plans_and_paid_upgrade_requires_payment_in_live_mode(self):
        c, *_ = make_user_with_channel("Billing live")
        st, plans = c.get("/billing/plans")
        self.assertEqual(st, 200)
        self.assertTrue({"free", "pro", "business"} <= set(plans["plans"]))
        self.assertNotIn("agency", plans["plans"])
        old = cfg.BILLING_MODE
        cfg.BILLING_MODE = "live"
        try:
            st, body = c.post("/subscriptions", {"plan": "business"})
            self.assertEqual(st, 402)
            self.assertEqual(body["error"], "payment_required")
            st, me = c.get("/me")
            self.assertNotEqual(me["plan"], "business")
            st, _ = c.post("/subscriptions", {"plan": "free"})  # downgrade is always allowed
            self.assertEqual(st, 201)
        finally:
            cfg.BILLING_MODE = old


if __name__ == "__main__":
    unittest.main()
