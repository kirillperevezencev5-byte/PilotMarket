"""Local YooKassa API fake for billing integration tests."""
import base64
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeYooKassa:
    def __init__(self):
        self.lock = threading.Lock()
        self.payments = {}
        self.refunds = {}
        self.calls = []
        self.next_payment = 1
        self.next_refund = 1
        self.server = None

    def start(self) -> str:
        fake = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *_):
                pass

            def _respond(self, status, payload):
                data = json.dumps(payload).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if self.headers.get("Authorization") != "Basic " + base64.b64encode(b"test-shop:test-secret").decode():
                    return self._respond(401, {"type": "error", "description": "unauthorized"})
                path = self.path.strip("/").split("/")
                with fake.lock:
                    if len(path) == 2 and path[0] == "payments" and path[1] in fake.payments:
                        fake.calls.append(("GET", self.path, {}))
                        return self._respond(200, fake.payments[path[1]])
                    if len(path) == 2 and path[0] == "refunds" and path[1] in fake.refunds:
                        fake.calls.append(("GET", self.path, {}))
                        return self._respond(200, fake.refunds[path[1]])
                self._respond(404, {"type": "error", "description": "not found"})

            def do_POST(self):
                if self.headers.get("Authorization") != "Basic " + base64.b64encode(b"test-shop:test-secret").decode():
                    return self._respond(401, {"type": "error", "description": "unauthorized"})
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
                path = self.path.strip("/")
                with fake.lock:
                    fake.calls.append(("POST", path, body))
                    if path == "payments":
                        key = self.headers.get("Idempotence-Key")
                        existing = next((p for p in fake.payments.values() if p.get("_idempotency_key") == key), None)
                        if existing:
                            return self._respond(200, {k: v for k, v in existing.items() if not k.startswith("_")})
                        payment_id = f"test-payment-{fake.next_payment}"
                        fake.next_payment += 1
                        result = {
                            "id": payment_id,
                            "status": "pending",
                            "amount": body["amount"],
                            "metadata": body.get("metadata", {}),
                            "confirmation": {"type": "redirect", "confirmation_url": "https://checkout.example.test/" + payment_id},
                            "payment_method": {"id": "test-method-" + payment_id, "saved": bool(body.get("save_payment_method"))},
                            "_idempotency_key": key,
                        }
                        fake.payments[payment_id] = result
                        return self._respond(200, {k: v for k, v in result.items() if not k.startswith("_")})
                    if path == "refunds":
                        refund_id = f"test-refund-{fake.next_refund}"
                        fake.next_refund += 1
                        result = {"id": refund_id, "status": "pending", "payment_id": body["payment_id"], "amount": body["amount"]}
                        fake.refunds[refund_id] = result
                        return self._respond(200, result)
                self._respond(404, {"type": "error", "description": "not found"})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return f"http://127.0.0.1:{self.server.server_address[1]}"

    def set_payment_status(self, payment_id: str, status: str) -> None:
        with self.lock:
            self.payments[payment_id]["status"] = status

    def set_refund_status(self, refund_id: str, status: str) -> None:
        with self.lock:
            self.refunds[refund_id]["status"] = status

    def stop(self):
        if self.server:
            self.server.shutdown()
