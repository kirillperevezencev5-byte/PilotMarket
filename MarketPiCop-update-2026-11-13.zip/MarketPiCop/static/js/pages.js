/* MarketPilot pages: Dashboard, Resources, Posts (list + calendar + editor), Analytics, Settings. */
(function () {
  'use strict';
  const MP = window.MP;
  const { h, $, clear, t, api, toast, fail, modal, confirmDialog, busy, fmtNum, fmtDateTime, fmtTime, fmtDay, ago } = MP;
  const pages = (MP.pages = {});
  const state = MP.state;

  // ---------------------------------------------------------------- shared bits
  async function loadResources() {
    const r = await api('GET', '/resources');
    state.resources = r.items;
    return r.items;
  }
  const activeResources = () => state.resources.filter((r) => r.status !== 'disconnected');
  function resourceSelect(value, onchange, withAll = true) {
    return h('select', { onchange: (e) => onchange(e.target.value), 'aria-label': t('Ресурс') },
      withAll ? h('option', { value: '' }, t('Все ресурсы')) : null,
      activeResources().map((r) => h('option', { value: r.id, selected: String(r.id) === String(value) }, r.title + (r.is_demo ? ' · DEMO' : ''))));
  }
  function periodSelect(value, onchange) {
    return h('select', { onchange: (e) => onchange(+e.target.value), 'aria-label': t('Период') },
      [7, 30, 90].map((d) => h('option', { value: d, selected: d === value }, MP.state.lang === 'en' ? `${d} days` : `${d} дн.`)));
  }
  function head(title, sub, ...actions) {
    return h('div', { class: 'page-head' }, h('div', {}, h('h1', {}, title), sub ? h('div', { class: 'sub' }, sub) : null), h('div', { class: 'row right' }, actions));
  }
  function emptyBox(title, text, ...actions) {
    return h('div', { class: 'card empty' }, h('h3', {}, title), h('p', { style: 'margin:0 0 12px' }, text), h('div', { class: 'row', style: 'justify-content:center' }, actions));
  }
  function eventDot(kind) {
    return { published: 'ok', resource_connected: 'ok', publish_failed: 'bad', publish_unknown: 'warn', rights_changed: 'warn', resource_disconnected: '' }[kind] || 'blue';
  }
  function eventList(events) {
    if (!events.length) return h('div', { class: 'muted' }, t('Событий пока нет'));
    return events.map((e) => h('div', { class: 'list-item' }, h('span', { class: 'dot ' + eventDot(e.kind) }), h('div', {}, h('div', {}, e.message), h('div', { class: 'small muted' }, ago(e.created_at) + ' · ' + fmtDateTime(e.created_at)))));
  }
  const goto = (hash) => { location.hash = hash; };

  // ================================================================ DASHBOARD
  const dashF = { days: 30, resource_id: '', type: '', kind: '' };
  pages.dashboard = async function (root) {
    await loadResources();
    const content = h('div');
    const filters = h('div', { class: 'filters' });
    const draw = () => {
      clear(filters).append(
        periodSelect(dashF.days, (v) => { dashF.days = v; load(); }),
        h('select', { onchange: (e) => { dashF.type = e.target.value; load(); } },
          [['', 'Все типы'], ['channel', 'Каналы'], ['group', 'Группы']].map(([v, l]) => h('option', { value: v, selected: v === dashF.type }, t(l)))),
        resourceSelect(dashF.resource_id, (v) => { dashF.resource_id = v; load(); }),
        h('select', { onchange: (e) => { dashF.kind = e.target.value; load(); }, 'aria-label': t('Категория событий') },
          [['', 'Все события'], ['published', 'Публикации'], ['publish_failed', 'Ошибки публикации'], ['rights_changed', 'Изменения прав'], ['resource_connected', 'Подключения']].map(([v, l]) => h('option', { value: v, selected: v === dashF.kind }, t(l)))));
    };
    root.append(head(t('Дашборд'), t('Единая картина по всем подключённым ресурсам')), filters, content);

    async function load() {
      draw();
      clear(content).append(h('div', { class: 'boot', style: 'height:200px' }, h('div', { class: 'spinner' })));
      let d;
      try {
        const q = new URLSearchParams({ days: dashF.days });
        if (dashF.resource_id) q.set('resource_id', dashF.resource_id);
        if (dashF.type) q.set('type', dashF.type);
        if (dashF.kind) q.set('kind', dashF.kind);
        d = await api('GET', '/dashboard?' + q);
      } catch (e) { clear(content).append(h('div', { class: 'note err' }, e.message)); return; }
      if (!state.resources.length) {
        clear(content).append(emptyBox(t('Пока нет подключённых ресурсов'), t('Подключите канал или группу через бота — или добавьте демо-данные, чтобы посмотреть, как всё выглядит.'),
          h('button', { class: 'btn primary', onclick: () => goto('#/resources') }, t('Подключить ресурс')),
          h('button', { class: 'btn', onclick: loadDemoData }, t('Загрузить демо-данные'))));
        return;
      }
      const k = d.kpis;
      const kpi = (label, o, extra) => h('div', { class: 'card kpi', title: `${t('Источник')}: ${o.source}` + (o.period ? ` · ${t('Период')}: ${o.period}` : '') },
        h('div', { class: 'label' }, label), h('div', { class: 'value' }, fmtNum(o.value)), extra || null,
        h('div', { class: 'meta' }, (o.period ? o.period + ' · ' : '') + o.source));
      const deltaEl = k.members.delta !== null && k.members.delta !== undefined
        ? h('div', { class: 'small delta ' + (k.members.delta >= 0 ? 'up' : 'down') }, (k.members.delta >= 0 ? '▲ +' : '▼ ') + fmtNum(k.members.delta) + (k.members.delta_pct !== null ? ` (${k.members.delta_pct}%)` : '') + ` ${t('за')} ${d.period_days} ${t('дн.')}`) : null;
      clear(content).append(
        h('div', { class: 'grid kpis' },
          kpi(t('Каналы'), k.channels), kpi(t('Группы'), k.groups), kpi(t('Подписчики'), k.members, deltaEl),
          kpi(t('Опубликовано'), k.published), kpi(t('Запланировано'), k.scheduled),
          h('div', { class: 'card kpi', style: k.attention.value ? 'border-color:var(--warn)' : '' }, h('div', { class: 'label' }, t('Требует внимания')), h('div', { class: 'value', style: k.attention.value ? 'color:var(--warn)' : '' }, fmtNum(k.attention.value)), h('div', { class: 'meta' }, k.attention.period + ' · ' + k.attention.source))),
        h('div', { class: 'grid cols2', style: 'margin-top:14px' },
          h('div', { class: 'card' }, h('h3', {}, t('Динамика подписчиков')), MP.lineChart({ labels: d.labels, series: [{ name: t('Подписчики'), values: d.members_series }] }), h('div', { class: 'small muted', style: 'margin-top:6px' }, t('Источник') + ': ' + k.members.source)),
          h('div', { class: 'card' }, h('h3', {}, t('Публикации по дням')), MP.barChart({ labels: d.labels, values: d.published_series }), h('div', { class: 'small muted', style: 'margin-top:6px' }, t('Источник') + ': ' + k.published.source))),
        h('div', { class: 'grid cols2', style: 'margin-top:14px' },
          h('div', { class: 'card' }, h('h3', {}, t('Ближайшие публикации')), d.upcoming.length ? d.upcoming.map((u) => h('div', { class: 'list-item' }, h('span', { class: 'dot blue' }), h('div', {}, h('div', {}, u.text || '—'), h('div', { class: 'small muted' }, fmtDateTime(u.scheduled_at) + ' · ' + u.resource_title)))) : h('div', { class: 'muted' }, t('Нет запланированных публикаций')),
            h('div', { style: 'margin-top:10px' }, h('button', { class: 'btn sm', onclick: () => goto('#/posts') }, t('Открыть календарь')))),
          h('div', { class: 'card' }, h('h3', {}, t('Последние события')), eventList(d.events))),
        h('div', { class: 'note', style: 'margin-top:14px' }, d.views_note));
    }
    load();
  };

  async function loadDemoData() {
    try { await api('POST', '/me/demo-data'); toast(t('Демо-данные загружены')); MP.render(); } catch (e) { fail(e); }
  }

  // ================================================================ RESOURCES
  const resF = { q: '', type: '', status: '' };
  pages.resources = async function (root) {
    const grid = h('div', { class: 'grid cols3' });
    let timer;
    const filters = h('div', { class: 'filters' },
      h('input', { type: 'search', placeholder: t('Поиск') + '…', value: resF.q, oninput: (e) => { resF.q = e.target.value; clearTimeout(timer); timer = setTimeout(load, 250); } }),
      h('select', { onchange: (e) => { resF.type = e.target.value; load(); } }, [['', 'Все типы'], ['channel', 'Каналы'], ['group', 'Группы']].map(([v, l]) => h('option', { value: v, selected: v === resF.type }, t(l)))),
      h('select', { onchange: (e) => { resF.status = e.target.value; load(); } }, [['', 'Все статусы'], ['active', 'Подключён'], ['missing_rights', 'Не хватает прав'], ['disconnected', 'Отключён']].map(([v, l]) => h('option', { value: v, selected: v === resF.status }, t(l)))));
    root.append(head(t('Ресурсы'), t('Каналы и группы, подключённые к MarketPilot'), h('button', { class: 'btn primary', onclick: () => connectModal(load) }, MP.icon('plus'), t('Подключить ресурс'))), filters, grid);

    async function load() {
      const q = new URLSearchParams();
      Object.entries(resF).forEach(([k, v]) => v && q.set(k, v));
      let items;
      try { items = (await api('GET', '/resources?' + q)).items; } catch (e) { clear(grid).append(h('div', { class: 'note err' }, e.message)); return; }
      state.resources = items.length || !(resF.q || resF.type || resF.status) ? items : state.resources;
      clear(grid);
      if (!items.length) {
        grid.style.display = 'block';
        grid.append(emptyBox(resF.q || resF.type || resF.status ? t('Ничего не найдено') : t('Ресурсов пока нет'),
          t('Подключите канал или группу через бота либо добавьте демо-ресурс для теста.'),
          h('button', { class: 'btn primary', onclick: () => connectModal(load) }, t('Подключить ресурс')),
          h('button', { class: 'btn', onclick: loadDemoData }, t('Загрузить демо-данные'))));
        return;
      }
      grid.style.display = '';
      items.forEach((r) => grid.append(resourceCard(r, load)));
    }
    load();
  };

  function resourceCard(r, reload) {
    const dis = r.status === 'disconnected';
    const delta = r.members_delta_7d;
    return h('div', { class: 'card res-card', style: dis ? 'opacity:.75' : '' },
      h('div', { class: 'row' }, h('span', { class: 'title', onclick: () => resourceModal(r.id, reload) }, r.title), h('span', { class: 'right' }, r.is_demo ? MP.demoBadge() : null)),
      h('div', { class: 'row' }, h('span', { class: 'badge' }, t(MP.TYPES[r.type])), MP.resBadge(r.status), r.username ? h('span', { class: 'small muted' }, '@' + r.username) : null),
      h('div', { class: 'row', style: 'align-items:baseline' }, h('span', { class: 'big' }, fmtNum(r.members)), h('span', { class: 'muted small' }, t('подписчиков')),
        delta !== null && delta !== undefined ? h('span', { class: 'small delta ' + (delta >= 0 ? 'up' : 'down') }, (delta >= 0 ? '▲ +' : '▼ ') + fmtNum(delta) + ' ' + t('за 7 дн.')) : null),
      r.missing_rights.length ? h('div', { class: 'note warn' }, t('Не хватает прав') + ': ' + r.missing_rights.map((x) => MP.RIGHTS[x] || x).join(', ')) : null,
      h('div', { class: 'row' }, r.capabilities.map((c) => h('span', { class: 'chip' }, t(MP.CAPS[c] || c)))),
      h('div', { class: 'small muted' }, `${t('Опубликовано')}: ${r.published_total} · ${t('Запланировано')}: ${r.scheduled_count} · ${t('Проверено')}: ${ago(r.last_checked_at)}`),
      h('div', { class: 'res-actions' },
        dis ? [
          r.is_demo ? h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/resources/${r.id}/reconnect`), t('Ресурс подключён'), reload) }, t('Подключить заново')) : null,
          h('button', { class: 'btn sm danger', onclick: async () => { if (await confirmDialog(t('Удалить ресурс и всю его историю из MarketPilot?'), { danger: true, okText: t('Удалить') })) { try { await api('DELETE', `/resources/${r.id}/forget`); toast(t('Удалено')); reload(); } catch (e) { fail(e); } } } }, t('Удалить'))
        ] : [
          h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/resources/${r.id}/check`), t('Права проверены'), reload) }, t('Проверить права')),
          h('button', { class: 'btn sm', onclick: () => { MP.postsFilter = { resource_id: String(r.id) }; goto('#/posts'); } }, t('Публикации')),
          r.is_demo ? h('button', { class: 'btn sm', title: t('Демо: показать, как продукт реагирует на отзыв прав'), onclick: (e) => act(e, () => api('POST', `/resources/${r.id}/simulate-rights`), t('Права изменены (демо)'), reload) }, r.status === 'active' ? t('Отозвать права (демо)') : t('Вернуть права (демо)')) : null,
          h('button', { class: 'btn sm danger', onclick: async () => { if (await confirmDialog(t('Отключить «') + r.title + t('»? Будущие публикации в него будут отменены.'), { danger: true, okText: t('Отключить') })) { try { await api('DELETE', `/resources/${r.id}`); toast(t('Ресурс отключён')); reload(); } catch (e) { fail(e); } } } }, t('Отключить')),
        ]));
  }
  async function act(e, fn, okMsg, reload) {
    await busy(e.currentTarget, async () => { try { await fn(); toast(okMsg); await reload(); } catch (err) { fail(err); } });
  }

  async function resourceModal(id, reload) {
    let r;
    try { r = await api('GET', '/resources/' + id); } catch (e) { return fail(e); }
    modal({
      title: r.title, body: h('div', { class: 'stack' },
        h('div', { class: 'row' }, h('span', { class: 'badge' }, t(MP.TYPES[r.type])), MP.resBadge(r.status), r.is_demo ? MP.demoBadge() : null, r.username ? h('span', { class: 'muted' }, '@' + r.username) : null),
        h('div', {}, h('span', { class: 'big' }, fmtNum(r.members)), ' ', h('span', { class: 'muted' }, t('подписчиков'))),
        h('div', {}, h('div', { class: 'small muted' }, t('Доступные действия бота')), h('div', { class: 'row', style: 'margin-top:4px' }, r.capabilities.length ? r.capabilities.map((c) => h('span', { class: 'chip' }, t(MP.CAPS[c] || c))) : h('span', { class: 'muted' }, '—'))),
        r.missing_rights.length ? h('div', { class: 'note warn' }, t('Не хватает прав') + ': ' + r.missing_rights.map((x) => MP.RIGHTS[x] || x).join(', ') + '. ' + t('Выдайте боту эти права в настройках администраторов.')) : null,
        h('div', { class: 'small muted' }, `${t('Подключён')}: ${fmtDateTime(r.connected_at)} · ${t('Проверено')}: ${fmtDateTime(r.last_checked_at)}`),
        h('div', {}, h('h3', {}, t('Последние события')), eventList(r.recent_events)),
        h('div', { class: 'small muted' }, t('Связанные автоматизации: появятся на следующем этапе.'))),
      footer: (close) => [h('button', { class: 'btn', onclick: () => { close(); MP.postsFilter = { resource_id: String(r.id) }; goto('#/posts'); } }, t('Публикации')), h('button', { class: 'btn primary', onclick: close }, t('Закрыть'))],
    });
  }

  function connectModal(reload) {
    let poll = null;
    const known = new Set(state.resources.map((r) => r.id));
    const live = h('div', { class: 'stack' });
    const demoForm = { title: '', type: 'channel', members: 1500 };
    const errbox = h('div', { class: 'errtext' });
    const startLive = async (btn) => {
      await busy(btn, async () => {
        try {
          const r = await api('POST', '/resources/link-code');
          if (!r.live) { clear(live).append(h('div', { class: 'note warn' }, r.message)); return; }
          clear(live).append(
            h('ol', { style: 'margin:0;padding-left:20px;line-height:1.7' },
              h('li', {}, t('Откройте канал или группу и добавьте бота '), h('b', {}, '@' + r.bot_username), t(' в администраторы (для канала нужно право «Публикация сообщений»).')),
              h('li', {}, t('Отправьте в этом чате сообщение:'), h('div', { class: 'linkbox', style: 'margin-top:6px;font-size:15px' }, h('b', {}, '/connect ' + r.code))),
              h('li', {}, t('Эта страница обновится сама, когда бот увидит команду.'))),
            h('div', { class: 'small muted' }, t('Код действует 15 минут.')), h('div', { class: 'row' }, h('div', { class: 'spinner', style: 'width:18px;height:18px;border-width:2px' }), h('span', { class: 'muted small' }, t('Жду подключения…'))));
          poll = setInterval(async () => {
            try {
              const s = await api('GET', '/resources/link-status');
              const fresh = s.items.find((x) => !known.has(x.id));
              if (fresh) { clearInterval(poll); toast(t('Подключён ресурс «') + fresh.title + '»'); m.close(); reload(); }
            } catch (e) { /* keep polling */ }
          }, 3000);
        } catch (e) { clear(live).append(h('div', { class: 'note err' }, e.message)); }
      });
    };
    const m = modal({
      title: t('Подключить ресурс'), wide: false, onClose: () => poll && clearInterval(poll),
      body: h('div', { class: 'stack' },
        h('div', {}, h('h3', {}, t('Через Telegram-бота')),
          h('p', { class: 'muted', style: 'margin:4px 0 10px' }, t('Бот проверит свои права и добавит ресурс в ваше рабочее пространство.')),
          h('button', { class: 'btn primary', onclick: (e) => startLive(e.currentTarget) }, t('Получить код подключения')), live),
        h('hr', { style: 'width:100%;border:0;border-top:1px solid var(--border)' }),
        h('div', {}, h('h3', {}, t('Демо-ресурс')), h('p', { class: 'muted', style: 'margin:4px 0 10px' }, t('Не отправляет ничего в Telegram — удобно, чтобы протестировать планировщик и аналитику.')),
          h('div', { class: 'field' }, h('label', { class: 'f' }, t('Название')), h('input', { type: 'text', maxlength: 80, placeholder: t('Например, Мой тестовый канал'), oninput: (e) => (demoForm.title = e.target.value) })),
          h('div', { class: 'row' }, h('div', { style: 'flex:1;min-width:140px' }, h('label', { class: 'f' }, t('Тип')), h('select', { onchange: (e) => (demoForm.type = e.target.value) }, ['channel', 'group', 'supergroup'].map((v) => h('option', { value: v }, t(MP.TYPES[v]))))),
            h('div', { style: 'flex:1;min-width:140px' }, h('label', { class: 'f' }, t('Подписчиков')), h('input', { type: 'number', min: 0, value: demoForm.members, oninput: (e) => (demoForm.members = +e.target.value) }))), errbox)),
      footer: (close) => [h('button', { class: 'btn', onclick: close }, t('Закрыть')),
        h('button', { class: 'btn', onclick: async (e) => { errbox.textContent = ''; await busy(e.currentTarget, async () => { try { await api('POST', '/resources/demo', { ...demoForm, title: demoForm.title.trim() }); toast(t('Демо-ресурс добавлен')); close(); reload(); } catch (err) { errbox.textContent = err.message; } }); } }, t('Добавить демо-ресурс'))],
    });
  }

  // ================================================================ POSTS
  MP.postsFilter = MP.postsFilter || {};
  const postsUI = { view: 'list', calMode: 'month', calCursor: null, status: '', q: '', resource_id: '' };

  pages.posts = async function (root) {
    await loadResources();
    if (MP.postsFilter.resource_id !== undefined) { postsUI.resource_id = MP.postsFilter.resource_id; MP.postsFilter = {}; }
    const body = h('div');
    const seg = h('div', { class: 'seg' });
    const drawSeg = () => clear(seg).append(['list', 'calendar'].map((v) => h('button', { class: postsUI.view === v ? 'on' : '', onclick: () => { postsUI.view = v; drawSeg(); show(); } }, v === 'list' ? t('Список') : t('Календарь'))));
    root.append(head(t('Публикации'), t('Планирование, календарь и история'), seg, h('button', { class: 'btn primary', onclick: () => openEditor({ onSaved: show }) }, MP.icon('plus'), t('Новый пост'))), body);
    drawSeg();
    function show() { clear(body); postsUI.view === 'list' ? renderPostList(body) : renderCalendar(body); }
    show();
  };

  function renderPostList(root) {
    const list = h('div', { class: 'stack' });
    const more = h('div', { style: 'text-align:center;margin-top:12px' });
    let offset = 0, timer;
    const filters = h('div', { class: 'filters' },
      h('input', { type: 'search', placeholder: t('Поиск по тексту'), value: postsUI.q, oninput: (e) => { postsUI.q = e.target.value; clearTimeout(timer); timer = setTimeout(() => load(true), 250); } }),
      h('select', { onchange: (e) => { postsUI.status = e.target.value; load(true); } }, [['', 'Все статусы'], ['draft', 'Черновик'], ['scheduled', 'Запланирован'], ['published', 'Опубликован'], ['failed', 'Ошибка'], ['unknown', 'Не подтверждён'], ['cancelled', 'Отменён']].map(([v, l]) => h('option', { value: v, selected: v === postsUI.status }, t(l)))),
      resourceSelect(postsUI.resource_id, (v) => { postsUI.resource_id = v; load(true); }));
    root.append(filters, list, more);

    async function load(reset) {
      if (reset) { offset = 0; clear(list); }
      const q = new URLSearchParams({ limit: 20, offset });
      if (postsUI.status) q.set('status', postsUI.status);
      if (postsUI.resource_id) q.set('resource_id', postsUI.resource_id);
      if (postsUI.q) q.set('q', postsUI.q);
      let r;
      try { r = await api('GET', '/posts?' + q); } catch (e) { list.append(h('div', { class: 'note err' }, e.message)); return; }
      r.items.forEach((p) => list.append(postCard(p, () => load(true))));
      offset += r.items.length;
      clear(more);
      if (!r.items.length && reset) list.append(emptyBox(t('Публикаций нет'), postsUI.status || postsUI.q || postsUI.resource_id ? t('Измените фильтры или создайте новую публикацию.') : t('Создайте первую публикацию — черновик, отложенную или сразу.'), h('button', { class: 'btn primary', onclick: () => openEditor({ onSaved: () => load(true) }) }, t('Новый пост'))));
      if (offset < r.total) more.append(h('button', { class: 'btn', onclick: () => load(false) }, `${t('Показать ещё')} (${r.total - offset})`));
    }
    load(true);
  }

  function postCard(p, reload) {
    const locked = p.targets.some((x) => x.status === 'published' || x.status === 'publishing');
    const first = p.text.replace(/<[^>]+>/g, '').trim() || (p.image_url ? '🖼 ' + t('Изображение') : '—');
    return h('div', { class: 'card post' },
      h('div', { class: 'text' }, first),
      p.targets.map((x) => h('div', { class: 'target' },
        h('span', { class: 't-title' }, x.resource_title), MP.targetBadge(x.status),
        h('span', { class: 'small muted' }, x.status === 'published' ? fmtDateTime(x.published_at) : x.scheduled_at ? fmtDateTime(x.scheduled_at) : t('без даты')),
        h('span', { class: 'row right', style: 'gap:6px' },
          ['draft', 'scheduled', 'cancelled'].includes(x.status) ? h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/post-targets/${x.id}/publish-now`), t('Поставлено в очередь на публикацию'), reload) }, t('Опубликовать сейчас')) : null,
          ['draft', 'scheduled'].includes(x.status) ? h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/post-targets/${x.id}/cancel`), t('Отменено'), reload) }, t('Отменить')) : null,
          ['failed', 'unknown'].includes(x.status) ? h('button', { class: 'btn sm', onclick: async (e) => {
            if (x.status === 'unknown' && !(await confirmDialog(t('Telegram не подтвердил отправку. Возможно, сообщение уже опубликовано — проверьте канал.\nПовторная отправка может создать дубль. Повторить?'), { okText: t('Повторить') }))) return;
            act(e, () => api('POST', `/post-targets/${x.id}/retry`), t('Поставлено в очередь'), reload);
          } }, t('Повторить')) : null)),
      ).concat(p.targets.filter((x) => x.error && ['failed', 'unknown'].includes(x.status)).map((x) => h('div', { class: 'errtext' }, `${x.resource_title}: ${x.error}`))),
      h('div', { class: 'row' },
        h('button', { class: 'btn sm', disabled: locked, title: locked ? t('Опубликованный пост нельзя изменить — создайте копию') : '', onclick: () => openEditor({ post: p, onSaved: reload }) }, t('Изменить')),
        h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/posts/${p.id}/duplicate`), t('Копия создана как черновик'), reload) }, t('Копировать')),
        h('button', { class: 'btn sm', onclick: () => previewModal(p) }, t('Предпросмотр')),
        h('button', { class: 'btn sm danger right', onclick: async () => { if (await confirmDialog(t('Удалить пост из MarketPilot?') + (locked ? '\n' + t('Уже опубликованные сообщения в Telegram останутся.') : ''), { danger: true, okText: t('Удалить') })) { try { await api('DELETE', '/posts/' + p.id); toast(t('Пост удалён')); reload(); } catch (e) { fail(e); } } } }, t('Удалить'))));
  }
  function previewModal(p) {
    modal({ title: t('Предпросмотр'), body: MP.tgBubble(p.text, p.image_url), footer: (close) => h('button', { class: 'btn primary', onclick: close }, t('Закрыть')) });
  }

  // ---------------------------------------------------------------- editor
  async function openEditor({ post, date, onSaved }) {
    await loadResources();
    const tz = state.tz;
    const targets = post ? post.targets : [];
    const ed = {
      text: post ? post.text : '', image: post ? post.image_url || '' : '', imagePreview: '',
      ids: new Set(targets.map((x) => x.resource_id)), mode: 'draft', when: '',
    };
    const nextSlot = () => { const d = new Date(Date.now() + 3600e3); d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0); return MP.utcToInput(d.toISOString(), tz); };
    if (post) {
      const sched = targets.find((x) => x.status === 'scheduled');
      if (targets.length && targets.every((x) => x.status === 'draft')) ed.mode = 'draft';
      else { ed.mode = 'schedule'; ed.when = sched ? MP.utcToInput(sched.scheduled_at, tz) : nextSlot(); }
    } else if (date) { ed.mode = 'schedule'; ed.when = date + 'T10:00'; if (MP.zonedToUtc(ed.when, tz) < new Date()) ed.when = nextSlot(); }
    else { ed.when = nextSlot(); const act1 = activeResources(); if (act1.length === 1) ed.ids.add(act1[0].id); }

    const ta = h('textarea', { placeholder: t('Текст публикации. Поддерживается форматирование Telegram (HTML).'), oninput: (e) => { ed.text = e.target.value; refresh(); } });
    ta.value = ed.text;
    const counter = h('div', { class: 'counter' });
    const prev = h('div');
    const errbox = h('div', { class: 'note err', style: 'display:none' });
    const uploadStatus = h('div', { class: 'small muted' });
    const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', style: 'display:none' });
    const urlInput = h('input', { type: 'url', placeholder: 'https://…/image.jpg', value: ed.image.startsWith('upload:') ? '' : ed.image });
    const uploadButton = h('button', { class: 'btn sm', type: 'button', onclick: () => fileInput.click() }, 'Выбрать файл');
    const removeImageButton = h('button', { class: 'btn sm ghost', type: 'button', style: ed.image ? '' : 'display:none' }, 'Убрать изображение');
    const whenInput = h('input', { type: 'datetime-local', value: ed.when, oninput: (e) => (ed.when = e.target.value) });
    const whenField = h('div', { class: 'field' }, h('label', { class: 'f' }, `${t('Дата и время')} (${tz})`), whenInput);
    const saveBtn = h('button', { class: 'btn primary' });
    const refresh = () => {
      saveBtn.textContent = ed.mode === 'now' ? t('Опубликовать') : ed.mode === 'schedule' ? t('Запланировать') : t('Сохранить');
      const len = MP.visibleLength(ed.text), lim = ed.image.trim() ? 1024 : 4096;
      counter.textContent = `${len} / ${lim}`; counter.className = 'counter' + (len > lim ? ' over' : '');
      const imageSource = ed.imagePreview || (/^https?:\/\//i.test(ed.image.trim()) ? ed.image.trim() : '');
      clear(prev).append(ed.text.trim() || imageSource ? MP.tgBubble(ed.text, imageSource) : h('div', { class: 'muted small' }, t('Здесь появится предпросмотр поста')));
      removeImageButton.style.display = ed.image ? '' : 'none';
      whenField.style.display = ed.mode === 'schedule' ? '' : 'none';
    };
    fileInput.onchange = async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) { uploadStatus.className = 'note err'; uploadStatus.textContent = 'Файл больше 10 MiB'; return; }
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { uploadStatus.className = 'note err'; uploadStatus.textContent = 'Выберите JPEG, PNG или WebP'; return; }
      uploadButton.disabled = true; uploadStatus.className = 'small muted'; uploadStatus.textContent = 'Загрузка…';
      try {
        const uploaded = await MP.upload('/media', file);
        if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
        ed.image = uploaded.image_url; ed.imagePreview = URL.createObjectURL(file); urlInput.value = '';
        uploadStatus.className = 'note ok'; uploadStatus.textContent = `${uploaded.filename} · ${(uploaded.size / 1024 / 1024).toFixed(2)} MiB`;
        refresh();
      } catch (e) { uploadStatus.className = 'note err'; uploadStatus.textContent = e.message || 'Не удалось загрузить файл'; }
      finally { uploadButton.disabled = false; }
    };
    urlInput.oninput = () => {
      if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
      ed.imagePreview = ''; ed.image = urlInput.value.trim(); uploadStatus.textContent = ''; refresh();
    };
    removeImageButton.onclick = () => {
      if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
      ed.imagePreview = ''; ed.image = ''; urlInput.value = ''; uploadStatus.textContent = ''; refresh();
    };
    const wrap = (open, close) => { const s = ta.selectionStart, e = ta.selectionEnd; ta.value = ta.value.slice(0, s) + open + ta.value.slice(s, e) + close + ta.value.slice(e); ed.text = ta.value; ta.focus(); ta.setSelectionRange(s + open.length, e + open.length); refresh(); };
    const linkRow = h('div', { class: 'row', style: 'display:none;margin-bottom:8px' });
    const linkInput = h('input', { type: 'url', placeholder: 'https://…', style: 'flex:1;min-width:160px' });
    clear(linkRow).append(linkInput, h('button', { class: 'btn sm', onclick: () => { const u = linkInput.value.trim(); if (/^https?:\/\//i.test(u)) { wrap(`<a href="${u.replace(/"/g, '&quot;')}">`, '</a>'); linkRow.style.display = 'none'; linkInput.value = ''; } else toast(t('Введите ссылку, начинающуюся с http(s)://'), true); } }, t('Вставить')));
    const tb = h('div', { class: 'toolbar' },
      [['<b>', '</b>', 'B', 'font-weight:700'], ['<i>', '</i>', 'I', 'font-style:italic'], ['<u>', '</u>', 'U', 'text-decoration:underline'], ['<s>', '</s>', 'S', 'text-decoration:line-through'], ['<code>', '</code>', '</>', ''], ['<tg-spoiler>', '</tg-spoiler>', '◼', '']]
        .map(([o, c, l, st]) => h('button', { class: 'btn sm', type: 'button', style: st, title: o, onclick: () => wrap(o, c) }, l)),
      h('button', { class: 'btn sm', type: 'button', onclick: () => { linkRow.style.display = linkRow.style.display === 'none' ? 'flex' : 'none'; } }, '🔗'));

    // templates
    const tplSelect = h('select', {}, h('option', { value: '' }, t('Шаблоны') + '…'));
    let tpls = [];
    const loadTpls = async () => { try { tpls = (await api('GET', '/templates')).items; } catch (e) { tpls = []; } clear(tplSelect).append(h('option', { value: '' }, t('Шаблоны') + '…'), tpls.map((x) => h('option', { value: x.id }, `${x.name}${x.is_favorite ? ' ★' : ''}${x.category ? ` · ${x.category}` : ''}`))); };
    loadTpls();
    tplSelect.onchange = () => { const x = tpls.find((y) => String(y.id) === tplSelect.value); if (x) { ta.value = ed.text = x.text; refresh(); } };
    const tplName = h('input', { type: 'text', placeholder: t('Название шаблона'), style: 'flex:1;min-width:140px' });
    const tplCategory = h('select', {}, ['general', 'sales', 'daily', 'event', 'promo'].map((v) => h('option', { value: v }, v)));
    const tplFavorite = h('label', { class: 'row', style: 'gap:8px;align-items:center;white-space:nowrap' }, h('input', { type: 'checkbox' }), h('span', {}, '★ ' + t('Избранное')));
    const tplRow = h('div', { class: 'row', style: 'display:none;margin-top:6px;flex-wrap:wrap' },
      tplName, tplCategory, tplFavorite,
      h('button', { class: 'btn sm', onclick: async () => { try { await api('POST', '/templates', { name: tplName.value || t('Шаблон'), text: ed.text, category: tplCategory.value, is_favorite: tplFavorite.querySelector('input').checked, variables: (ed.text.match(/\{([a-zA-Z0-9_-]+)\}/g) || []).map((m) => m.slice(1, -1)) }); toast(t('Шаблон сохранён')); tplName.value = ''; tplCategory.value = 'general'; tplFavorite.querySelector('input').checked = false; tplRow.style.display = 'none'; loadTpls(); } catch (e) { fail(e); } } }, t('Сохранить')));

    const resList = h('div', { class: 'reslist' }, activeResources().length ? activeResources().map((r) => {
      const noRights = r.status !== 'active';
      return h('label', { class: noRights ? 'dis' : '' }, h('input', { type: 'checkbox', checked: ed.ids.has(r.id), onchange: (e) => (e.target.checked ? ed.ids.add(r.id) : ed.ids.delete(r.id)) }),
        h('span', {}, r.title), r.is_demo ? MP.demoBadge() : null, noRights ? MP.badge(t('нет прав на публикацию'), 'warn') : null);
    }) : h('div', { class: 'muted' }, t('Нет ресурсов. Подключите ресурс на вкладке «Ресурсы».')));

    const modeSeg = h('div', { class: 'seg', style: 'flex-wrap:wrap' });
    const drawMode = () => clear(modeSeg).append([['draft', 'Черновик (не публиковать)'], ['schedule', 'Запланировать'], ['now', 'Опубликовать сейчас']].map(([v, l]) => h('button', { type: 'button', class: ed.mode === v ? 'on' : '', onclick: () => { ed.mode = v; drawMode(); refresh(); } }, t(l))));
    drawMode();
    if (ed.image.startsWith('upload:')) {
      const mediaId = ed.image.slice('upload:'.length);
      api('GET', `/media/${mediaId}`).then((media) => {
        const binary = atob(media.data), bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
        ed.imagePreview = URL.createObjectURL(new Blob([bytes], { type: media.mime })); refresh();
      }).catch(() => { uploadStatus.className = 'note warn'; uploadStatus.textContent = 'Предпросмотр загруженного изображения недоступен.'; });
    }

    const body = h('div', { class: 'editor-grid' },
      h('div', {},
        h('div', { class: 'field' }, h('label', { class: 'f' }, t('Текст поста')), tb, linkRow, ta, counter,
          h('div', { class: 'row', style: 'margin-top:6px' }, tplSelect, h('button', { class: 'btn sm', type: 'button', onclick: () => { tplRow.style.display = tplRow.style.display === 'none' ? 'flex' : 'none'; } }, t('Сохранить как шаблон'))), tplRow),
        h('div', { class: 'field' }, h('label', { class: 'f' }, 'Изображение'), h('div', { class: 'row wrap' }, uploadButton, removeImageButton), fileInput,
          h('div', { class: 'small muted', style: 'margin:6px 0' }, 'С устройства: JPEG, PNG или WebP, до 10 MiB. С изображением подпись ограничена 1024 символами.'), uploadStatus,
          h('details', {}, h('summary', { class: 'small muted', style: 'cursor:pointer' }, 'Или указать ссылку'), urlInput)),
        h('div', { class: 'field' }, h('label', { class: 'f' }, t('Куда публиковать')), resList)),
      h('div', {},
        h('div', { class: 'field' }, h('label', { class: 'f' }, t('Когда')), modeSeg), whenField,
        h('div', { class: 'field' }, h('label', { class: 'f' }, t('Предпросмотр')), prev), errbox));
    refresh();

    modal({
      title: post ? t('Редактирование поста') : t('Новый пост'), wide: true, body,
      onClose: () => { if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview); },
      footer: (close) => [h('button', { class: 'btn', onclick: close }, t('Отмена')),
        (saveBtn.onclick = async (e) => {
          errbox.style.display = 'none';
          const payload = { text: ed.text, image_url: ed.image.trim() || null, resource_ids: [...ed.ids], mode: ed.mode };
          if (ed.mode === 'schedule') {
            if (!ed.when) { errbox.textContent = t('Укажите дату и время'); errbox.style.display = ''; return; }
            payload.scheduled_at = MP.zonedToUtc(ed.when, tz).toISOString();
          }
          await busy(e.currentTarget, async () => {
            try {
              await api(post ? 'PUT' : 'POST', post ? '/posts/' + post.id : '/posts', payload);
              toast(ed.mode === 'draft' ? t('Черновик сохранён') : ed.mode === 'now' ? t('Пост поставлен в очередь на публикацию') : t('Публикация запланирована'));
              close(); if (onSaved) onSaved();
            } catch (err) { errbox.textContent = err.message; errbox.style.display = ''; }
          });
        }, saveBtn)],
    });
  }
  MP.openEditor = openEditor;

  async function openPost(id, onChange) {
    try {
      const p = await api('GET', '/posts/' + id);
      if (p.targets.some((x) => x.status === 'published' || x.status === 'publishing')) {
        modal({ title: t('Публикация'), body: h('div', { class: 'stack' }, MP.tgBubble(p.text, p.image_url), p.targets.map((x) => h('div', { class: 'row' }, h('b', {}, x.resource_title), MP.targetBadge(x.status), h('span', { class: 'small muted' }, fmtDateTime(x.published_at || x.scheduled_at))))),
          footer: (close) => [h('button', { class: 'btn', onclick: async () => { try { await api('POST', `/posts/${p.id}/duplicate`); toast(t('Копия создана как черновик')); close(); onChange(); } catch (e) { fail(e); } } }, t('Копировать')), h('button', { class: 'btn primary', onclick: close }, t('Закрыть'))] });
      } else openEditor({ post: p, onSaved: onChange });
    } catch (e) { fail(e); }
  }

  // ---------------------------------------------------------------- calendar
  function renderCalendar(root) {
    const tz = state.tz;
    if (!postsUI.calCursor) postsUI.calCursor = MP.todayKey();
    const grid = h('div'); const title = h('div', { class: 'cal-title' });
    const dow = [t('Пн'), t('Вт'), t('Ср'), t('Чт'), t('Пт'), t('Сб'), t('Вс')];
    const modeSeg = h('div', { class: 'seg' });
    const drawMode = () => clear(modeSeg).append([['week', 'Неделя'], ['month', 'Месяц']].map(([v, l]) => h('button', { class: postsUI.calMode === v ? 'on' : '', onclick: () => { postsUI.calMode = v; drawMode(); load(); } }, t(l))));
    const shift = (dir) => {
      const c = postsUI.calCursor;
      if (postsUI.calMode === 'week') postsUI.calCursor = MP.addDays(c, 7 * dir);
      else { const [Y, M] = c.split('-').map(Number); const d = new Date(Date.UTC(Y, M - 1 + dir, 1)); postsUI.calCursor = d.toISOString().slice(0, 10); }
      load();
    };
    root.append(h('div', { class: 'cal-head' },
      h('button', { class: 'btn sm', onclick: () => shift(-1), 'aria-label': 'prev' }, '◀'), title, h('button', { class: 'btn sm', onclick: () => shift(1), 'aria-label': 'next' }, '▶'),
      h('button', { class: 'btn sm', onclick: () => { postsUI.calCursor = MP.todayKey(); load(); } }, t('Сегодня')), modeSeg,
      h('span', { class: 'right' }, resourceSelect(postsUI.resource_id, (v) => { postsUI.resource_id = v; load(); }))), grid,
      h('div', { class: 'row small muted', style: 'margin-top:10px' }, [['scheduled', 'Запланирован'], ['published', 'Опубликован'], ['failed', 'Ошибка']].map(([k, l]) => h('span', {}, h('span', { class: 'dot ' + (k === 'published' ? 'ok' : k === 'failed' ? 'bad' : 'blue'), style: 'display:inline-block;margin-right:4px' }), t(l)))));
    drawMode();

    async function load() {
      const c = postsUI.calCursor; let start, end, label;
      if (postsUI.calMode === 'week') { start = MP.addDays(c, -MP.weekdayOf(c)); end = MP.addDays(start, 7); label = `${fmtDay(start)} — ${fmtDay(MP.addDays(end, -1))}`; }
      else {
        const first = c.slice(0, 8) + '01'; start = MP.addDays(first, -MP.weekdayOf(first));
        const [Y, M] = c.split('-').map(Number); const nextFirst = new Date(Date.UTC(Y, M, 1)).toISOString().slice(0, 10);
        const lastDay = MP.addDays(nextFirst, -1); end = MP.addDays(lastDay, 7 - MP.weekdayOf(lastDay));
        label = new Intl.DateTimeFormat(state.lang === 'en' ? 'en-US' : 'ru-RU', { timeZone: 'UTC', month: 'long', year: 'numeric' }).format(new Date(Date.UTC(Y, M - 1, 1)));
      }
      title.textContent = label;
      const q = new URLSearchParams({ from: MP.zonedToUtc(start + 'T00:00', tz).toISOString(), to: MP.zonedToUtc(end + 'T00:00', tz).toISOString() });
      if (postsUI.resource_id) q.set('resource_id', postsUI.resource_id);
      let items;
      try { items = (await api('GET', '/targets?' + q)).items; } catch (e) { clear(grid).append(h('div', { class: 'note err' }, e.message)); return; }
      const byDay = {};
      items.forEach((x) => (byDay[MP.dayKey(x.scheduled_at, tz)] ||= []).push(x));
      const today = MP.todayKey(), onChange = load;
      const chip = (x) => h('button', { class: 'cal-item ' + x.status, title: `${x.resource_title}: ${x.text}`, onclick: () => openPost(x.post_id, onChange) }, `${fmtTime(x.scheduled_at)} ${x.text || x.resource_title}`);
      clear(grid);
      if (postsUI.calMode === 'week') {
        const wrapEl = h('div', { class: 'cal-week' });
        for (let i = 0; i < 7; i++) {
          const key = MP.addDays(start, i), list = byDay[key] || [];
          wrapEl.append(h('div', { class: 'cal-weekcol' + (key === today ? ' today' : '') }, h('div', { class: 'dh' }, dow[i] + ' ' + fmtDay(key)), list.map(chip), key >= today ? h('button', { class: 'btn sm ghost', onclick: () => openEditor({ date: key, onSaved: onChange }) }, '+ ' + t('Пост')) : null));
        }
        grid.append(wrapEl);
      } else {
        const g = h('div', { class: 'cal-grid' }, dow.map((d) => h('div', { class: 'cal-dow' }, d)));
        for (let key = start; key < end; key = MP.addDays(key, 1)) {
          const list = byDay[key] || [];
          g.append(h('div', { class: 'cal-cell' + (key.slice(0, 7) !== c.slice(0, 7) ? ' other' : '') + (key === today ? ' today' : '') },
            h('div', { class: 'num' }, +key.slice(8)), key >= today ? h('button', { class: 'add', title: t('Новый пост'), onclick: () => openEditor({ date: key, onSaved: onChange }) }, '+') : null,
            list.slice(0, 3).map(chip),
            list.length > 3 ? h('button', { class: 'cal-item', onclick: () => modal({ title: fmtDay(key), body: h('div', { class: 'stack' }, list.map(chip)), footer: (cl) => h('button', { class: 'btn primary', onclick: cl }, t('Закрыть')) }) }, `+${list.length - 3} ${t('ещё')}`) : null));
        }
        grid.append(g);
      }
    }
    load();
  }

  // ================================================================ ANALYTICS
  const anF = { days: 30, resource_id: '' };
  pages.analytics = async function (root) {
    await loadResources();
    const content = h('div'); const filters = h('div', { class: 'filters' });
    root.append(head(t('Аналитика'), t('Подписчики, публикации и активность'), null), filters, content);
    async function load() {
      clear(filters).append(periodSelect(anF.days, (v) => { anF.days = v; load(); }), resourceSelect(anF.resource_id, (v) => { anF.resource_id = v; load(); }));
      clear(content).append(h('div', { class: 'boot', style: 'height:200px' }, h('div', { class: 'spinner' })));
      let d;
      try { const q = new URLSearchParams({ days: anF.days }); if (anF.resource_id) q.set('resource_id', anF.resource_id); d = await api('GET', '/analytics?' + q); }
      catch (e) { clear(content).append(h('div', { class: 'note err' }, e.message)); return; }
      if (!d.table.length) { clear(content).append(emptyBox(t('Нет данных для аналитики'), t('Подключите ресурс или загрузите демо-данные.'), h('button', { class: 'btn primary', onclick: () => goto('#/resources') }, t('Ресурсы')), h('button', { class: 'btn', onclick: loadDemoData }, t('Загрузить демо-данные')))); return; }
      const g = d.growth, byRes = d.members_by_resource;
      const weekNames = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(t);
      clear(content).append(
        h('div', { class: 'grid kpis' },
          h('div', { class: 'card kpi' }, h('div', { class: 'label' }, t('Прирост подписчиков')), h('div', { class: 'value delta ' + (g.delta >= 0 ? 'up' : 'down') }, (g.delta >= 0 ? '+' : '') + fmtNum(g.delta)), h('div', { class: 'meta' }, (g.pct !== null ? `${g.pct}% · ` : '') + `${d.period_days} ${t('дн.')}`)),
          h('div', { class: 'card kpi' }, h('div', { class: 'label' }, t('Опубликовано')), h('div', { class: 'value' }, fmtNum(d.published_series.reduce((a, b) => a + b, 0))), h('div', { class: 'meta' }, `${d.period_days} ${t('дн.')}`)),
          h('div', { class: 'card kpi' }, h('div', { class: 'label' }, t('В среднем в день')), h('div', { class: 'value' }, (d.published_series.reduce((a, b) => a + b, 0) / d.period_days).toFixed(1)), h('div', { class: 'meta' }, t('публикаций')))),
        h('div', { class: 'card', style: 'margin-top:14px' }, h('h3', {}, t('Динамика подписчиков')),
          MP.lineChart({ labels: d.labels, series: byRes.length > 1 && byRes.length <= 6 && !anF.resource_id ? [{ name: t('Всего'), values: d.members_series, color: 'var(--text)' }, ...byRes.map((r) => ({ name: r.title, values: r.values }))] : [{ name: t('Подписчики'), values: d.members_series }] }),
          h('div', { class: 'small muted', style: 'margin-top:6px' }, t('Источник') + ': ' + d.source)),
        h('div', { class: 'grid cols2', style: 'margin-top:14px' },
          h('div', { class: 'card' }, h('h3', {}, t('Публикации по дням')), MP.barChart({ labels: d.labels, values: d.published_series })),
          h('div', { class: 'card' }, h('h3', {}, t('Время публикаций')), MP.labelBars({ labels: d.hours.map((_, i) => String(i)), values: d.hours }), h('h3', { style: 'margin-top:14px' }, t('Дни недели')), MP.labelBars({ labels: weekNames, values: d.weekdays, color: 'var(--c3)', height: 110 }))),
        h('div', { class: 'card', style: 'margin-top:14px' }, h('h3', {}, t('Сравнение ресурсов')), h('div', { class: 'tablewrap' }, h('table', {},
          h('thead', {}, h('tr', {}, [t('Название'), t('Тип'), t('Подписчики'), t('Прирост'), t('Опубликовано'), t('Ошибки'), t('Успешность')].map((x) => h('th', {}, x)))),
          h('tbody', {}, d.table.map((r) => h('tr', {}, h('td', {}, r.title, ' ', r.is_demo ? MP.demoBadge() : null), h('td', {}, t(MP.TYPES[r.type])), h('td', {}, fmtNum(r.members)),
            h('td', { class: r.delta === null ? '' : 'delta ' + (r.delta >= 0 ? 'up' : 'down') }, r.delta === null ? '—' : (r.delta >= 0 ? '+' : '') + fmtNum(r.delta)), h('td', {}, r.published), h('td', {}, r.failed + r.unknown), h('td', {}, r.success_rate === null ? '—' : r.success_rate + '%'))))))),
        d.group_activity ? h('div', { class: 'card', style: 'margin-top:14px' }, h('h3', {}, t('Активность групп')),
          MP.lineChart({ labels: d.labels, zeroBase: true, series: [{ name: t('Сообщения'), values: d.group_activity.messages }, { name: t('Вступления'), values: d.group_activity.joins }, { name: t('Выходы'), values: d.group_activity.leaves }] }),
          h('div', { class: 'small muted', style: 'margin-top:6px' }, t('Источник') + ': ' + d.group_activity.source)) : null,
        h('div', { class: 'grid cols2', style: 'margin-top:14px' },
          h('div', { class: 'card' }, h('h3', {}, t('Рекомендации')), d.tips.length ? d.tips.map((x) => h('div', { class: 'list-item' }, h('span', { class: 'dot blue' }), h('div', {}, x))) : h('div', { class: 'muted' }, t('Пока недостаточно данных для рекомендаций.'))),
          h('div', { class: 'card' }, h('h3', {}, t('Ограничения данных')), d.limitations.map((x) => h('div', { class: 'list-item' }, h('span', { class: 'dot warn' }), h('div', { class: 'small' }, x))))));
    }
    load();
  };

  // ================================================================ SETTINGS
  pages.settings = async function (root) {
    const u = (await api('GET', '/me'));
    state.user = u;
    const f = { first_name: u.first_name, language: u.language, timezone: u.timezone, notify: u.notify };
    const tzs = (typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : ['Europe/Moscow', 'Europe/Kiev', 'Europe/London', 'Europe/Berlin', 'Asia/Almaty', 'Asia/Dubai', 'Asia/Tokyo', 'America/New_York', 'America/Los_Angeles']).slice();
    if (!tzs.includes('UTC')) tzs.unshift('UTC');
    if (!tzs.includes(f.timezone)) tzs.unshift(f.timezone);
    const st = state.status.telegram;
    const theme = (() => { try { return localStorage.getItem('mp_theme') || 'auto'; } catch (e) { return 'auto'; } })();
    const demoCount = state.resources.filter((r) => r.is_demo).length || (await loadResources(), state.resources.filter((r) => r.is_demo).length);

    root.append(head(t('Настройки'), t('Профиль, язык, уведомления и данные')),
      h('div', { class: 'grid cols2' },
        h('div', { class: 'card stack' }, h('h3', {}, t('Профиль')),
          h('div', {}, h('label', { class: 'f' }, t('Имя')), h('input', { type: 'text', maxlength: 80, value: f.first_name, oninput: (e) => (f.first_name = e.target.value) })),
          h('div', {}, h('label', { class: 'f' }, t('Язык')), h('select', { onchange: (e) => (f.language = e.target.value) }, [['ru', 'Русский'], ['en', 'English']].map(([v, l]) => h('option', { value: v, selected: v === f.language }, l)))),
          h('div', {}, h('label', { class: 'f' }, t('Часовой пояс')), h('select', { onchange: (e) => (f.timezone = e.target.value) }, tzs.map((z) => h('option', { value: z, selected: z === f.timezone }, z)))),
          h('label', { class: 'row', style: 'cursor:pointer' }, h('input', { type: 'checkbox', style: 'width:auto;min-height:0', checked: f.notify, onchange: (e) => (f.notify = e.target.checked) }), t('Уведомления в Telegram (ошибки публикаций, потеря прав)')),
          h('div', { class: 'row' },
            h('button', { class: 'btn primary', onclick: async (e) => { await busy(e.currentTarget, async () => { try { const nu = await api('PUT', '/me', f); state.user = nu; state.lang = nu.language; state.tz = nu.timezone; toast(t('Настройки сохранены')); MP.render(); } catch (err) { fail(err); } }); } }, t('Сохранить')),
            h('button', { class: 'btn', onclick: async (e) => { await busy(e.currentTarget, async () => { try { const r = await api('POST', '/me/test-notification'); r.sent ? toast(t('Тестовое уведомление отправлено в Telegram')) : toast(r.reason, true); } catch (err) { fail(err); } }); } }, t('Отправить тест')))),
        h('div', { class: 'card stack' }, h('h3', {}, t('Тема оформления')),
          h('div', { class: 'seg' }, [['auto', 'Автоматически'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, l]) => h('button', { class: v === theme ? 'on' : '', onclick: () => { MP.setTheme(v); MP.render(); } }, t(l)))),
          h('h3', { style: 'margin-top:8px' }, t('Тариф')),
          h('div', {}, h('span', { class: 'badge blue' }, u.plan.toUpperCase()), ' ', h('span', { class: 'muted' }, `${u.resources_used} / ${u.resource_limit} ${t('ресурсов')}`)),
          h('div', { class: 'small muted' }, t('Во время бета-теста платёжный модуль не подключён: лимиты действуют, оплата не взимается.'))),
        h('div', { class: 'card stack' }, h('h3', {}, 'Telegram'),
          h('div', { class: 'row' }, MP.badge(st.connected ? t('Подключён') : st.configured ? t('Нет связи') : t('Не настроен'), st.connected ? 'ok' : 'warn'), st.username ? h('span', { class: 'muted' }, '@' + st.username) : null),
          st.error ? h('div', { class: 'note err' }, st.error) : null,
          st.connected ? h('div', { class: 'small muted' }, t('Бот получает события через long polling. Публичный HTTPS-адрес для этого не нужен.'))
            : h('div', { class: 'note warn' }, t('Демо-режим: чтобы подключить Telegram, создайте бота в @BotFather, впишите BOT_TOKEN в файл .env и перезапустите приложение.'))),
        h('div', { class: 'card stack' }, h('h3', {}, t('Демо-данные')),
          h('div', { class: 'small muted' }, t('Демо-ресурсы помечены DEMO: публикации в них имитируются, в Telegram ничего не уходит.')),
          h('div', { class: 'row' },
            u.is_demo ? h('button', { class: 'btn', onclick: async (e) => { if (await confirmDialog(t('Сбросить все данные демо-аккаунта к исходным?'))) await busy(e.currentTarget, async () => { try { await api('POST', '/me/reset-demo'); toast(t('Демо-данные сброшены')); MP.render(); } catch (err) { fail(err); } }); } }, t('Сбросить демо-данные'))
              : demoCount ? h('button', { class: 'btn', onclick: async (e) => { if (await confirmDialog(t('Убрать демо-ресурсы и связанные с ними публикации?'), { danger: true })) await busy(e.currentTarget, async () => { try { await api('DELETE', '/me/demo-data'); toast(t('Демо-данные удалены')); MP.render(); } catch (err) { fail(err); } }); } }, t('Убрать демо-данные'))
                : h('button', { class: 'btn', onclick: loadDemoData }, t('Загрузить демо-данные'))))),
      h('div', { class: 'card stack', style: 'margin-top:14px;border-color:var(--bad-soft)' }, h('h3', {}, t('Опасная зона')),
        h('div', { class: 'small muted' }, t('Удаление аккаунта безвозвратно стирает ваши ресурсы, публикации, шаблоны и историю в MarketPilot. Сообщения в Telegram не затрагиваются.')),
        h('div', { class: 'row' }, h('button', { class: 'btn danger', onclick: async () => { if (await confirmDialog(t('Удалить аккаунт и все данные безвозвратно?'), { danger: true, okText: t('Удалить аккаунт') })) { try { await api('DELETE', '/me'); MP.onUnauthorized(); } catch (e) { fail(e); } } } }, t('Удалить аккаунт')), h('button', { class: 'btn', onclick: MP.logout }, t('Выйти')))));
  };
})();
