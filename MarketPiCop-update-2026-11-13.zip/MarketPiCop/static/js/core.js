/* MarketPilot frontend core: DOM helper, API, i18n, time zones, modals, charts. Classic script, global `MP`. */
(function () {
  'use strict';
  const MP = (window.MP = { state: { user: null, status: null, resources: [], workspaces: [], workspaceId: null, lang: 'ru', tz: 'Europe/Moscow' } });

  // Element.append() natively stringifies arrays and null. Make it flatten arrays and skip null/false, like h() does.
  const nativeAppend = Element.prototype.append;
  Element.prototype.append = function (...items) {
    const out = [];
    (function flat(list) {
      for (const c of list) {
        if (c === null || c === undefined || c === false) continue;
        if (Array.isArray(c)) flat(c); else out.push(c);
      }
    })(items);
    return nativeAppend.apply(this, out);
  };

  // ---------------------------------------------------------------- DOM
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'selected') el[k] = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
    (function add(list) {
      for (const c of list) {
        if (c === null || c === undefined || c === false) continue;
        if (Array.isArray(c)) add(c);
        else el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
      }
    })(kids);
    return el;
  }
  const $ = (sel, root) => (root || document).querySelector(sel);
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
  function svgEl(tag, attrs, ...kids) {
    const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [k, v] of Object.entries(attrs || {})) if (v !== null && v !== undefined) el.setAttribute(k, v);
    kids.forEach((c) => c && el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c));
    return el;
  }
  const ICONS = {
    dashboard: 'M3 12 12 3l9 9M5 10v10h5v-6h4v6h5V10',
    resources: 'M4 6h16M4 12h16M4 18h10',
    posts: 'M4 5h16v11H8l-4 4zM8 9h8M8 12h5',
    analytics: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
    settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
    plus: 'M12 5v14M5 12h14',
  };
  function icon(name) {
    return svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }, svgEl('path', { d: ICONS[name] }));
  }

  // ---------------------------------------------------------------- i18n (keys are the Russian strings)
  const EN = {
    'Дашборд': 'Dashboard', 'Ресурсы': 'Resources', 'Публикации': 'Posts', 'Аналитика': 'Analytics', 'Настройки': 'Settings',
    'Войти через Telegram': 'Sign in with Telegram', 'Попробовать демо': 'Try the demo', 'Выйти': 'Log out',
    'Подключить ресурс': 'Connect a resource', 'Новый пост': 'New post', 'Сохранить': 'Save', 'Отмена': 'Cancel',
    'Закрыть': 'Close', 'Удалить': 'Delete', 'Копировать': 'Duplicate', 'Изменить': 'Edit', 'Период': 'Period',
    'Все ресурсы': 'All resources', 'Каналы': 'Channels', 'Группы': 'Groups', 'Подписчики': 'Members',
    'Опубликовано': 'Published', 'Запланировано': 'Scheduled', 'Требует внимания': 'Needs attention',
    'Последние события': 'Recent events', 'Ближайшие публикации': 'Upcoming posts', 'Черновик': 'Draft',
    'Отправляется': 'Sending', 'Ошибка': 'Failed', 'Отменён': 'Cancelled', 'Не подтверждён': 'Unconfirmed',
    'Календарь': 'Calendar', 'Список': 'List', 'Неделя': 'Week', 'Месяц': 'Month', 'Сегодня': 'Today',
    'Язык': 'Language', 'Часовой пояс': 'Time zone', 'Уведомления в Telegram': 'Telegram notifications',
    'Тариф': 'Plan', 'Тема': 'Theme', 'Автоматически': 'Auto', 'Светлая': 'Light', 'Тёмная': 'Dark',
    'Подключён': 'Connected', 'Не хватает прав': 'Missing rights', 'Отключён': 'Disconnected',
    'Проверить права': 'Check rights', 'Отключить': 'Disconnect', 'Профиль': 'Profile', 'Имя': 'Name',
    'ДЕМО-РЕЖИМ': 'DEMO MODE', 'Опасная зона': 'Danger zone', 'Удалить аккаунт': 'Delete account',
    'Черновик (не публиковать)': 'Draft (do not publish)', 'Запланировать': 'Schedule', 'Опубликовать сейчас': 'Publish now',
    'Предпросмотр': 'Preview', 'Шаблоны': 'Templates', 'Текст поста': 'Post text', 'Изображение (URL)': 'Image (URL)',
    'Сообщение': 'Message', 'Повторить': 'Retry', 'Отменить': 'Cancel', 'Поиск': 'Search', 'Все статусы': 'All statuses',
    'Все типы': 'All types', 'Загрузка…': 'Loading…', 'Ничего не найдено': 'Nothing found',
    'Динамика подписчиков': 'Members over time', 'Публикации по дням': 'Posts per day', 'Сравнение ресурсов': 'Resource comparison',
    'Время публикаций': 'Publishing hours', 'Дни недели': 'Weekdays', 'Активность групп': 'Group activity',
    'Рекомендации': 'Tips', 'Ограничения данных': 'Data limitations', 'Название': 'Title', 'Тип': 'Type',
    'Успешность': 'Success rate', 'Сейчас': 'Now', 'Принять': 'OK', 'Добавить демо-ресурс': 'Add demo resource',
    'Показать': 'Show', 'Сбросить демо-данные': 'Reset demo data', 'Загрузить демо-данные': 'Load demo data',
    'Убрать демо-данные': 'Remove demo data', 'Отправить тест': 'Send test', 'Пн': 'Mon', 'Вт': 'Tue', 'Ср': 'Wed',
    'Чт': 'Thu', 'Пт': 'Fri', 'Сб': 'Sat', 'Вс': 'Sun', 'Черновики': 'Drafts', 'Подключить': 'Connect',
    'Работает в демо-режиме: Telegram API не подключён': 'Running in demo mode: Telegram API is not connected',
    'Подписчики и динамика строятся по снимкам getChatMemberCount.': 'Members and growth are built from getChatMemberCount snapshots.',
  };
  function t(ru) { return MP.state.lang === 'en' && EN[ru] ? EN[ru] : ru; }

  // ---------------------------------------------------------------- formatting & time zones
  const loc = () => (MP.state.lang === 'en' ? 'en-US' : 'ru-RU');
  const fmtNum = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString(loc()));
  function tzParts(date, tz) {
    const f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const p = {};
    f.formatToParts(date).forEach((x) => (p[x.type] = x.value));
    return p;
  }
  function tzOffsetMs(date, tz) {
    const p = tzParts(date, tz);
    return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - Math.floor(date.getTime() / 1000) * 1000;
  }
  /** 'YYYY-MM-DDTHH:MM' interpreted in time zone `tz` -> Date (UTC instant). */
  function zonedToUtc(str, tz) {
    const [d, tm] = str.split('T');
    const [Y, M, D] = d.split('-').map(Number);
    const [hh, mm] = tm.split(':').map(Number);
    const guess = Date.UTC(Y, M - 1, D, hh, mm);
    let res = guess - tzOffsetMs(new Date(guess), tz);
    res = guess - tzOffsetMs(new Date(res), tz);
    return new Date(res);
  }
  function utcToInput(iso, tz) {
    const p = tzParts(new Date(iso), tz);
    return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
  }
  function dayKey(iso, tz) {
    const p = tzParts(new Date(iso), tz);
    return `${p.year}-${p.month}-${p.day}`;
  }
  function todayKey() { return dayKey(new Date().toISOString(), MP.state.tz); }
  function fmtDateTime(iso) {
    if (!iso) return '—';
    return new Intl.DateTimeFormat(loc(), { timeZone: MP.state.tz, day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
  }
  function fmtTime(iso) {
    return new Intl.DateTimeFormat(loc(), { timeZone: MP.state.tz, hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
  }
  function fmtDay(key) {
    const [Y, M, D] = key.split('-').map(Number);
    return new Intl.DateTimeFormat(loc(), { timeZone: 'UTC', day: 'numeric', month: 'short' }).format(new Date(Date.UTC(Y, M - 1, D)));
  }
  function ago(iso) {
    if (!iso) return '—';
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 90) return MP.state.lang === 'en' ? 'just now' : 'только что';
    if (s < 3600) return Math.round(s / 60) + (MP.state.lang === 'en' ? ' min ago' : ' мин назад');
    if (s < 86400) return Math.round(s / 3600) + (MP.state.lang === 'en' ? ' h ago' : ' ч назад');
    return Math.round(s / 86400) + (MP.state.lang === 'en' ? ' d ago' : ' дн назад');
  }
  /** Pure calendar arithmetic on 'YYYY-MM-DD' keys (no time zones involved). */
  function addDays(key, n) {
    const [Y, M, D] = key.split('-').map(Number);
    const d = new Date(Date.UTC(Y, M - 1, D + n));
    return d.toISOString().slice(0, 10);
  }
  const weekdayOf = (key) => (new Date(key + 'T00:00:00Z').getUTCDay() + 6) % 7; // Mon=0

  // ---------------------------------------------------------------- API
  class ApiError extends Error {
    constructor(status, code, message) { super(message || code); this.status = status; this.code = code; }
  }
  async function api(method, path, body) {
    let res;
    try {
      res = await fetch('/api/v1' + path, {
        method, credentials: 'same-origin',
        headers: Object.assign(body !== undefined ? { 'Content-Type': 'application/json' } : {},
          MP.token ? { Authorization: 'Bearer ' + MP.token } : {},
          MP.state.workspaceId ? { 'X-Workspace-ID': String(MP.state.workspaceId) } : {}),
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (e) {
      throw new ApiError(0, 'network', 'Нет связи с сервером MarketPilot');
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* empty */ }
    if (!res.ok) {
      if (res.status === 401 && MP.onUnauthorized && !path.startsWith('/auth/')) MP.onUnauthorized();
      throw new ApiError(res.status, (data && data.error) || 'error', (data && data.message) || 'Ошибка ' + res.status);
    }
    return data;
  }
  async function upload(path, file) {
    let response;
    try {
      response = await fetch('/api/v1' + path, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': file.type, 'X-File-Name': encodeURIComponent(file.name),
          ...(MP.token ? { Authorization: 'Bearer ' + MP.token } : {}),
          ...(MP.state.workspaceId ? { 'X-Workspace-ID': String(MP.state.workspaceId) } : {}) },
        body: file,
      });
    } catch (e) {
      throw new ApiError(0, 'network', 'Не удалось загрузить файл');
    }
    let data = null;
    try { data = await response.json(); } catch (e) { /* empty */ }
    if (!response.ok) throw new ApiError(response.status, (data && data.error) || 'error', (data && data.message) || 'Ошибка загрузки');
    return data;
  }

  // ---------------------------------------------------------------- toasts, modals
  function toast(msg, isErr) {
    const el = h('div', { class: 'toast' + (isErr ? ' err' : ''), role: 'status' }, msg);
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), isErr ? 6000 : 3200);
  }
  const fail = (e) => toast(e && e.message ? e.message : String(e), true);

  function modal({ title, body, footer, wide, onClose }) {
    const overlay = h('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true' });
    const close = () => {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      if (onClose) onClose();
    };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    const box = h('div', { class: 'modal' + (wide ? ' wide' : '') },
      h('div', { class: 'modal-head' }, h('h2', {}, title), h('button', { class: 'btn ghost sm right', onclick: close, 'aria-label': t('Закрыть') }, '✕')),
      h('div', { class: 'modal-body' }, body),
      footer ? h('div', { class: 'modal-foot' }, typeof footer === 'function' ? footer(close) : footer) : null);
    overlay.appendChild(box);
    overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    document.body.appendChild(overlay);
    return { close, el: box };
  }
  function confirmDialog(message, { okText, danger } = {}) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (v, close) => { if (!done) { done = true; resolve(v); } close(); };
      modal({
        title: t('Подтвердите действие'), body: h('p', { style: 'margin:0;white-space:pre-line' }, message),
        footer: (close) => [
          h('button', { class: 'btn', onclick: () => finish(false, close) }, t('Отмена')),
          h('button', { class: 'btn ' + (danger ? 'danger solid' : 'primary'), onclick: () => finish(true, close) }, okText || t('Принять')),
        ],
        onClose: () => { if (!done) { done = true; resolve(false); } },
      });
    });
  }
  async function busy(btn, fn) {
    if (btn) btn.disabled = true;
    try { return await fn(); } finally { if (btn) btn.disabled = false; }
  }

  // ---------------------------------------------------------------- badges & labels
  const TARGET_STATUS = {
    draft: ['Черновик', ''], scheduled: ['Запланирован', 'blue'], publishing: ['Отправляется', 'warn'],
    published: ['Опубликован', 'ok'], failed: ['Ошибка', 'bad'], cancelled: ['Отменён', ''], unknown: ['Не подтверждён', 'warn'],
  };
  const RES_STATUS = { active: ['Подключён', 'ok'], missing_rights: ['Не хватает прав', 'warn'], disconnected: ['Отключён', ''], pending: ['Ожидает', ''] };
  const CAPS = { publish: 'Публикация', edit_messages: 'Редактирование', delete_messages: 'Удаление сообщений', restrict_members: 'Ограничение участников', pin_messages: 'Закрепление' };
  const RIGHTS = { administrator: 'права администратора', can_post_messages: 'публиковать сообщения', can_edit_messages: 'редактировать сообщения', can_delete_messages: 'удалять сообщения', can_restrict_members: 'ограничивать участников', can_pin_messages: 'закреплять сообщения' };
  const TYPES = { channel: 'Канал', group: 'Группа', supergroup: 'Супергруппа' };
  const badge = (text, kind) => h('span', { class: 'badge ' + (kind || '') }, text);
  const targetBadge = (s) => { const [l, k] = TARGET_STATUS[s] || [s, '']; return badge(t(l), k); };
  const resBadge = (s) => { const [l, k] = RES_STATUS[s] || [s, '']; return badge(t(l), k); };
  const demoBadge = () => badge('DEMO', 'demo');

  // ---------------------------------------------------------------- Telegram-flavoured HTML preview (XSS-safe: builds DOM nodes)
  const TAGMAP = { b: 'b', strong: 'b', i: 'i', em: 'i', u: 'u', ins: 'u', s: 's', strike: 's', del: 's', code: 'code', pre: 'pre', blockquote: 'blockquote', 'tg-spoiler': 'spoiler', a: 'a', span: 'span' };
  function decodeEntities(s) { return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&'); }
  function visibleLength(text) { return decodeEntities(text.replace(/<[^>]*>/g, '')).length; }
  function renderTg(text) {
    const root = h('div'); const stack = [root];
    const top = () => stack[stack.length - 1];
    const re = /<(\/?)([a-zA-Z-]+)([^>]*)>/g;
    let last = 0, m;
    const pushText = (s) => { if (s) top().appendChild(document.createTextNode(decodeEntities(s))); };
    while ((m = re.exec(text))) {
      pushText(text.slice(last, m.index)); last = re.lastIndex;
      const tag = m[2].toLowerCase(), mapped = TAGMAP[tag];
      if (!mapped) { pushText(m[0]); continue; }
      if (m[1]) { if (stack.length > 1) stack.pop(); continue; }
      let el;
      if (mapped === 'a') {
        const href = /href\s*=\s*"([^"]*)"/i.exec(m[3]) || /href\s*=\s*'([^']*)'/i.exec(m[3]);
        const url = href ? decodeEntities(href[1]) : '';
        el = h('a', { href: /^(https?:|tg:)/i.test(url) ? url : '#', target: '_blank', rel: 'noopener noreferrer' });
      } else if (mapped === 'spoiler' || (mapped === 'span' && /tg-spoiler/.test(m[3]))) {
        el = h('span', { class: 'spoiler', onclick: (e) => e.currentTarget.classList.toggle('open') });
      } else el = h(mapped === 'span' ? 'span' : mapped);
      top().appendChild(el); stack.push(el);
    }
    pushText(text.slice(last));
    return root;
  }
  function tgBubble(text, imageUrl) {
    const b = h('div', { class: 'tg-bubble' });
    if (imageUrl) b.appendChild(h('img', { src: imageUrl, alt: '', referrerpolicy: 'no-referrer', onerror: (e) => e.target.replaceWith(h('div', { class: 'note warn' }, t('Изображение не загрузилось по этому адресу'))) }));
    b.appendChild(renderTg(text || ''));
    return b;
  }

  // ---------------------------------------------------------------- charts (SVG, no libraries)
  const COLORS = ['var(--c1)', 'var(--c2)', 'var(--c3)', 'var(--c4)', 'var(--c5)', 'var(--c6)'];
  const compact = (n) => (Math.abs(n) >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : Math.abs(n) >= 1e4 ? Math.round(n / 1e3) + 'k' : Math.abs(n) >= 1e3 ? (n / 1e3).toFixed(1) + 'k' : String(Math.round(n)));
  function niceMax(v) {
    if (v <= 0) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
  }
  function chartFrame(W, H, ml, mr, mt, mb, n, labels, tooltipFor, yMin, yMax, xAt) {
    const wrap = h('div', { class: 'chart' });
    const svg = svgEl('svg', { viewBox: `0 0 ${W} ${H}`, role: 'img' });
    const grid = svgEl('g', { class: 'grid' });
    for (let i = 0; i <= 4; i++) {
      const y = mt + ((H - mt - mb) * i) / 4;
      const val = yMax - ((yMax - yMin) * i) / 4;
      grid.appendChild(svgEl('line', { x1: ml, x2: W - mr, y1: y, y2: y }));
      grid.appendChild(svgEl('text', { x: ml - 6, y: y + 4, 'text-anchor': 'end' }, compact(val)));
    }
    svg.appendChild(grid);
    const step = Math.max(1, Math.ceil(n / 6));
    for (let i = 0; i < n; i += step) svg.appendChild(svgEl('text', { x: xAt(i), y: H - 8, 'text-anchor': 'middle' }, fmtDay(labels[i])));
    const tip = h('div', { class: 'tip', style: 'display:none' });
    const guide = svgEl('line', { y1: mt, y2: H - mb, stroke: 'var(--muted)', 'stroke-dasharray': '3 3', style: 'display:none' });
    svg.appendChild(guide);
    wrap.append(svg, tip);
    const move = (e) => {
      const r = svg.getBoundingClientRect();
      const px = ((e.clientX - r.left) / r.width) * W;
      let best = 0, bd = 1e9;
      for (let i = 0; i < n; i++) { const d = Math.abs(xAt(i) - px); if (d < bd) { bd = d; best = i; } }
      guide.setAttribute('x1', xAt(best)); guide.setAttribute('x2', xAt(best)); guide.style.display = '';
      clear(tip).append(...tooltipFor(best));
      tip.style.display = ''; tip.style.left = (xAt(best) / W) * r.width + 'px'; tip.style.top = '8px';
    };
    svg.addEventListener('pointermove', move);
    svg.addEventListener('pointerleave', () => { tip.style.display = 'none'; guide.style.display = 'none'; });
    return { wrap, svg };
  }
  function lineChart({ labels, series, height = 230, zeroBase = false }) {
    const W = 720, H = height, ml = 44, mr = 10, mt = 10, mb = 26, n = labels.length;
    const vals = series.flatMap((s) => s.values.filter((v) => v !== null && v !== undefined));
    if (!vals.length) return h('div', { class: 'empty' }, t('Недостаточно данных для графика'));
    let lo = zeroBase ? 0 : Math.min(...vals), hi = Math.max(...vals);
    if (!zeroBase) { const pad = (hi - lo) * 0.08 || Math.max(1, hi * 0.02); lo -= pad; hi += pad; if (lo < 0 && Math.min(...vals) >= 0) lo = 0; }
    else hi = niceMax(hi);
    const xAt = (i) => ml + (n === 1 ? (W - ml - mr) / 2 : ((W - ml - mr) * i) / (n - 1));
    const yAt = (v) => mt + (H - mt - mb) * (1 - (v - lo) / (hi - lo || 1));
    const { wrap, svg } = chartFrame(W, H, ml, mr, mt, mb, n, labels, (i) => [
      h('b', {}, fmtDay(labels[i])), ...series.map((s, k) => h('div', {}, h('span', { style: `color:${s.color || COLORS[k % 6]}` }, '● '), s.name ? s.name + ': ' : '', s.values[i] === null || s.values[i] === undefined ? '—' : fmtNum(s.values[i]))),
    ], lo, hi, xAt);
    series.forEach((s, k) => {
      const color = s.color || COLORS[k % COLORS.length];
      let d = '', pen = false;
      s.values.forEach((v, i) => { if (v === null || v === undefined) { pen = false; return; } d += (pen ? 'L' : 'M') + xAt(i).toFixed(1) + ' ' + yAt(v).toFixed(1); pen = true; });
      svg.insertBefore(svgEl('path', { d, fill: 'none', stroke: color, 'stroke-width': 2.2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }), svg.lastChild);
    });
    if (series.length > 1) wrap.appendChild(h('div', { class: 'legend' }, series.map((s, k) => h('span', {}, h('i', { style: `background:${s.color || COLORS[k % COLORS.length]}` }), s.name))));
    return wrap;
  }
  function barChart({ labels, values, height = 200, color = 'var(--c1)', labelFmt }) {
    const W = 720, H = height, ml = 44, mr = 10, mt = 10, mb = 26, n = labels.length;
    const hi = Math.max(4, niceMax(Math.max(0, ...values))); // >=4 keeps integer ticks for small counts
    const slot = (W - ml - mr) / n, bw = Math.max(2, slot * 0.68);
    const xAt = (i) => ml + slot * i + slot / 2;
    const { wrap, svg } = chartFrame(W, H, ml, mr, mt, mb, n, labels.map((l) => l), (i) => [h('b', {}, labelFmt ? labelFmt(labels[i]) : fmtDay(labels[i])), h('div', {}, fmtNum(values[i]))], 0, hi, xAt);
    values.forEach((v, i) => {
      const bh = (H - mt - mb) * (v / hi);
      svg.insertBefore(svgEl('rect', { x: xAt(i) - bw / 2, y: H - mb - bh, width: bw, height: Math.max(0, bh), rx: 2, fill: color }), svg.lastChild);
    });
    return wrap;
  }
  /** Histogram with plain text labels on the x axis (hours / weekdays). */
  function labelBars({ labels, values, color = 'var(--c2)', height = 150 }) {
    const hi = Math.max(1, ...values);
    return h('div', { class: 'chart' }, h('div', { style: `display:flex;align-items:flex-end;gap:3px;height:${height}px` },
      values.map((v, i) => h('div', { title: `${labels[i]}: ${v}`, style: 'flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;min-width:0' },
        h('div', { class: 'small muted' }, v || ''),
        h('div', { style: `width:100%;max-width:26px;border-radius:4px 4px 0 0;background:${color};height:${Math.max(v ? 3 : 0, (v / hi) * (height - 34))}px` })))),
      h('div', { style: 'display:flex;gap:3px;margin-top:4px' }, labels.map((l) => h('div', { class: 'small muted', style: 'flex:1;text-align:center;font-size:10.5px;min-width:0;overflow:hidden' }, l))));
  }

  Object.assign(MP, {
    h, $, clear, svgEl, icon, t, fmtNum, tzParts, zonedToUtc, utcToInput, dayKey, todayKey, fmtDateTime, fmtTime, fmtDay, ago, addDays, weekdayOf,
    api, upload, ApiError, toast, fail, modal, confirmDialog, busy, badge, targetBadge, resBadge, demoBadge, TARGET_STATUS, RES_STATUS, CAPS, RIGHTS, TYPES,
    renderTg, tgBubble, visibleLength, lineChart, barChart, labelBars, COLORS,
  });
})();
