/* Thin, defensive bridge to the Telegram WebApp SDK. Every call is feature-checked: older clients lack newer methods.
   If the SDK script is blocked, initData is recovered from the URL launch parameters (#tgWebAppData=...). */
(function () {
  'use strict';
  const wa = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;

  function hashParam(name) {
    try { return new URLSearchParams(location.hash.replace(/^#/, '')).get(name) || ''; } catch (e) { return ''; }
  }
  const initData = (wa && wa.initData) || hashParam('tgWebAppData');
  const inTelegram = !!initData;
  const atLeast = (v) => { try { return wa && wa.isVersionAtLeast ? wa.isVersionAtLeast(v) : false; } catch (e) { return false; } };
  const safe = (fn) => { try { return fn(); } catch (e) { return undefined; } };

  let hapticsOn = true;
  const TG = {
    wa, initData, inTelegram,
    platform: (wa && wa.platform) || 'unknown',
    user: safe(() => wa.initDataUnsafe.user) || null, // display only: never trusted for auth (server verifies initData)
    startParam: safe(() => wa.initDataUnsafe.start_param) || hashParam('tgWebAppStartParam') || '',

    init() {
      if (!wa) return;
      safe(() => wa.ready());                         // tell Telegram the app is ready (hides the loading placeholder)
      safe(() => wa.expand());                        // use the full height
      if (atLeast('7.7')) safe(() => wa.disableVerticalSwipes()); // keep swipe-down from closing the app mid-scroll
      this.applyTheme();
      safe(() => wa.onEvent('themeChanged', () => this.applyTheme()));
      safe(() => wa.onEvent('viewportChanged', () => this.syncViewport()));
      this.syncViewport();
    },
    applyTheme() {
      if (!wa) return;
      const root = document.documentElement;
      root.dataset.scheme = wa.colorScheme === 'dark' ? 'dark' : 'light';
      const p = wa.themeParams || {};
      // the SDK also exposes --tg-theme-* CSS variables; set them ourselves too for clients where it does not
      Object.entries(p).forEach(([k, v]) => root.style.setProperty('--tg-theme-' + k.replace(/_/g, '-'), v));
      const bg = p.secondary_bg_color || p.bg_color;
      if (bg && atLeast('6.1')) { safe(() => wa.setHeaderColor(bg)); safe(() => wa.setBackgroundColor(bg)); }
      if (atLeast('7.10') && p.bottom_bar_bg_color) safe(() => wa.setBottomBarColor(p.bottom_bar_bg_color));
    },
    syncViewport() {
      const h = wa && (wa.viewportStableHeight || wa.viewportHeight);
      if (h) document.documentElement.style.setProperty('--vh', h + 'px');
    },
    setHaptics(on) { hapticsOn = !!on; },
    /** kind: 'light'|'medium'|'heavy' (impact) | 'success'|'warning'|'error' (notification) | 'select' */
    haptic(kind = 'light') {
      if (!hapticsOn || !wa || !atLeast('6.1') || !wa.HapticFeedback) return;
      safe(() => {
        if (['success', 'warning', 'error'].includes(kind)) wa.HapticFeedback.notificationOccurred(kind);
        else if (kind === 'select') wa.HapticFeedback.selectionChanged();
        else wa.HapticFeedback.impactOccurred(kind);
      });
    },
    // ---- back button
    _back: null,
    showBack(handler) {
      if (!wa || !atLeast('6.1') || !wa.BackButton) return;
      this.hideBack();
      this._back = handler;
      safe(() => { wa.BackButton.onClick(handler); wa.BackButton.show(); });
    },
    hideBack() {
      if (!wa || !wa.BackButton) return;
      safe(() => { if (this._back) wa.BackButton.offClick(this._back); wa.BackButton.hide(); });
      this._back = null;
    },
    // ---- main button (the big bottom button); returns false when unavailable so the page can render its own
    _main: null,
    showMain(text, handler, { loading = false, disabled = false } = {}) {
      if (!wa || !atLeast('6.0') || !wa.MainButton) return false;
      this.hideMain();
      this._main = handler;
      safe(() => {
        wa.MainButton.setParams({ text, is_visible: true, is_active: !disabled });
        wa.MainButton.onClick(handler);
        loading ? wa.MainButton.showProgress(false) : wa.MainButton.hideProgress();
      });
      return true;
    },
    setMainBusy(on) { if (wa && wa.MainButton) safe(() => (on ? wa.MainButton.showProgress(false) : wa.MainButton.hideProgress())); },
    hideMain() {
      if (!wa || !wa.MainButton) return;
      safe(() => { if (this._main) wa.MainButton.offClick(this._main); wa.MainButton.hideProgress(); wa.MainButton.hide(); });
      this._main = null;
    },
    /** Native confirm dialog (Bot API 6.2+) with a graceful fallback to the page's own dialog. */
    confirm(message) {
      return new Promise((resolve) => {
        if (wa && atLeast('6.2') && wa.showConfirm) safe(() => wa.showConfirm(message, (ok) => resolve(!!ok)));
        else resolve(window.confirm(message));
      });
    },
    openLink(url) {
      if (wa && wa.openLink) safe(() => wa.openLink(url)); else window.open(url, '_blank', 'noopener');
    },
    openTelegramLink(url) {
      if (wa && wa.openTelegramLink) safe(() => wa.openTelegramLink(url)); else window.open(url, '_blank', 'noopener');
    },
    copy(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(() => true, () => false);
      return Promise.resolve(false);
    },
    close() { if (wa && wa.close) safe(() => wa.close()); },
  };
  window.TG = TG;
})();
