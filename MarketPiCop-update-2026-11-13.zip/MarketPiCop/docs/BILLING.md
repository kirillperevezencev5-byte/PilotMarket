# YooKassa billing

## Scope

Community plans are sold in RUB only. Telegram Stars are disabled until an official automatic seller-payout path is available. Both public and private groups/supergroups are supported. Group membership is not paywalled: in public groups anyone can join, and payment grants only the plan's configured member privileges. The bot must be an administrator with member-restriction rights; invite rights are needed only to send an invite for private groups.

A buyer explicitly opts in to auto-renewal at checkout. It is off by default. The scheduler charges the saved YooKassa payment method at the subscription end date, sends a notice up to three days before renewal, and disables renewal after a provider-declined charge. A full refund is requested by the buyer, approved or rejected by the community owner, and tariff privileges are revoked only after YooKassa confirms the refund. Members of public groups stay in the group and return to its default permissions after expiry/refund; members of private groups are removed.

Community purchases and recurring charges are disabled by default. Keep `COMMUNITY_PAYMENTS_ENABLED=0` while testing; the API rejects checkout and the scheduler does not issue renewals. Enable it only after confirming the payment environment and seller setup.

## YooKassa Marketplace setup

### Platform administrator

1. Apply for YooKassa Marketplace access and complete the platform agreement. The platform owner needs a platform YooKassa shop; each seller must also join the platform and connect a seller shop. A regular platform shop alone is not enough for split payments.
2. On the server, set the platform shop ID and API key in the local `.env`. Never put the secret in the Mini App, source control, screenshots, or chat. `YOOKASSA_SHOP_ID` is the platform shop, not a seller's `account_id`:

```dotenv
YOOKASSA_SHOP_ID=
YOOKASSA_SECRET_KEY=
YOOKASSA_MARKETPLACE_ENABLED=1
COMMUNITY_PAYMENTS_ENABLED=0
YOOKASSA_API_URL=https://api.yookassa.ru/v3
PLATFORM_COMMISSION_BPS=150
PUBLIC_URL=https://your-domain.example
COOKIE_SECURE=1
```

Keep `.env` local and make sure it is ignored by Git. Use test credentials for test purchases; a `live_` key can cause real charges. `COMMUNITY_PAYMENTS_ENABLED=0` blocks checkout and auto-renewal even when YooKassa credentials are present. Set it to `1` only after approval and testing. `BILLING_MODE=sandbox` controls MarketPilot's own plan switching and does not put YooKassa into sandbox mode. Do not enable marketplace payments until the provider account, HTTPS URL, and webhook are ready.
3. Configure the YooKassa notification URL as `https://your-domain.example/api/v1/webhooks/yookassa` for successful and canceled payments and successful refunds. The handler retrieves each payment/refund from YooKassa using server credentials before changing local state; webhook bodies alone never activate access.
4. Restart MarketPilot after changing `.env`, then verify the app status and run the integration tests. Integration tests use a local fake provider and do not verify real-money transactions.

### Community owner

1. Ask the platform administrator to confirm that Marketplace payments are enabled and the site is available at a public HTTPS address. Community owners do not enter the platform secret key in the app.
2. Apply to join the platform in YooKassa and connect the seller shop as required by the platform agreement. Obtain the seller `account_id` from the YooKassa Marketplace account; this is not the platform `shop_id` or API secret.
3. In the MarketPilot Mini App, open **Инструменты → Подписки**, choose an active public or private group/supergroup, enter the seller `account_id`, and press **Подключить магазин**. Public groups remain freely accessible.
4. Configure standard group permissions in the same section. This changes Telegram's default permissions for all group members, and is available for basic groups and supergroups. Create a tariff with a name, description, price in RUB, privilege duration, optional maximum number of subscribers, a daily per-member message quota, and (for supergroups) individual Telegram permissions. Messages above the tariff quota are deleted; group admins are exempt.
5. Before offering a tariff, verify that the bot is an administrator with member-restriction rights. Invite rights are required only for private groups. Make a small test purchase and refund using the provider's test credentials before switching to live payments.

If the community is still a basic group, convert it to a supergroup in Telegram first. The bot cannot perform this conversion. MarketPilot updates the connected resource when Telegram sends the group migration service message; after that, refresh the app to configure per-member permissions.

For each supergroup tariff, the owner can allow or deny text, audio, documents, photos, videos, video/voice notes, polls, stickers/GIFs/inline apps, link previews, inviting members, pinning messages, managing topics, and changing group information. Telegram applies these restrictions to a paid member after they join. The selected permissions must also be allowed by the group's default permissions; a tariff cannot grant rights that the group itself disables. Per-member permission controls are only available for supergroups. When a tariff expires or a refund is confirmed, a public-group member stays in the group with the group's default permissions; a private-group member is removed.

The 1.5% platform commission is sent as the YooKassa marketplace fee in the split-payment request. The remaining transfer is routed automatically to the seller's connected YooKassa shop. YooKassa's processing charges and the seller shop's subsequent bank settlement are controlled by the signed provider agreement and are not simulated by MarketPilot.

## API and accounting

- `GET /api/v1/marketplace/plans` lists purchasable tariffs.
- `POST /api/v1/communities/{id}/merchant` connects a seller shop; `POST /api/v1/communities/{id}/plans` creates a tariff.
- `POST /api/v1/community-plans/{id}/checkout` creates a payment only when `COMMUNITY_PAYMENTS_ENABLED=1`; `auto_renew` is opt-in.
- `GET /api/v1/community-subscriptions` and `/api/v1/owner/community-billing` serve buyer and owner dashboards.
- Refunds are requested at `/api/v1/community-subscriptions/{id}/refunds`; the owner approves or rejects them at `/api/v1/community-refunds/{id}/approve` or `/reject`.
- Payment, subscription, refund, ledger, and access-job records are scoped to the owner's workspace. Provider event IDs and YooKassa idempotency keys protect against repeated requests and notifications.

The owner ledger records RUB sales, platform commission, and the automatic marketplace transfer separately. No Stars wallet, Stars-to-RUB conversion, or manual payout path is implemented.
