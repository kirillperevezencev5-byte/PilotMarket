"""Configuration: environment variables, optionally loaded from a .env file next to run.py."""
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent


def _load_dotenv(path: pathlib.Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)  # real environment wins over .env


if os.environ.get("MP_NO_DOTENV") != "1":
    _load_dotenv(ROOT / ".env")


def _bool(name: str, default: bool) -> bool:
    return os.environ.get(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


class Config:
    VERSION = "0.2.0"
    HOST = os.environ.get("HOST", "127.0.0.1")
    PORT = int(os.environ.get("PORT", "8000"))
    DB_PATH = os.environ.get("DB_PATH", str(ROOT / "data" / "marketpilot.db"))

    BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
    BOT_USERNAME = os.environ.get("BOT_USERNAME", "").strip().lstrip("@")
    TG_API_BASE = os.environ.get("TG_API_BASE", "https://api.telegram.org").rstrip("/")
    PUBLIC_URL = os.environ.get("PUBLIC_URL", "").rstrip("/")

    DEMO_MODE = _bool("DEMO_MODE", True)
    COOKIE_SECURE = _bool("COOKIE_SECURE", False)  # set to 1 behind HTTPS
    SESSION_DAYS = int(os.environ.get("SESSION_DAYS", "30"))
    INIT_DATA_MAX_AGE = int(os.environ.get("INIT_DATA_MAX_AGE", str(24 * 3600)))
    LOGIN_TOKEN_TTL = 300
    AUTH_RATE_LIMIT = int(os.environ.get("AUTH_RATE_LIMIT", "100"))
    AUTH_RATE_WINDOW_SEC = int(os.environ.get("AUTH_RATE_WINDOW_SEC", "60"))

    SNAPSHOT_INTERVAL_MIN = int(os.environ.get("SNAPSHOT_INTERVAL_MIN", "360"))
    DEFAULT_PLAN = os.environ.get("DEFAULT_PLAN", "beta")
    # "sandbox": self-service plan changes are allowed without payment (demo / beta only).
    # "live": paid plans can only be activated by a confirmed payment (provider not connected yet -> 402).
    BILLING_MODE = os.environ.get("BILLING_MODE", "sandbox").strip().lower()
    AUDIT_RETENTION_DAYS = int(os.environ.get("AUDIT_RETENTION_DAYS", "180"))
    YOOKASSA_SHOP_ID = os.environ.get("YOOKASSA_SHOP_ID", "").strip()
    YOOKASSA_SECRET_KEY = os.environ.get("YOOKASSA_SECRET_KEY", "").strip()
    YOOKASSA_API_URL = os.environ.get("YOOKASSA_API_URL", "https://api.yookassa.ru/v3").rstrip("/")
    YOOKASSA_MARKETPLACE_ENABLED = _bool("YOOKASSA_MARKETPLACE_ENABLED", False)
    COMMUNITY_PAYMENTS_ENABLED = _bool("COMMUNITY_PAYMENTS_ENABLED", False)
    PLATFORM_COMMISSION_BPS = int(os.environ.get("PLATFORM_COMMISSION_BPS", "150"))

    # Telegram limits (Bot FAQ): ~30 msg/s overall, ~1 msg/s per chat
    TG_GLOBAL_RPS = 25
    TG_CHAT_INTERVAL = 1.1
    MAX_TEXT = 4096
    MAX_CAPTION = 1024


cfg = Config

PLANS = {
    "free": {"price": 0, "resources": 1, "features": ["dashboard", "resources", "analytics"]},
    "starter": {"price": 490, "resources": 3, "features": ["dashboard", "resources", "analytics", "templates", "moderation"]},
    "beta": {"price": 0, "resources": 10, "features": ["dashboard", "resources", "analytics", "templates", "moderation", "autoreply", "scheduler", "anti_scam", "ads", "export"]},  # beta: Pro limits for free while billing is not implemented
    "pro": {"price": 1490, "resources": 10, "features": ["dashboard", "resources", "analytics", "templates", "moderation", "autoreply", "scheduler", "anti_scam", "ads", "export"]},
    "business": {"price": 2990, "resources": 30, "features": ["dashboard", "resources", "analytics", "templates", "moderation", "autoreply", "scheduler", "anti_scam", "autoclean", "ads", "export", "premium"]},
    "agency": {"price": 5990, "resources": 100, "features": ["dashboard", "resources", "analytics", "templates", "moderation", "autoreply", "scheduler", "anti_scam", "autoclean", "ads", "export", "premium", "team"]},
}

# Public tariffs (TZ): FREE, PRO, BUSINESS. The others are legacy plans kept so existing accounts keep working.
PUBLIC_PLANS = ("free", "pro", "business")
LEGACY_PLANS = tuple(p for p in PLANS if p not in PUBLIC_PLANS)
