"""Community plans, YooKassa payments, subscription lifecycle and owner settlement views."""
import json
import hashlib
import logging
import secrets
import threading
from datetime import timedelta

from . import db, payments, security, telegram
from .config import cfg
from .server import ApiError, require_role, route

_maintenance_lock = threading.Lock()
log = logging.getLogger("marketpilot.marketplace")
PLAN_PERMISSION_FIELDS = telegram.CHAT_PERMISSION_FIELDS
PLAN_QUOTA_FIELDS = {"max_messages_per_day"}


def _feature_ready() -> None:
    if not cfg.COMMUNITY_PAYMENTS_ENABLED:
        raise ApiError(503, "payments_disabled", "Оплата подписок временно отключена")
    if not payments.configured():
        raise ApiError(503, "billing_unavailable", "Оплата YooKassa ещё не подключена")
    if not cfg.PUBLIC_URL.startswith("https://"):
        raise ApiError(503, "https_required", "Для оплаты нужен публичный HTTPS-адрес")


def _activate_pending_merchants() -> None:
    if payments.configured():
        db.run("UPDATE community_merchants SET status='active',updated_at=? WHERE status='pending'", db.now_iso())


def _resource_for_owner(req, resource_id: int, role: str = "admin"):
    require_role(req, req.workspace_id, role)
    resource = db.one("SELECT * FROM resources WHERE id=? AND user_id=? AND is_demo=0 AND status='active'",
                      resource_id, req.user["id"])
    if resource is None:
        raise ApiError(404, "not_found", "Сообщество не найдено")
    return resource


def _refresh_community_resource(resource) -> dict:
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram для проверки сообщества")
    try:
        chat = client.get_chat(resource["chat_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_check_failed", "Не удалось проверить актуальные настройки сообщества в Telegram") from exc
    chat_type = chat.get("type")
    if chat_type not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Платный доступ доступен только для групп и супергрупп")
    current = dict(resource)
    current["type"] = chat_type
    current["title"] = chat.get("title") or resource["title"]
    current["username"] = chat.get("username")
    db.run("UPDATE resources SET type=?,title=?,username=?,last_checked_at=? WHERE id=?",
           current["type"], current["title"], current["username"], db.now_iso(), resource["id"])
    return current


def _ensure_paid_access_supported(resource) -> None:
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Платный доступ пока поддерживается только для групп и супергрупп")
    client = telegram.client()
    if client is None or not telegram.is_live() or not telegram.state.get("bot_id"):
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram для управления доступом")
    try:
        member = client.chat_member(resource["chat_id"], telegram.state["bot_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError):
        raise ApiError(503, "telegram_rights_unavailable", "Не удалось проверить права бота в группе")
    missing = []
    if member.get("status") not in ("administrator", "creator"):
        missing.append("права администратора")
    if member.get("status") == "administrator" and not resource["username"] and not member.get("can_invite_users"):
        missing.append("приглашение участников")
    if member.get("status") == "administrator" and not member.get("can_restrict_members"):
        missing.append("ограничение участников")
    if missing:
        raise ApiError(409, "bot_rights_missing", "Боту не хватает прав: " + ", ".join(missing))


def _plan_dict(row) -> dict:
    return {"id": row["id"], "resource_id": row["resource_id"], "community": row["community"],
            "name": row["name"], "description": row["description"], "amount_minor": row["amount_minor"],
            "price": payments.money(row["amount_minor"]), "currency": "RUB", "duration_days": row["duration_days"],
            "max_members": row["max_members"], "active": bool(row["active"]),
            "permissions": json.loads(row["limits_json"] or "{}")}


def _validate_plan_permissions(value) -> dict:
    if not isinstance(value, dict):
        raise ApiError(422, "validation", "Права тарифа должны быть объектом разрешений")
    unknown = set(value) - set(PLAN_PERMISSION_FIELDS) - PLAN_QUOTA_FIELDS
    if unknown:
        raise ApiError(422, "validation", "В тарифе указано неизвестное ограничение")
    if any(not isinstance(value[key], bool) for key in set(value) & set(PLAN_PERMISSION_FIELDS)):
        raise ApiError(422, "validation", "Каждое право тарифа должно быть включено или выключено")
    quota = value.get("max_messages_per_day")
    if quota is not None and (isinstance(quota, bool) or not isinstance(quota, int) or not 1 <= quota <= 10000):
        raise ApiError(422, "validation", "Дневной лимит должен быть от 1 до 10000 сообщений или пустым")
    result = {key: bool(value[key]) for key in PLAN_PERMISSION_FIELDS if key in value}
    if "max_messages_per_day" in value:
        result["max_messages_per_day"] = quota
    return result


def _validate_chat_permissions(value) -> dict:
    if not isinstance(value, dict) or set(value) != set(telegram.CHAT_PERMISSION_FIELDS):
        raise ApiError(422, "validation", "Передайте все стандартные права Telegram")
    if any(not isinstance(allowed, bool) for allowed in value.values()):
        raise ApiError(422, "validation", "Каждое стандартное право должно быть включено или выключено")
    return {key: value[key] for key in telegram.CHAT_PERMISSION_FIELDS}


def _has_member_permissions(permissions: dict) -> bool:
    return any(key in permissions for key in PLAN_PERMISSION_FIELDS)


def _current_chat_permissions(resource) -> dict:
    saved = db.one("SELECT permissions_json FROM community_chat_settings WHERE resource_id=?", resource["id"])
    if saved is not None:
        return json.loads(saved["permissions_json"])
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram")
    try:
        chat = client.get_chat(resource["chat_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_permissions_unavailable", "Не удалось получить стандартные права группы") from exc
    current = chat.get("permissions") or {}
    return {key: bool(current.get(key, True)) for key in telegram.CHAT_PERMISSION_FIELDS}


@route("GET", "/api/v1/communities/<int:id>/permissions")
def get_community_permissions(req):
    resource = _resource_for_owner(req, req.params["id"], "viewer")
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Стандартные права доступны только для групп")
    return {"permissions": _current_chat_permissions(resource)}


@route("PUT", "/api/v1/communities/<int:id>/permissions")
def update_community_permissions(req):
    resource = _resource_for_owner(req, req.params["id"])
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Стандартные права доступны только для групп")
    permissions = _validate_chat_permissions(req.body.get("permissions"))
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram")
    try:
        member = client.chat_member(resource["chat_id"], telegram.state["bot_id"])
        if member.get("status") not in ("administrator", "creator"):
            raise ApiError(409, "bot_rights_missing", "Бот должен быть администратором группы")
        client.set_chat_permissions(resource["chat_id"], permissions)
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_permissions_update_failed",
                       "Telegram не принял стандартные права. Проверьте права администратора бота.") from exc
    db.run("INSERT INTO community_chat_settings(resource_id,permissions_json,updated_at) VALUES(?,?,?) "
           "ON CONFLICT(resource_id) DO UPDATE SET permissions_json=excluded.permissions_json,updated_at=excluded.updated_at",
           resource["id"], json.dumps(permissions), db.now_iso())
    return {"permissions": permissions}


def _queue_access(subscription_id: int, action: str) -> None:
    db.run("INSERT OR IGNORE INTO community_access_jobs(workspace_id,subscription_id,action,created_at,updated_at) "
           "SELECT workspace_id,id,?,?,? FROM community_subscriptions WHERE id=?",
           action, db.now_iso(), db.now_iso(), subscription_id)


def _queue_member_permission(subscription_id: int) -> None:
    now = db.now_iso()
    db.run("INSERT INTO community_permission_jobs(workspace_id,subscription_id,created_at,updated_at) "
           "SELECT workspace_id,id,?,? FROM community_subscriptions WHERE id=? "
           "ON CONFLICT(subscription_id) DO UPDATE SET status='pending',attempts=0,last_error='',updated_at=excluded.updated_at",
           now, now, subscription_id)


def queue_member_permissions(chat_id: int, telegram_user_id: int) -> int:
    subscriptions = db.q(
        "SELECT s.id FROM community_subscriptions s "
        "JOIN resources r ON r.id=s.resource_id JOIN users u ON u.id=s.buyer_user_id "
        "WHERE r.chat_id=? AND u.telegram_id=? AND s.status='active' AND s.starts_at<=? AND s.ends_at>?",
        chat_id, telegram_user_id, db.now_iso(), db.now_iso(),
    )
    for subscription in subscriptions:
        _queue_member_permission(subscription["id"])
    process_member_permission_jobs()
    return len(subscriptions)


def process_member_permission_jobs(limit: int = 20) -> int:
    client = telegram.client()
    if client is None or not telegram.is_live():
        return 0
    rows = db.q(
        "SELECT j.id job_id,s.id subscription_id,s.status,s.ends_at,p.limits_json,r.chat_id,u.telegram_id "
        "FROM community_permission_jobs j JOIN community_subscriptions s ON s.id=j.subscription_id "
        "JOIN community_plans p ON p.id=s.plan_id JOIN resources r ON r.id=s.resource_id "
        "JOIN users u ON u.id=s.buyer_user_id WHERE j.status IN ('pending','failed','processing') "
        "ORDER BY j.id LIMIT ?", limit,
    )
    completed = 0
    for row in rows:
        db.run("UPDATE community_permission_jobs SET status='processing',attempts=attempts+1,updated_at=? WHERE id=?",
               db.now_iso(), row["job_id"])
        try:
            if row["status"] != "active" or not row["ends_at"] or row["ends_at"] <= db.now_iso():
                db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                       db.now_iso(), row["job_id"])
                completed += 1
                continue
            member = client.chat_member(row["chat_id"], row["telegram_id"])
            if member.get("status") not in ("member", "administrator", "creator", "restricted"):
                db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                       db.now_iso(), row["job_id"])
                completed += 1
                continue
            plan_settings = json.loads(row["limits_json"] or "{}")
            permissions = {key: plan_settings[key] for key in PLAN_PERMISSION_FIELDS if key in plan_settings}
            if permissions:
                client.restrict_chat_member(row["chat_id"], row["telegram_id"], permissions)
            db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                   db.now_iso(), row["job_id"])
            completed += 1
        except Exception as exc:
            log.exception("applying community permissions failed for job %s", row["job_id"])
            db.run("UPDATE community_permission_jobs SET status='failed',last_error=?,updated_at=? WHERE id=?",
                   f"{type(exc).__name__}: {exc}"[:300], db.now_iso(), row["job_id"])
    return completed


def _settle_payment(provider_payment: dict, event_key: str = "") -> None:
    payment_id = (provider_payment.get("metadata") or {}).get("payment_id")
    if not payment_id or not str(payment_id).isdigit():
        raise ApiError(400, "payment_metadata_invalid", "Платёж не связан с заказом MarketPilot")
    local = db.one("SELECT * FROM community_payments WHERE id=?", int(payment_id))
    if local is None or local["provider_payment_id"] != provider_payment.get("id"):
        raise ApiError(404, "payment_not_found", "Заказ не найден")
    amount = provider_payment.get("amount") or {}
    if amount.get("currency") != "RUB" or amount.get("value") != payments.money(local["amount_minor"]):
        raise ApiError(400, "payment_amount_mismatch", "Сумма или валюта платежа не совпадает с заказом")
    if provider_payment.get("status") != "succeeded":
        return

    method = provider_payment.get("payment_method") or {}
    subscription = db.one("SELECT * FROM community_subscriptions WHERE id=?", local["subscription_id"])
    if subscription is None:
        raise ApiError(404, "subscription_not_found", "Подписка не найдена")
    saved_method_id = (method.get("id") if method.get("saved") else
                       subscription["payment_method_id"] if local["is_recurring"] else None)
    if event_key:
        db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
               "yookassa", event_key, "payment.succeeded", db.now_iso())

    with db.tx():
        current = db.one("SELECT status FROM community_payments WHERE id=?", local["id"])
        if current["status"] == "succeeded":
            return
        db.run("UPDATE community_payments SET status='succeeded', paid_at=?, payment_method_id=? WHERE id=?",
               db.now_iso(), saved_method_id, local["id"])
        duration = db.one("SELECT duration_days FROM community_plans WHERE id=?", local["plan_id"])["duration_days"]
        base = db.parse_iso(subscription["ends_at"]) if subscription["ends_at"] and subscription["ends_at"] > db.now_iso() else db.now()
        end = db.iso(base + timedelta(days=duration))
        auto_renew = bool(subscription["auto_renew"] and saved_method_id)
        db.run("UPDATE community_subscriptions SET status='active', starts_at=COALESCE(starts_at,?), ends_at=?, "
               "auto_renew=?, payment_method_id=?, updated_at=? WHERE id=?",
               db.now_iso(), end, int(auto_renew), saved_method_id if auto_renew else None, db.now_iso(), subscription["id"])
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="sale", amount_minor=local["amount_minor"],
                  created_at=db.now_iso())
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="commission", amount_minor=-local["commission_minor"],
                  created_at=db.now_iso())
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="payout", amount_minor=-local["owner_amount_minor"],
                  created_at=db.now_iso())
        db.event(local["buyer_user_id"], "community_subscription_active",
                 "Оплата подтверждена, привилегии тарифа активированы", local["resource_id"])
        db.event(local["owner_user_id"], "community_sale", "YooKassa подтвердила оплату тарифа сообщества", local["resource_id"])
        _queue_access(subscription["id"], "invite")
        _queue_member_permission(subscription["id"])


def _reconcile_payment(local) -> dict:
    if not local["provider_payment_id"]:
        if not cfg.COMMUNITY_PAYMENTS_ENABLED:
            return dict(local)
        if local["status"] != "unknown":
            return dict(local)
        subscription = db.one("SELECT * FROM community_subscriptions WHERE id=?", local["subscription_id"])
        plan = db.one("SELECT p.*,m.yookassa_account_id FROM community_plans p JOIN community_merchants m "
                      "ON m.resource_id=p.resource_id AND m.status='active' WHERE p.id=?", local["plan_id"])
        if subscription is None or plan is None:
            return dict(local)
        try:
            result = payments.create_payment(amount_minor=local["amount_minor"],
                seller_account_id=plan["yookassa_account_id"], payment_id=local["id"],
                subscription_id=subscription["id"], return_url=f"{cfg.PUBLIC_URL}/app/?payment={local['id']}",
                save_payment_method=bool(subscription["auto_renew"]), idempotency_key=local["idempotency_key"])
        except payments.PaymentProviderError as exc:
            if not exc.ambiguous:
                db.run("UPDATE community_payments SET status='canceled' WHERE id=?", local["id"])
                db.run("UPDATE community_subscriptions SET status='payment_failed',auto_renew=0,updated_at=? WHERE id=?",
                       db.now_iso(), subscription["id"])
            return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))
        db.run("UPDATE community_payments SET provider_payment_id=?,confirmation_url=?,status=? WHERE id=?",
               result.get("id"), (result.get("confirmation") or {}).get("confirmation_url"),
               result.get("status", "pending"), local["id"])
        if result.get("status") == "succeeded":
            _settle_payment(result)
        return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))
    try:
        provider_payment = payments.get_payment(local["provider_payment_id"])
    except payments.PaymentProviderError as exc:
        raise ApiError(503, "payment_status_unavailable", str(exc))
    if provider_payment.get("status") == "succeeded":
        _settle_payment(provider_payment)
    elif provider_payment.get("status") == "canceled":
        db.run("UPDATE community_payments SET status='canceled' WHERE id=? AND status IN ('pending','unknown')", local["id"])
        db.run("UPDATE community_subscriptions SET auto_renew=0, updated_at=? WHERE id=? AND status IN ('pending','active')",
               db.now_iso(), local["subscription_id"])
    return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))


def _payment_dict(row) -> dict:
    return {"id": row["id"], "subscription_id": row["subscription_id"], "amount": payments.money(row["amount_minor"]),
            "currency": row["currency"], "status": row["status"], "confirmation_url": row["confirmation_url"],
            "created_at": row["created_at"], "paid_at": row["paid_at"]}


@route("PUT", "/api/v1/communities/<int:id>/merchant")
def connect_merchant(req):
    resource = _resource_for_owner(req, req.params["id"])
    account_id = str(req.body.get("yookassa_account_id") or "").strip()
    if not account_id or len(account_id) > 64 or not account_id.isdigit():
        raise ApiError(422, "validation", "Укажите числовой account_id продавца YooKassa")
    status = "active" if payments.configured() else "pending"
    db.run("INSERT INTO community_merchants(resource_id,workspace_id,owner_user_id,yookassa_account_id,status,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(resource_id) DO UPDATE SET workspace_id=excluded.workspace_id, "
            "yookassa_account_id=excluded.yookassa_account_id,status=excluded.status,updated_at=excluded.updated_at",
            resource["id"], resource["workspace_id"], req.user["id"], account_id, status, db.now_iso(), db.now_iso())
    db.audit(req.actor_user["id"], "community_merchant_connected", method="PUT", status=200,
             resource_id=resource["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"resource_id": resource["id"], "status": status}


@route("GET", "/api/v1/communities/<int:id>/merchant")
def get_merchant(req):
    resource = _resource_for_owner(req, req.params["id"], "viewer")
    _activate_pending_merchants()
    merchant = db.one("SELECT status,yookassa_account_id FROM community_merchants WHERE resource_id=? AND owner_user_id=?",
                      resource["id"], req.user["id"])
    return {"resource_id": resource["id"], "status": merchant["status"] if merchant else "not_connected",
            "yookassa_account_id": merchant["yookassa_account_id"] if merchant else ""}


@route("GET", "/api/v1/communities/<int:id>/plans")
def list_community_plans(req):
    resource = db.one("SELECT id,title FROM resources WHERE id=? AND is_demo=0 AND status='active'", req.params["id"])
    if resource is None:
        raise ApiError(404, "not_found", "Сообщество не найдено")
    rows = db.q("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                "WHERE p.resource_id=? AND p.active=1 ORDER BY p.amount_minor", resource["id"])
    return {"items": [_plan_dict(row) for row in rows]}


@route("POST", "/api/v1/communities/<int:id>/plans")
def create_community_plan(req):
    resource = _resource_for_owner(req, req.params["id"])
    resource = _refresh_community_resource(resource)
    _ensure_paid_access_supported(resource)
    merchant = db.one("SELECT status FROM community_merchants WHERE resource_id=? AND owner_user_id=?",
                      resource["id"], req.user["id"])
    if merchant is None or merchant["status"] != "active":
        raise ApiError(409, "merchant_not_connected", "Сначала подключите магазин YooKassa для этого сообщества")
    name = str(req.body.get("name") or "").strip()[:80]
    description = str(req.body.get("description") or "").strip()[:500]
    try:
        amount_minor = int(req.body.get("amount_minor"))
        duration_days = int(req.body.get("duration_days"))
        max_members = int(req.body["max_members"]) if req.body.get("max_members") not in (None, "") else None
    except (ValueError, TypeError):
        raise ApiError(422, "validation", "Цена, срок и лимит участников должны быть целыми числами")
    if not name or amount_minor < 100 or amount_minor > 100_000_000 or not 1 <= duration_days <= 3650:
        raise ApiError(422, "validation", "Цена должна быть от 1 до 1 000 000 ₽, срок — от 1 до 3650 дней")
    if max_members is not None and not 1 <= max_members <= 1_000_000:
        raise ApiError(422, "validation", "Лимит участников должен быть от 1 до 1 000 000")
    permissions = _validate_plan_permissions(req.body.get("permissions", {}))
    if _has_member_permissions(permissions) and resource["type"] != "supergroup":
        raise ApiError(409, "permissions_require_supergroup",
                       "Индивидуальные права тарифа поддерживаются только в супергруппах Telegram")
    plan_id = db.insert("community_plans", workspace_id=resource["workspace_id"], resource_id=resource["id"],
                        owner_user_id=req.user["id"], name=name,
                        description=description, amount_minor=amount_minor, duration_days=duration_days,
                        max_members=max_members, limits_json=json.dumps(permissions),
                        created_at=db.now_iso(), updated_at=db.now_iso())
    db.audit(req.actor_user["id"], "community_plan_created", method="POST", status=201,
             resource_id=resource["id"], entity_id=plan_id, request_id=req.request_id, workspace_id=req.workspace_id)
    row = db.one("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id WHERE p.id=?", plan_id)
    return 201, _plan_dict(row)


@route("PUT", "/api/v1/community-plans/<int:id>")
def update_community_plan(req):
    row = db.one("SELECT * FROM community_plans WHERE id=? AND owner_user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Тариф не найден")
    resource = _resource_for_owner(req, row["resource_id"])
    name = str(req.body.get("name", row["name"])).strip()[:80]
    description = str(req.body.get("description", row["description"])).strip()[:500]
    try:
        amount = int(req.body.get("amount_minor", row["amount_minor"]))
        duration = int(req.body.get("duration_days", row["duration_days"]))
        max_members = int(req.body["max_members"]) if req.body.get("max_members") not in (None, "") else row["max_members"]
    except (ValueError, TypeError):
        raise ApiError(422, "validation", "Цена, срок и лимит участников должны быть целыми числами")
    active = int(bool(req.body.get("active", row["active"])))
    if not name or not 100 <= amount <= 100_000_000 or not 1 <= duration <= 3650:
        raise ApiError(422, "validation", "Неверная цена или срок тарифа")
    if max_members is not None and not 1 <= max_members <= 1_000_000:
        raise ApiError(422, "validation", "Лимит участников должен быть от 1 до 1 000 000")
    permissions = (json.dumps(_validate_plan_permissions(req.body["permissions"]))
                   if "permissions" in req.body else row["limits_json"])
    if ("permissions" in req.body and
            _has_member_permissions(json.loads(permissions)) and resource["type"] != "supergroup"):
        raise ApiError(409, "permissions_require_supergroup",
                       "Индивидуальные права тарифа поддерживаются только в супергруппах Telegram")
    db.run("UPDATE community_plans SET name=?,description=?,amount_minor=?,duration_days=?,max_members=?,limits_json=?,active=?,updated_at=? WHERE id=?",
           name, description, amount, duration, max_members, permissions, active, db.now_iso(), row["id"])
    if "permissions" in req.body:
        for sub in db.q("SELECT id FROM community_subscriptions WHERE plan_id=? AND status='active' AND ends_at>?",
                        row["id"], db.now_iso()):
            _queue_member_permission(sub["id"])
    db.audit(req.actor_user["id"], "community_plan_updated", method="PUT", status=200,
              resource_id=row["resource_id"], entity_id=row["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"ok": True}


@route("POST", "/api/v1/community-plans/<int:id>/checkout")
def create_checkout(req):
    _feature_ready()
    buyer_id = req.actor_user["id"]
    plan = db.one("SELECT p.*,r.title community,r.username,r.type,r.chat_id,r.status resource_status,"
                  "m.yookassa_account_id,m.status merchant_status "
                  "FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                  "JOIN community_merchants m ON m.resource_id=p.resource_id "
                  "WHERE p.id=? AND p.active=1", req.params["id"])
    if plan is None or plan["merchant_status"] != "active":
        raise ApiError(404, "plan_unavailable", "Тариф недоступен")
    plan = _refresh_community_resource(plan)
    if plan["resource_status"] != "active":
        raise ApiError(409, "community_unavailable", "Сообщество неактивно")
    _ensure_paid_access_supported(plan)
    if plan["owner_user_id"] == buyer_id:
        raise ApiError(409, "owner_cannot_buy", "Владелец не может купить собственный тариф")
    active = db.one("SELECT id FROM community_subscriptions WHERE buyer_user_id=? AND resource_id=? "
                    "AND status='active' AND ends_at>?", buyer_id, plan["resource_id"], db.now_iso())
    if active:
        raise ApiError(409, "already_subscribed", "У вас уже есть активный доступ к этому сообществу")
    if plan["max_members"] is not None:
        pending_cutoff = db.iso(db.now() - timedelta(minutes=20))
        count = db.one("SELECT COUNT(*) n FROM community_subscriptions WHERE plan_id=? AND "
                       "(status='active' AND ends_at>? OR (status='pending' AND created_at>?))",
                       plan["id"], db.now_iso(), pending_cutoff)["n"]
        if count >= plan["max_members"]:
            raise ApiError(409, "plan_full", "В этом тарифе больше нет мест")
    method = req.body.get("payment_method")
    if method not in (None, "yookassa"):
        raise ApiError(422, "payment_method_unavailable", "Сейчас доступна только оплата YooKassa в RUB")
    auto_renew = bool(req.body.get("auto_renew", False))
    sub_id = db.insert("community_subscriptions", workspace_id=plan["workspace_id"],
                       resource_id=plan["resource_id"], plan_id=plan["id"],
                       buyer_user_id=buyer_id, owner_user_id=plan["owner_user_id"], status="pending",
                       auto_renew=int(auto_renew), created_at=db.now_iso(), updated_at=db.now_iso())
    idempotency = "mp-community-" + secrets.token_urlsafe(24)
    fee = payments.commission(plan["amount_minor"])
    payment_id = db.insert("community_payments", workspace_id=plan["workspace_id"],
                           subscription_id=sub_id, plan_id=plan["id"],
                           resource_id=plan["resource_id"], buyer_user_id=buyer_id, owner_user_id=plan["owner_user_id"],
                           provider="yookassa", idempotency_key=idempotency, amount_minor=plan["amount_minor"],
                           commission_minor=fee, owner_amount_minor=plan["amount_minor"] - fee,
                           status="pending", is_recurring=0, created_at=db.now_iso())
    return_url = f"{cfg.PUBLIC_URL}/app/?payment={payment_id}"
    try:
        result = payments.create_payment(amount_minor=plan["amount_minor"], seller_account_id=plan["yookassa_account_id"],
                                          payment_id=payment_id, subscription_id=sub_id, return_url=return_url,
                                          save_payment_method=auto_renew, idempotency_key=idempotency)
    except payments.PaymentProviderError as exc:
        if exc.ambiguous:
            db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment_id)
            return 202, {"payment": _payment_dict(db.one("SELECT * FROM community_payments WHERE id=?", payment_id)),
                         "message": "Проверяем статус платежа. Повторное списание не выполняется."}
        db.run("UPDATE community_payments SET status='canceled' WHERE id=?", payment_id)
        db.run("UPDATE community_subscriptions SET status='payment_failed',auto_renew=0,updated_at=? WHERE id=?",
               db.now_iso(), sub_id)
        raise ApiError(502, "payment_rejected", str(exc))
    provider_id = result.get("id")
    confirmation_url = (result.get("confirmation") or {}).get("confirmation_url")
    if not provider_id:
        db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment_id)
        raise ApiError(502, "payment_provider_response", "YooKassa не вернула идентификатор платежа")
    db.run("UPDATE community_payments SET provider_payment_id=?,confirmation_url=?,status=? WHERE id=?",
           provider_id, confirmation_url, result.get("status", "pending"), payment_id)
    if result.get("status") == "succeeded":
        _settle_payment(result)
    db.audit(buyer_id, "community_checkout_created", method="POST", status=201,
             resource_id=plan["resource_id"], entity_id=payment_id, request_id=req.request_id, workspace_id=req.workspace_id)
    local = db.one("SELECT * FROM community_payments WHERE id=?", payment_id)
    return 201, {"payment": _payment_dict(local), "auto_renew_requested": auto_renew}


@route("GET", "/api/v1/marketplace/plans")
def marketplace_plans(req):
    _activate_pending_merchants()
    rows = db.q("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                "JOIN community_merchants m ON m.resource_id=p.resource_id "
                "WHERE p.active=1 AND m.status='active' AND r.status='active' AND r.is_demo=0 "
                "ORDER BY r.title,p.amount_minor")
    return {"items": [_plan_dict(row) for row in rows],
            "checkout_enabled": bool(cfg.COMMUNITY_PAYMENTS_ENABLED and payments.configured())}


@route("GET", "/api/v1/community-subscriptions")
def buyer_subscriptions(req):
    rows = db.q("SELECT s.*,r.title community,p.name plan_name,p.amount_minor,p.currency "
                "FROM community_subscriptions s JOIN resources r ON r.id=s.resource_id "
                "JOIN community_plans p ON p.id=s.plan_id WHERE s.buyer_user_id=? ORDER BY s.id DESC", req.actor_user["id"])
    return {"items": [{"id": row["id"], "community": row["community"], "plan": row["plan_name"],
                        "price": payments.money(row["amount_minor"]), "currency": row["currency"],
                        "status": row["status"], "starts_at": row["starts_at"], "ends_at": row["ends_at"],
                        "auto_renew": bool(row["auto_renew"])} for row in rows]}


@route("GET", "/api/v1/community-payments/<int:id>")
def community_payment_status(req):
    row = db.one("SELECT * FROM community_payments WHERE id=? AND (buyer_user_id=? OR owner_user_id=?)",
                 req.params["id"], req.actor_user["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Платёж не найден")
    if row["status"] in ("pending", "unknown"):
        row = _reconcile_payment(row)
    return _payment_dict(row)


@route("POST", "/api/v1/community-subscriptions/<int:id>/cancel")
def cancel_community_subscription(req):
    row = db.one("SELECT * FROM community_subscriptions WHERE id=? AND buyer_user_id=?",
                 req.params["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Подписка не найдена")
    db.run("UPDATE community_subscriptions SET auto_renew=0,status=CASE WHEN status='active' THEN 'cancelled' ELSE status END,updated_at=? WHERE id=?",
           db.now_iso(), row["id"])
    db.audit(req.actor_user["id"], "community_subscription_cancelled", method="POST", status=200,
             resource_id=row["resource_id"], entity_id=row["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"ok": True, "access_until": row["ends_at"], "auto_renew": False}


@route("POST", "/api/v1/community-subscriptions/<int:id>/refunds")
def request_community_refund(req):
    subscription = db.one("SELECT * FROM community_subscriptions WHERE id=? AND buyer_user_id=?",
                          req.params["id"], req.actor_user["id"])
    if subscription is None:
        raise ApiError(404, "not_found", "Подписка не найдена")
    payment = db.one("SELECT * FROM community_payments WHERE subscription_id=? AND status='succeeded' ORDER BY id DESC LIMIT 1",
                     subscription["id"])
    if payment is None:
        raise ApiError(409, "no_paid_payment", "Нет платежа, доступного для возврата")
    existing = db.one("SELECT id FROM community_refunds WHERE payment_id=? AND status IN ('requested','approved','pending','succeeded')",
                       payment["id"])
    if existing:
        raise ApiError(409, "refund_exists", "Возврат по этому платежу уже рассматривается")
    refund_id = db.insert("community_refunds", workspace_id=payment["workspace_id"],
                          owner_user_id=payment["owner_user_id"], payment_id=payment["id"],
                          requested_by=req.actor_user["id"],
                          amount_minor=payment["amount_minor"], idempotency_key="mp-refund-" + secrets.token_urlsafe(24),
                          status="requested", reason=str(req.body.get("reason") or "")[:300],
                          created_at=db.now_iso(), updated_at=db.now_iso())
    db.audit(req.actor_user["id"], "community_refund_requested", method="POST", status=201,
             resource_id=subscription["resource_id"], entity_id=refund_id,
             request_id=req.request_id, workspace_id=subscription["workspace_id"])
    db.event(subscription["owner_user_id"], "community_refund_requested", "Покупатель запросил возврат",
             subscription["resource_id"])
    return 201, {"id": refund_id, "status": "requested"}


@route("GET", "/api/v1/owner/community-billing")
def owner_billing(req):
    _activate_pending_merchants()
    rows = db.q("SELECT l.currency,l.kind,SUM(l.amount_minor) amount_minor,COUNT(*) n "
                "FROM community_ledger l WHERE l.owner_user_id=? GROUP BY l.currency,l.kind", req.user["id"])
    plans = db.q("SELECT p.id,p.resource_id,p.name,p.amount_minor,p.duration_days,p.active,p.limits_json,r.title community "
                 "FROM community_plans p JOIN resources r ON r.id=p.resource_id WHERE p.owner_user_id=? ORDER BY p.id DESC",
                 req.user["id"])
    refunds = db.q("SELECT f.id,f.status,f.amount_minor,f.reason,r.title community,p.name plan "
                   "FROM community_refunds f JOIN community_payments x ON x.id=f.payment_id "
                   "JOIN community_plans p ON p.id=x.plan_id JOIN resources r ON r.id=x.resource_id "
                   "WHERE x.owner_user_id=? ORDER BY f.id DESC", req.user["id"])
    subscriptions = db.q("SELECT s.id,s.status,s.starts_at,s.ends_at,s.auto_renew,u.first_name,u.username,"
                         "r.title community,p.name plan FROM community_subscriptions s "
                         "JOIN users u ON u.id=s.buyer_user_id JOIN resources r ON r.id=s.resource_id "
                         "JOIN community_plans p ON p.id=s.plan_id WHERE s.owner_user_id=? ORDER BY s.id DESC",
                         req.user["id"])
    plan_items = []
    for row in plans:
        item = dict(row)
        item["permissions"] = json.loads(item.pop("limits_json") or "{}")
        plan_items.append(item)
    return {"ledger": [dict(row) for row in rows], "plans": plan_items,
            "refunds": [dict(row) for row in refunds], "subscriptions": [dict(row) for row in subscriptions]}


@route("POST", "/api/v1/community-refunds/<int:id>/approve")
def approve_community_refund(req):
    refund = db.one("SELECT f.*,p.provider_payment_id,p.id payment_local_id,p.owner_user_id,p.resource_id "
                    "FROM community_refunds f JOIN community_payments p ON p.id=f.payment_id WHERE f.id=? AND p.owner_user_id=?",
                    req.params["id"], req.user["id"])
    if refund is None or refund["status"] != "requested":
        raise ApiError(404, "not_found", "Запрос возврата не найден")
    _feature_ready()
    try:
        provider_refund = payments.create_refund(provider_payment_id=refund["provider_payment_id"],
                                                  amount_minor=refund["amount_minor"], payment_id=refund["payment_local_id"],
                                                  idempotency_key=refund["idempotency_key"])
    except payments.PaymentProviderError as exc:
        raise ApiError(503, "refund_pending", str(exc))
    db.run("UPDATE community_refunds SET approved_by=?,provider_refund_id=?,status=?,updated_at=? WHERE id=?",
            req.actor_user["id"], provider_refund.get("id"), "pending", db.now_iso(), refund["id"])
    db.run("UPDATE community_payments SET status='refund_pending' WHERE id=?", refund["payment_local_id"])
    if provider_refund.get("status") == "succeeded":
        _complete_refund(refund["id"], provider_refund)
    db.audit(req.actor_user["id"], "community_refund_approved", method="POST", status=200,
             resource_id=refund["resource_id"], entity_id=refund["id"],
             request_id=req.request_id, workspace_id=refund["workspace_id"])
    return {"id": refund["id"], "status": db.one("SELECT status FROM community_refunds WHERE id=?", refund["id"])["status"]}


@route("POST", "/api/v1/community-refunds/<int:id>/reject")
def reject_community_refund(req):
    refund = db.one("SELECT f.id,f.status,p.owner_user_id FROM community_refunds f "
                    "JOIN community_payments p ON p.id=f.payment_id WHERE f.id=? AND p.owner_user_id=?",
                    req.params["id"], req.user["id"])
    if refund is None or refund["status"] != "requested":
        raise ApiError(404, "not_found", "Запрос возврата не найден")
    db.run("UPDATE community_refunds SET approved_by=?,status='rejected',updated_at=? WHERE id=?",
           req.actor_user["id"], db.now_iso(), refund["id"])
    db.audit(req.actor_user["id"], "community_refund_rejected", method="POST", status=200,
             entity_id=refund["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"id": refund["id"], "status": "rejected"}


def _complete_refund(refund_id: int, provider_refund: dict) -> None:
    refund = db.one("SELECT f.*,p.owner_user_id,p.resource_id,p.id payment_local_id,p.subscription_id "
                    "FROM community_refunds f JOIN community_payments p ON p.id=f.payment_id WHERE f.id=?", refund_id)
    if refund is None or refund["status"] == "succeeded":
        return
    if provider_refund.get("status") != "succeeded":
        return
    payment = db.one("SELECT provider_payment_id FROM community_payments WHERE id=?", refund["payment_local_id"])
    provider_amount = provider_refund.get("amount") or {}
    if (provider_refund.get("payment_id") != payment["provider_payment_id"] or
            provider_amount.get("currency") != "RUB" or
            provider_amount.get("value") != payments.money(refund["amount_minor"])):
        raise ApiError(400, "refund_mismatch", "Возврат не совпадает с исходным платежом")
    with db.tx():
        db.run("UPDATE community_refunds SET status='succeeded',provider_refund_id=?,updated_at=? WHERE id=?",
               provider_refund.get("id"), db.now_iso(), refund_id)
        db.run("UPDATE community_payments SET status='refunded' WHERE id=?", refund["payment_local_id"])
        db.run("UPDATE community_subscriptions SET status='refunded',auto_renew=0,payment_method_id=NULL,updated_at=? WHERE id=?",
               db.now_iso(), refund["subscription_id"])
        db.insert("community_ledger", workspace_id=refund["workspace_id"],
              owner_user_id=refund["owner_user_id"], resource_id=refund["resource_id"],
                  refund_id=refund_id, currency="RUB", kind="refund", amount_minor=-refund["amount_minor"],
                  created_at=db.now_iso())
        db.event(refund["requested_by"], "community_refund_succeeded", "Возврат подтверждён, привилегии тарифа отозваны",
             refund["resource_id"])
        db.event(refund["owner_user_id"], "community_refund_succeeded", "Возврат выполнен YooKassa",
             refund["resource_id"])
        _queue_access(refund["subscription_id"], "revoke")


def _handle_payment_canceled(object_id: str, event_type: str) -> None:
    row = db.one("SELECT * FROM community_payments WHERE provider_payment_id=?", object_id)
    if row is None:
        return
    db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
           "yookassa", "payment:" + object_id + ":canceled", event_type, db.now_iso())
    db.run("UPDATE community_payments SET status='canceled' WHERE id=? AND status!='succeeded'", row["id"])
    db.run("UPDATE community_subscriptions SET status=CASE WHEN ends_at IS NULL OR ends_at<=? "
           "THEN 'payment_failed' ELSE status END,auto_renew=0,payment_method_id=NULL,updated_at=? "
           "WHERE id=? AND status IN ('pending','active')", db.now_iso(), db.now_iso(), row["subscription_id"])


@route("POST", "/api/v1/webhooks/yookassa", public=True)
def yookassa_webhook(req):
    event_type = str(req.body.get("event") or "")
    obj = req.body.get("object") or {}
    object_id = str(obj.get("id") or "")
    if event_type == "payment.succeeded" and object_id:
        try:
            provider_payment = payments.get_payment(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        if provider_payment.get("status") == "succeeded":
            _settle_payment(provider_payment, "payment:" + object_id + ":succeeded")
    elif event_type == "payment.canceled" and object_id:
        try:
            provider_payment = payments.get_payment(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        if provider_payment.get("status") == "canceled":
            _handle_payment_canceled(object_id, event_type)
    elif event_type == "refund.succeeded" and object_id:
        try:
            provider_refund = payments.get_refund(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        local_refund = db.one("SELECT id FROM community_refunds WHERE provider_refund_id=?", object_id)
        if local_refund:
            _complete_refund(local_refund["id"], provider_refund)
            db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
                   "yookassa", "refund:" + object_id + ":succeeded", event_type, db.now_iso())
    return {"ok": True}


def expire_community_subscriptions() -> int:
    rows = db.q("SELECT id,resource_id FROM community_subscriptions WHERE status IN ('active','cancelled','payment_failed') "
                "AND ends_at IS NOT NULL AND ends_at<=? AND NOT EXISTS "
                "(SELECT 1 FROM community_payments p WHERE p.subscription_id=community_subscriptions.id "
                "AND p.is_recurring=1 AND p.status IN ('pending','unknown'))", db.now_iso())
    for row in rows:
        db.run("UPDATE community_subscriptions SET status='expired',auto_renew=0,payment_method_id=NULL,updated_at=? "
               "WHERE id=? AND status IN ('active','cancelled','payment_failed')", db.now_iso(), row["id"])
        _queue_access(row["id"], "revoke")
        db.run("INSERT OR IGNORE INTO community_subscription_notices(workspace_id,subscription_id,notice_type,ends_at,created_at) "
               "SELECT workspace_id,id,'expired',COALESCE(ends_at,''),? FROM community_subscriptions WHERE id=?",
               db.now_iso(), row["id"])
    return len(rows)


def renew_due_subscriptions() -> int:
    if not cfg.COMMUNITY_PAYMENTS_ENABLED or not payments.configured():
        return 0
    rows = db.q("SELECT s.*,p.amount_minor,p.owner_user_id,p.id plan_id,p.duration_days,m.yookassa_account_id "
                "FROM community_subscriptions s JOIN community_plans p ON p.id=s.plan_id "
                "JOIN community_merchants m ON m.resource_id=s.resource_id AND m.status='active' "
                "WHERE s.status='active' AND s.auto_renew=1 AND s.payment_method_id IS NOT NULL "
                "AND s.ends_at IS NOT NULL AND s.ends_at<=? ORDER BY s.ends_at LIMIT 20", db.now_iso())
    attempted = 0
    for subscription in rows:
        cycle = hashlib.sha256(subscription["ends_at"].encode()).hexdigest()[:16]
        key = f"mp-renew-{subscription['id']}-{cycle}"
        payment = db.one("SELECT * FROM community_payments WHERE idempotency_key=?", key)
        if payment and payment["provider_payment_id"]:
            try:
                _reconcile_payment(payment)
            except ApiError:
                pass
            continue
        if payment is None:
            fee = payments.commission(subscription["amount_minor"])
            local_id = db.insert("community_payments", workspace_id=subscription["workspace_id"],
                                 subscription_id=subscription["id"], plan_id=subscription["plan_id"],
                                 resource_id=subscription["resource_id"], buyer_user_id=subscription["buyer_user_id"],
                                 owner_user_id=subscription["owner_user_id"], provider="yookassa", idempotency_key=key,
                                 amount_minor=subscription["amount_minor"], commission_minor=fee,
                                 owner_amount_minor=subscription["amount_minor"] - fee, status="pending",
                                 is_recurring=1, created_at=db.now_iso())
            payment = db.one("SELECT * FROM community_payments WHERE id=?", local_id)
        try:
            result = payments.create_payment(amount_minor=payment["amount_minor"],
                seller_account_id=subscription["yookassa_account_id"], payment_id=payment["id"],
                subscription_id=subscription["id"], return_url=f"{cfg.PUBLIC_URL}/app/?payment={payment['id']}",
                save_payment_method=False, payment_method_id=subscription["payment_method_id"], idempotency_key=key)
        except payments.PaymentProviderError:
            db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment["id"])
            continue
        db.run("UPDATE community_payments SET provider_payment_id=?,status=? WHERE id=?",
               result.get("id"), result.get("status", "pending"), payment["id"])
        if result.get("status") == "succeeded":
            _settle_payment(result)
        elif result.get("status") == "canceled":
            db.run("UPDATE community_subscriptions SET auto_renew=0,updated_at=? WHERE id=?",
                   db.now_iso(), subscription["id"])
            db.event(subscription["buyer_user_id"], "community_renewal_failed",
                     "Автопродление не прошло. Доступ сохранится до даты окончания.", subscription["resource_id"])
        attempted += 1
    return attempted


def send_expiry_notices() -> int:
    if not telegram.is_live():
        return 0
    rows = db.q("SELECT s.id,s.buyer_user_id,s.resource_id,s.ends_at,u.telegram_id,r.title "
                "FROM community_subscriptions s JOIN users u ON u.id=s.buyer_user_id "
                "JOIN resources r ON r.id=s.resource_id WHERE s.status='active' "
                "AND s.ends_at>? AND s.ends_at<=?", db.now_iso(), db.iso(db.now() + timedelta(days=3)))
    sent = 0
    client = telegram.client()
    for row in rows:
        cur = db.run("INSERT OR IGNORE INTO community_subscription_notices(workspace_id,subscription_id,notice_type,ends_at,created_at) "
                 "SELECT workspace_id,id,'expiring',?,? FROM community_subscriptions WHERE id=?",
                 row["ends_at"], db.now_iso(), row["id"])
        if cur.rowcount:
            try:
                sub = db.one("SELECT auto_renew FROM community_subscriptions WHERE id=?", row["id"])
                note = ("В этот день запланировано автопродление. Отключите его в кабинете, если оно не нужно."
                        if sub["auto_renew"] else "Продлите тариф, чтобы сохранить его привилегии.")
                client.send_message(row["telegram_id"],
                    f"Срок привилегий тарифа в «{row['title']}» закончится {row['ends_at']}. "
                    f"Группа останется доступна. {note}", parse_mode=None)
                sent += 1
            except Exception:
                db.run("DELETE FROM community_subscription_notices WHERE subscription_id=? AND notice_type='expiring' AND ends_at=?",
                       row["id"], row["ends_at"])
    return sent


def maintenance_tick() -> None:
    if not _maintenance_lock.acquire(blocking=False):
        return
    try:
        expire_community_subscriptions()
        renew_due_subscriptions()
        send_expiry_notices()
        process_access_jobs()
        process_member_permission_jobs()
    finally:
        _maintenance_lock.release()


def process_access_jobs(limit: int = 20) -> int:
    client = telegram.client()
    if client is None or not telegram.is_live():
        return 0
    rows = db.q("SELECT j.*,s.resource_id,s.buyer_user_id,s.ends_at,u.telegram_id,r.title,r.chat_id,r.username "
                "FROM community_access_jobs j JOIN community_subscriptions s ON s.id=j.subscription_id "
                "JOIN users u ON u.id=s.buyer_user_id JOIN resources r ON r.id=s.resource_id "
                "WHERE j.status IN ('pending','failed','processing') ORDER BY j.id LIMIT ?", limit)
    completed = 0
    for row in rows:
        db.run("UPDATE community_access_jobs SET status='processing',attempts=attempts+1,updated_at=? WHERE id=?",
               db.now_iso(), row["id"])
        try:
            if row["action"] == "invite":
                if row["username"]:
                    link = "https://t.me/" + row["username"].lstrip("@")
                    client.send_message(row["telegram_id"],
                        f"Оплата подтверждена. Группа «{row['title']}» открыта для всех: {link}. "
                        "Привилегии вашего тарифа действуют после вступления.")
                else:
                    link = client.create_chat_invite_link(
                        row["chat_id"], int(db.now().timestamp()) + 3600, member_limit=1)
                    client.send_message(row["telegram_id"],
                        f"Оплата подтверждена. Ссылка для вступления в «{row['title']}»: {link}")
            else:
                if row["username"]:
                    member = client.chat_member(row["chat_id"], row["telegram_id"])
                    if member.get("status") in ("member", "restricted"):
                        chat = client.get_chat(row["chat_id"])
                        defaults = chat.get("permissions")
                        if not isinstance(defaults, dict):
                            raise RuntimeError("Telegram did not return the group's default permissions")
                        permissions = {key: bool(defaults.get(key, False))
                                       for key in telegram.CHAT_PERMISSION_FIELDS}
                        client.restrict_chat_member(row["chat_id"], row["telegram_id"], permissions)
                    client.send_message(row["telegram_id"],
                        f"Срок платных привилегий в «{row['title']}» завершён. "
                        "Группа остаётся открытой для вас и всех остальных участников.")
                else:
                    client.ban_chat_member(row["chat_id"], row["telegram_id"])
                    client.unban_chat_member(row["chat_id"], row["telegram_id"])
                    client.send_message(row["telegram_id"], f"Срок доступа к «{row['title']}» завершён.")
            db.run("UPDATE community_access_jobs SET status='done',last_error='',updated_at=? WHERE id=?", db.now_iso(), row["id"])
            completed += 1
        except Exception as exc:
            db.run("UPDATE community_access_jobs SET status='failed',last_error=?,updated_at=? WHERE id=?",
                   f"{type(exc).__name__}: {exc}"[:300], db.now_iso(), row["id"])
    return completed
