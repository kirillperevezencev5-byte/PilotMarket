"""REST API. Every authenticated query is scoped by the session user's id (tenant isolation)."""
import base64
import hashlib
import json
import re
import secrets
from datetime import datetime, timedelta, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from . import bot, db, security, seed, telegram
from .config import LEGACY_PLANS, PLANS, PUBLIC_PLANS, cfg
from .server import ApiError, require_role, route
from . import marketplace  # noqa: F401  (registers marketplace routes)

NOT_FOUND = ApiError(404, "not_found", "Не найдено")


# ====================================================================== helpers
def user_tz(user) -> ZoneInfo:
    try:
        return ZoneInfo(user["timezone"])
    except Exception:
        return ZoneInfo("UTC")


def need(req, field: str, kind=str, default=None, required=True):
    value = req.body.get(field, default)
    if value is None or value == "":
        if required:
            raise ApiError(422, "validation", f"Поле «{field}» обязательно")
        return default
    if kind is not None and not isinstance(value, kind):
        raise ApiError(422, "validation", f"Поле «{field}» имеет неверный тип")
    return value


def parse_when(value: str) -> datetime:
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        raise ApiError(422, "validation", "Неверный формат даты")
    if dt.tzinfo is None:
        raise ApiError(422, "validation", "Дата должна содержать часовой пояс")
    return dt.astimezone(timezone.utc)


ALLOWED_TAGS = {"b", "strong", "i", "em", "u", "ins", "s", "strike", "del", "a", "code", "pre", "tg-spoiler",
                "blockquote", "span"}


class _HtmlCheck(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.visible, self.error = [], 0, None

    def handle_starttag(self, tag, attrs):
        if tag not in ALLOWED_TAGS:
            self.error = self.error or f"Тег <{tag}> не поддерживается Telegram"
            return
        if tag == "a" and not dict(attrs).get("href"):
            self.error = self.error or "У ссылки <a> нужен атрибут href"
        self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag not in ALLOWED_TAGS:
            return
        if not self.stack or self.stack[-1] != tag:
            self.error = self.error or f"Тег </{tag}> закрыт неправильно"
        else:
            self.stack.pop()

    def handle_data(self, data):
        self.visible += len(data)


def validate_text(text: str, has_image: bool) -> None:
    chk = _HtmlCheck()
    chk.feed(text)
    chk.close()
    if chk.error:
        raise ApiError(422, "bad_format", chk.error)
    if chk.stack:
        raise ApiError(422, "bad_format", f"Не закрыт тег <{chk.stack[-1]}>")
    limit = cfg.MAX_CAPTION if has_image else cfg.MAX_TEXT
    if chk.visible > limit:
        raise ApiError(422, "too_long", f"Текст длиннее {limit} символов ({chk.visible})" +
                       (" — подпись к фото ограничена" if has_image else ""))


def validate_image(url) -> str | None:
    if not url:
        return None
    if not isinstance(url, str):
        raise ApiError(422, "validation", "Неверный адрес изображения")
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.netloc or len(url) > 2000:
        raise ApiError(422, "validation", "Адрес изображения должен начинаться с http:// или https://")
    return url


def render_template_text(text: str, variables: dict) -> str:
    if not isinstance(variables, dict):
        raise ApiError(422, "validation", "Переменные должны быть объектом JSON")

    def repl(match):
        key = match.group(1)
        return str(variables.get(key, match.group(0)))

    return re.sub(r"\{([a-zA-Z0-9_\-]+)\}", repl, text)


def resource_row(user_id: int, rid: int):
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, user_id)
    if row is None:
        raise NOT_FOUND
    return row


def res_dict(r) -> dict:
    return {
        "id": r["id"], "title": r["title"], "username": r["username"], "type": r["type"], "status": r["status"],
        "capabilities": db.jl(r["capabilities"]), "missing_rights": db.jl(r["missing_rights"]),
        "members": r["members"], "is_demo": bool(r["is_demo"]), "connected_at": r["connected_at"],
        "last_checked_at": r["last_checked_at"],
    }


def target_dict(t) -> dict:
    return {
        "id": t["id"], "post_id": t["post_id"], "resource_id": t["resource_id"],
        "resource_title": t["resource_title"] if "resource_title" in t.keys() else None,
        "status": t["status"], "scheduled_at": t["scheduled_at"], "published_at": t["published_at"],
        "error": t["error"], "message_id": t["message_id"], "attempts": t["attempts"],
    }


def publication_limit_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "kind": r["kind"],
        "value": int(r["value"]),
        "enabled": bool(r["enabled"]),
        "created_at": r["created_at"],
    }


def plan_info(user) -> dict:
    plan = PLANS.get(user["plan"], PLANS["free"])
    limit = plan["resources"]
    used = db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND status!='disconnected' AND is_demo=0",
                  user["id"])["n"]
    return {"plan": user["plan"], "resource_limit": limit, "resources_used": used,
            "features": plan.get("features", [])}


def feature_enabled(user, feature: str) -> bool:
    return feature in PLANS.get(user["plan"], PLANS["free"]).get("features", [])


def require_feature(req, feature: str, label: str):
    if not feature_enabled(req.user, feature):
        raise ApiError(402, "plan_required", f"Для {label} нужен тариф с доступом к '{feature}'.")


def user_dict(user) -> dict:
    uid = user["id"]
    row_keys = set(user.keys()) if hasattr(user, "keys") else set()
    return {
        "telegram_id": None if user["is_demo"] else user["telegram_id"],
        "posts_total": db.one("SELECT COUNT(*) n FROM posts WHERE user_id=?", uid)["n"],
        "published_total": db.one("SELECT COUNT(*) n FROM post_targets WHERE user_id=? AND status='published'", uid)["n"],
        "id": user["id"], "first_name": user["first_name"], "username": user["username"],
        "language": user["language"], "timezone": user["timezone"], "notify": bool(user["notify"]),
        "theme": user["theme"] if "theme" in row_keys else "light",
        "ui_density": user["ui_density"] if "ui_density" in row_keys else "comfortable",
        "security_mode": user["security_mode"] if "security_mode" in row_keys else "standard",
        "is_demo": bool(user["is_demo"]), "created_at": user["created_at"], **plan_info(user),
    }


def start_session(req, user, with_token: bool = False) -> dict:
    db.ensure_workspace(user["id"])
    raw = security.create_session(user["id"])
    req.set_session(raw)
    out = {"user": user_dict(user)}
    if with_token:  # Mini App: some Telegram webviews restrict cookies, so it sends a Bearer token instead
        out["token"] = raw
    return out


def limit_auth(req):
    if not security.auth_limiter.allow(req.ip):
        raise ApiError(429, "rate_limited", "Слишком много попыток, подождите минуту")


# ====================================================================== status & auth
@route("GET", "/api/v1/status", public=True)
def status(req):
    return {
        "version": cfg.VERSION,
        "demo_mode": cfg.DEMO_MODE,
        "billing_mode": cfg.BILLING_MODE,
        "telegram": {
            "configured": bool(cfg.BOT_TOKEN),
            "connected": telegram.state["connected"],
            "username": telegram.state["username"] or cfg.BOT_USERNAME,
            "error": telegram.state["error"],
        },
        "miniapp_url": bot.miniapp_url(),
        "authenticated": req.user is not None,
    }


@route("POST", "/api/v1/auth/demo", public=True)
def auth_demo(req):
    if not cfg.DEMO_MODE:
        raise ApiError(403, "demo_disabled", "Демо-режим отключён")
    limit_auth(req)
    user = db.one("SELECT * FROM users WHERE id=?", seed.create_demo_user())
    return start_session(req, user, with_token=True)


@route("POST", "/api/v1/auth/miniapp", public=True)
def auth_miniapp(req):
    limit_auth(req)
    if not cfg.BOT_TOKEN:
        raise ApiError(400, "no_bot", "Бот не настроен (BOT_TOKEN)")
    try:
        tg_user = security.verify_init_data(need(req, "init_data"), cfg.BOT_TOKEN, cfg.INIT_DATA_MAX_AGE)
    except security.AuthError as e:
        raise ApiError(401, "bad_init_data", str(e))
    user = security.upsert_telegram_user(tg_user)
    return start_session(req, user, with_token=True)


@route("POST", "/api/v1/auth/web/start", public=True)
def web_start(req):
    limit_auth(req)
    if not telegram.is_live():
        raise ApiError(409, "telegram_not_connected",
                       "Вход через Telegram недоступен: бот не подключён. Укажите BOT_TOKEN или используйте демо-режим.")
    raw, hashed = security.new_token()
    db.insert("login_tokens", token_hash=hashed, expires_at=db.iso(db.now() + timedelta(seconds=cfg.LOGIN_TOKEN_TTL)))
    username = telegram.state["username"]
    return {"token": raw, "deep_link": f"https://t.me/{username}?start=login_{raw}", "expires_in": cfg.LOGIN_TOKEN_TTL}


@route("POST", "/api/v1/auth/web/poll", public=True)
def web_poll(req):
    token = need(req, "token")
    h = security.hash_token(token)
    row = db.one("SELECT * FROM login_tokens WHERE token_hash=?", h)
    if row is None or row["consumed"] or row["expires_at"] < db.now_iso():
        return {"status": "expired"}
    if not row["confirmed"] or row["user_id"] is None:
        return {"status": "pending"}
    cur = db.run("UPDATE login_tokens SET consumed=1 WHERE token_hash=? AND consumed=0", h)
    if cur.rowcount != 1:
        return {"status": "expired"}
    user = db.one("SELECT * FROM users WHERE id=?", row["user_id"])
    return {"status": "confirmed", **start_session(req, user)}


@route("POST", "/api/v1/auth/logout")
def logout(req):
    security.delete_session(req.session_token)
    req.clear_session()
    return {"ok": True}


# ====================================================================== workspaces and roles
def workspace_dict(row) -> dict:
    return {"id": row["id"], "name": row["name"], "role": row["role"], "owner_user_id": row["owner_user_id"],
            "created_at": row["created_at"]}


@route("GET", "/api/v1/workspaces")
def list_workspaces(req):
    rows = db.q("SELECT w.*, m.role FROM workspace_members m JOIN workspaces w ON w.id=m.workspace_id "
                "WHERE m.user_id=? ORDER BY w.id", req.actor_user["id"])
    return {"items": [workspace_dict(row) for row in rows]}


@route("GET", "/api/v1/workspaces/<int:id>/members")
def list_workspace_members(req):
    require_role(req, req.params["id"], "viewer")
    rows = db.q("SELECT m.user_id, m.role, m.joined_at, u.first_name, u.username FROM workspace_members m "
                "JOIN users u ON u.id=m.user_id WHERE m.workspace_id=? ORDER BY m.joined_at", req.params["id"])
    return {"items": [dict(row) for row in rows]}


@route("GET", "/api/v1/workspaces/<int:id>/invitations")
def list_workspace_invitations(req):
    require_role(req, req.params["id"], "admin")
    rows = db.q("SELECT id, role, invited_by, expires_at, created_at FROM workspace_invitations "
                "WHERE workspace_id=? AND used_by IS NULL AND revoked_at IS NULL AND expires_at>? "
                "ORDER BY id DESC", req.params["id"], db.now_iso())
    return {"items": [dict(row) for row in rows]}


@route("POST", "/api/v1/workspaces/<int:id>/invitations")
def create_workspace_invitation(req):
    workspace_id = req.params["id"]
    actor_role = require_role(req, workspace_id, "admin")
    role = str(req.body.get("role") or "viewer")
    if role not in ("admin", "moderator", "viewer") or (role == "admin" and actor_role != "owner"):
        raise ApiError(422, "invalid_role", "Нельзя пригласить участника с этой ролью")
    try:
        hours = int(req.body.get("expires_in_hours", 24))
    except (ValueError, TypeError):
        raise ApiError(422, "validation", "Срок приглашения должен быть от 1 до 168 часов")
    if not 1 <= hours <= 168:
        raise ApiError(422, "validation", "Срок приглашения должен быть от 1 до 168 часов")
    raw, token_hash = security.new_token()
    expires_at = db.iso(db.now() + timedelta(hours=hours))
    invitation_id = db.insert("workspace_invitations", workspace_id=workspace_id, token_hash=token_hash,
                              role=role, invited_by=req.actor_user["id"], expires_at=expires_at,
                              created_at=db.now_iso())
    db.audit(req.actor_user["id"], "workspace_invitation_created", method="POST", status=201,
             entity_id=invitation_id, request_id=req.request_id, workspace_id=workspace_id)
    invite_url = f"{cfg.PUBLIC_URL}/app/?invite={raw}" if cfg.PUBLIC_URL.startswith("https://") else None
    return 201, {"id": invitation_id, "role": role, "expires_at": expires_at, "token": raw,
                 "invite_url": invite_url}


@route("POST", "/api/v1/workspaces/join")
def accept_workspace_invitation(req):
    raw = need(req, "token")
    with db.tx():
        invitation = db.one("SELECT * FROM workspace_invitations WHERE token_hash=?", security.hash_token(raw))
        if (invitation is None or invitation["used_by"] is not None or invitation["revoked_at"] is not None
                or invitation["expires_at"] <= db.now_iso()):
            raise ApiError(404, "invitation_invalid", "Приглашение недействительно или истекло")
        existing = db.one("SELECT 1 FROM workspace_members WHERE workspace_id=? AND user_id=?",
                          invitation["workspace_id"], req.actor_user["id"])
        if existing:
            raise ApiError(409, "already_member", "Вы уже состоите в этом рабочем пространстве")
        db.run("INSERT INTO workspace_members(workspace_id, user_id, role, joined_at) VALUES(?,?,?,?)",
               invitation["workspace_id"], req.actor_user["id"], invitation["role"], db.now_iso())
        db.run("UPDATE workspace_invitations SET used_by=? WHERE id=? AND used_by IS NULL",
               req.actor_user["id"], invitation["id"])
    db.audit(req.actor_user["id"], "workspace_joined", method="POST", status=200,
             request_id=req.request_id, workspace_id=invitation["workspace_id"])
    workspace = db.one("SELECT w.*, m.role FROM workspaces w JOIN workspace_members m ON m.workspace_id=w.id "
                       "WHERE w.id=? AND m.user_id=?", invitation["workspace_id"], req.actor_user["id"])
    return {"workspace": workspace_dict(workspace)}


@route("DELETE", "/api/v1/workspaces/<int:id>/invitations/<int:invitation_id>")
def revoke_workspace_invitation(req):
    workspace_id = req.params["id"]
    actor_role = require_role(req, workspace_id, "admin")
    row = db.one("SELECT * FROM workspace_invitations WHERE id=? AND workspace_id=?",
                 req.params["invitation_id"], workspace_id)
    if row is None:
        raise NOT_FOUND
    if actor_role != "owner" and row["role"] == "admin":
        raise ApiError(403, "workspace_forbidden", "Только владелец может отозвать приглашение администратора")
    db.run("UPDATE workspace_invitations SET revoked_at=? WHERE id=?", db.now_iso(), row["id"])
    db.audit(req.actor_user["id"], "workspace_invitation_revoked", method="DELETE", status=200,
             entity_id=row["id"], request_id=req.request_id, workspace_id=workspace_id)
    return {"ok": True}


@route("PUT", "/api/v1/workspaces/<int:id>/members/<int:user_id>")
def update_workspace_member(req):
    workspace_id, user_id = req.params["id"], req.params["user_id"]
    actor_role = require_role(req, workspace_id, "admin")
    member = db.one("SELECT * FROM workspace_members WHERE workspace_id=? AND user_id=?", workspace_id, user_id)
    if member is None:
        raise NOT_FOUND
    role = str(req.body.get("role") or "")
    if role not in ("admin", "moderator", "viewer") or member["role"] == "owner":
        raise ApiError(422, "invalid_role", "Роль участника нельзя изменить")
    if actor_role != "owner" and (role == "admin" or member["role"] == "admin"):
        raise ApiError(403, "workspace_forbidden", "Только владелец может назначать администраторов")
    db.run("UPDATE workspace_members SET role=? WHERE workspace_id=? AND user_id=?", role, workspace_id, user_id)
    db.audit(req.actor_user["id"], "workspace_member_role_changed", method="PUT", status=200,
             entity_id=user_id, request_id=req.request_id, workspace_id=workspace_id)
    return {"user_id": user_id, "role": role}


@route("DELETE", "/api/v1/workspaces/<int:id>/members/<int:user_id>")
def remove_workspace_member(req):
    workspace_id, user_id = req.params["id"], req.params["user_id"]
    actor_role = require_role(req, workspace_id, "admin")
    member = db.one("SELECT * FROM workspace_members WHERE workspace_id=? AND user_id=?", workspace_id, user_id)
    if member is None:
        raise NOT_FOUND
    if member["role"] == "owner" or (actor_role != "owner" and member["role"] == "admin"):
        raise ApiError(403, "workspace_forbidden", "Недостаточно прав для отзыва доступа")
    db.run("DELETE FROM workspace_members WHERE workspace_id=? AND user_id=?", workspace_id, user_id)
    db.audit(req.actor_user["id"], "workspace_member_removed", method="DELETE", status=200,
             entity_id=user_id, request_id=req.request_id, workspace_id=workspace_id)
    return {"ok": True}


@route("DELETE", "/api/v1/workspaces/<int:id>/members/me")
def leave_workspace(req):
    workspace_id = req.params["id"]
    member = db.one("SELECT role FROM workspace_members WHERE workspace_id=? AND user_id=?",
                    workspace_id, req.actor_user["id"])
    if member is None:
        raise NOT_FOUND
    if member["role"] == "owner":
        raise ApiError(409, "owner_cannot_leave", "Владелец не может покинуть своё рабочее пространство")
    db.run("DELETE FROM workspace_members WHERE workspace_id=? AND user_id=?", workspace_id, req.actor_user["id"])
    db.audit(req.actor_user["id"], "workspace_left", method="DELETE", status=200,
             request_id=req.request_id, workspace_id=workspace_id)
    return {"ok": True}


# ====================================================================== me / settings
@route("GET", "/api/v1/me")
def me(req):
    db.run("UPDATE users SET last_seen_at=? WHERE id=?", db.now_iso(), req.user["id"])
    return user_dict(req.user)


@route("PUT", "/api/v1/me")
def update_me(req):
    uid = req.user["id"]
    lang = req.body.get("language", req.user["language"])
    if lang not in ("ru", "en"):
        raise ApiError(422, "validation", "Язык: ru или en")
    tz = req.body.get("timezone", req.user["timezone"])
    try:
        ZoneInfo(tz)
    except Exception:
        raise ApiError(422, "validation", "Неизвестный часовой пояс")
    notify = 1 if req.body.get("notify", bool(req.user["notify"])) else 0
    name = str(req.body.get("first_name", req.user["first_name"]))[:80]
    theme = req.body.get("theme", req.user["theme"] if "theme" in req.user.keys() else "light")
    if theme not in ("light", "dark", "system"):
        raise ApiError(422, "validation", "Тема: light, dark или system")
    ui_density = req.body.get("ui_density", req.user["ui_density"] if "ui_density" in req.user.keys() else "comfortable")
    if ui_density not in ("comfortable", "compact", "wide"):
        raise ApiError(422, "validation", "Плотность: comfortable, compact или wide")
    security_mode = req.body.get("security_mode", req.user["security_mode"] if "security_mode" in req.user.keys() else "standard")
    if security_mode not in ("standard", "strict"):
        raise ApiError(422, "validation", "Режим безопасности: standard или strict")
    db.run("UPDATE users SET language=?, timezone=?, notify=?, first_name=?, theme=?, ui_density=?, security_mode=? WHERE id=?",
           lang, tz, notify, name, theme, ui_density, security_mode, uid)
    return user_dict(db.one("SELECT * FROM users WHERE id=?", uid))


@route("GET", "/api/v1/settings")
def get_settings(req):
    return {
        "language": req.user["language"],
        "timezone": req.user["timezone"],
        "notify": bool(req.user["notify"]),
        "theme": req.user["theme"] if "theme" in req.user.keys() else "light",
        "ui_density": req.user["ui_density"] if "ui_density" in req.user.keys() else "comfortable",
        "security_mode": req.user["security_mode"] if "security_mode" in req.user.keys() else "standard",
        "plan": req.user["plan"],
        "features": PLANS.get(req.user["plan"], PLANS["free"]).get("features", []),
    }


@route("PUT", "/api/v1/settings")
def update_settings(req):
    payload = {**req.body}
    if not payload:
        return get_settings(req)
    return update_me(req)


@route("POST", "/api/v1/me/test-notification")
def test_notification(req):
    if req.user["is_demo"]:
        return {"sent": False, "reason": "Демо-пользователь: Telegram-уведомления не отправляются. Войдите через Telegram."}
    if not telegram.is_live():
        return {"sent": False, "reason": "Бот не подключён к Telegram."}
    try:
        telegram.client().send_message(req.user["telegram_id"], "🔔 Тестовое уведомление MarketPilot. Всё работает!", None)
    except (telegram.TelegramError, telegram.TelegramNetworkError) as e:
        return {"sent": False, "reason": f"Telegram: {e}. Откройте чат с ботом и нажмите /start."}
    return {"sent": True}


@route("POST", "/api/v1/me/demo-data")
def load_demo_data(req):
    """Add demo resources/posts to a real account so the interface is not empty (clearly flagged as demo)."""
    if db.one("SELECT 1 FROM resources WHERE user_id=? AND is_demo=1", req.user["id"]):
        raise ApiError(409, "already_loaded", "Демо-данные уже загружены")
    with db.tx():
        seed.seed_demo(req.user["id"])
    return {"ok": True}


@route("DELETE", "/api/v1/me/demo-data")
def remove_demo_data(req):
    uid = req.user["id"]
    with db.tx():
        ids = [r["id"] for r in db.q("SELECT id FROM resources WHERE user_id=? AND is_demo=1", uid)]
        for rid in ids:
            db.run("DELETE FROM resources WHERE id=?", rid)  # cascades to targets, snapshots, stats
        db.run("DELETE FROM posts WHERE user_id=? AND id NOT IN (SELECT post_id FROM post_targets)", uid)
        db.run("DELETE FROM events WHERE user_id=? AND resource_id IS NULL AND message LIKE '%демо%'", uid)
    return {"ok": True, "removed": len(ids)}


@route("POST", "/api/v1/me/reset-demo")
def reset_demo(req):
    if not req.user["is_demo"]:
        raise ApiError(403, "not_demo", "Только для демо-пользователя")
    uid = req.user["id"]
    with db.tx():
        for table in ("resources", "posts", "templates", "events"):
            db.run(f"DELETE FROM {table} WHERE user_id=?", uid)
        seed.seed_demo(uid)
    return {"ok": True}


@route("DELETE", "/api/v1/me")
def delete_me(req):
    """Account and data deletion (spec 21.12)."""
    db.run("DELETE FROM users WHERE id=?", req.user["id"])
    req.clear_session()
    return {"ok": True}


@route("GET", "/api/v1/billing/plans")
def billing_plans(req):
    """Public tariffs only (FREE / PRO / BUSINESS). The user's own legacy plan is shown too, so it never disappears."""
    names = list(PUBLIC_PLANS)
    if req.user is not None and req.user["plan"] in LEGACY_PLANS:
        names.append(req.user["plan"])
    return {"billing_mode": cfg.BILLING_MODE, "current": req.user["plan"] if req.user is not None else None,
            "plans": {name: {"price": PLANS[name]["price"], "resources": PLANS[name]["resources"],
                             "features": PLANS[name].get("features", []), "legacy": name in LEGACY_PLANS}
                      for name in names}}


@route("GET", "/api/v1/subscriptions")
def list_subscriptions(req):
    rows = db.q("SELECT * FROM subscriptions WHERE user_id=? ORDER BY id DESC", req.user["id"])
    if not rows:
        plan = "free"
        row_id = db.insert(
            "subscriptions",
            user_id=req.user["id"],
            plan=plan,
            status="active",
            started_at=db.now_iso(),
            created_at=db.now_iso(),
        )
        rows = db.q("SELECT * FROM subscriptions WHERE id=?", row_id)
    return {"items": [{
        "id": r["id"],
        "plan": r["plan"],
        "status": r["status"],
        "started_at": r["started_at"],
        "ends_at": r["ends_at"],
        "auto_renew": bool(r["auto_renew"]),
        "created_at": r["created_at"],
    } for r in rows], "count": len(rows)}


@route("POST", "/api/v1/subscriptions")
def create_subscription(req):
    plan = str(req.body.get("plan") or req.user["plan"] or "free").lower()
    if plan not in PLANS:
        raise ApiError(422, "validation", "Неверный тариф")
    if plan in LEGACY_PLANS and plan != req.user["plan"]:
        raise ApiError(422, "validation", "Этот тариф больше не продаётся. Доступны FREE, PRO и BUSINESS")
    # Upgrade to a paid tariff needs a confirmed payment. Without this check anyone could grant themselves BUSINESS.
    if PLANS[plan]["price"] > PLANS.get(req.user["plan"], PLANS["free"])["price"] and cfg.BILLING_MODE != "sandbox":
        raise ApiError(402, "payment_required", "Оплата тарифа ещё не подключена. Обратитесь в поддержку.")
    row_id = db.insert(
        "subscriptions",
        user_id=req.user["id"],
        plan=plan,
        status="active",
        started_at=db.now_iso(),
        created_at=db.now_iso(),
    )
    db.run("UPDATE users SET plan=? WHERE id=?", plan, req.user["id"])
    row = db.one("SELECT * FROM subscriptions WHERE id=?", row_id)
    db.event(req.user["id"], "subscription_created", f"Подписка сменена на тариф {plan}", None)
    return 201, {
        "id": row["id"],
        "plan": row["plan"],
        "status": row["status"],
        "started_at": row["started_at"],
        "ends_at": row["ends_at"],
        "auto_renew": bool(row["auto_renew"]),
        "created_at": row["created_at"],
    }


@route("GET", "/api/v1/audit-log")
def audit_log(req):
    """The signed-in user's own action journal (newest first, cursor pagination via before_id)."""
    uid = req.user["id"]
    sql, args = "SELECT * FROM audit_log WHERE user_id=?", [uid]
    if req.query.get("resource_id", "").isdigit():
        sql += " AND resource_id=?"
        args.append(int(req.query["resource_id"]))
    if req.query.get("failed") == "1":
        sql += " AND status>=400"
    if req.query.get("action"):
        sql += " AND action LIKE ?"
        args.append("%" + req.query["action"][:60].replace("%", "") + "%")
    if req.query.get("before_id", "").isdigit():
        sql += " AND id<?"
        args.append(int(req.query["before_id"]))
    limit = req.int_param("limit", 50, 1, 200)
    rows = db.q(sql + " ORDER BY id DESC LIMIT ?", *args, limit + 1)
    more = len(rows) > limit
    rows = rows[:limit]
    return {"items": [{k: r[k] for k in ("id", "action", "status", "resource_id", "entity_id", "request_id", "error",
                                         "created_at")} for r in rows],
            "next_before_id": rows[-1]["id"] if more and rows else None}


@route("GET", "/api/v1/premium/summary")
def premium_summary(req):
    sub = db.one("SELECT * FROM subscriptions WHERE user_id=? ORDER BY id DESC LIMIT 1", req.user["id"])
    plan = req.user["plan"] or "free"
    return {
        "plan": plan,
        "status": sub["status"] if sub else "none",
        "active": bool(sub and sub["status"] == "active"),
        "next_renewal": sub["ends_at"] if sub else None,
        "features": PLANS.get(plan, PLANS["free"]).get("features", []),
        "auto_renew": bool(sub["auto_renew"]) if sub else False,
    }


@route("GET", "/api/v1/premium/history")
def premium_history(req):
    rows = db.q(
        "SELECT id, kind, message, resource_id, created_at FROM events WHERE user_id=? AND kind LIKE 'subscription_%' ORDER BY id DESC LIMIT 50",
        req.user["id"],
    )
    return {"items": [{"id": r["id"], "kind": r["kind"], "message": r["message"], "resource_id": r["resource_id"], "created_at": r["created_at"]} for r in rows], "count": len(rows)}


@route("POST", "/api/v1/subscriptions/<int:id>/renew")
def renew_subscription(req):
    row = db.one("SELECT * FROM subscriptions WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    if PLANS.get(row["plan"], PLANS["free"])["price"] > 0 and cfg.BILLING_MODE != "sandbox":
        raise ApiError(402, "payment_required", "Продление требует подтверждённой оплаты, она ещё не подключена.")
    months = max(1, int(req.body.get("months", 1) or 1))
    base = db.parse_iso(row["ends_at"]) if row["ends_at"] else db.now()
    if base < db.now():
        base = db.now()
    new_end = db.iso(base + timedelta(days=30 * months))
    db.run("UPDATE subscriptions SET status='active', auto_renew=1, started_at=?, ends_at=? WHERE id=? AND user_id=?",
           db.now_iso(), new_end, req.params["id"], req.user["id"])
    db.event(req.user["id"], "subscription_renewed", f"Подписка {row['plan']} продлена до {new_end}", None)
    updated = db.one("SELECT * FROM subscriptions WHERE id=?", req.params["id"])
    return {"id": updated["id"], "plan": updated["plan"], "status": updated["status"], "started_at": updated["started_at"], "ends_at": updated["ends_at"], "auto_renew": bool(updated["auto_renew"]), "created_at": updated["created_at"]}


@route("POST", "/api/v1/subscriptions/<int:id>/cancel")
def cancel_subscription(req):
    row = db.one("SELECT * FROM subscriptions WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    db.run("UPDATE subscriptions SET status='cancelled', auto_renew=0 WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    db.event(req.user["id"], "subscription_cancelled", f"Подписка {row['plan']} отменена", None)
    updated = db.one("SELECT * FROM subscriptions WHERE id=?", req.params["id"])
    return {"id": updated["id"], "plan": updated["plan"], "status": updated["status"], "started_at": updated["started_at"], "ends_at": updated["ends_at"], "auto_renew": bool(updated["auto_renew"]), "created_at": updated["created_at"]}


@route("GET", "/api/v1/ads")
def list_ads(req):
    require_feature(req, "ads", "рекламным кампаниям")
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM ad_campaigns WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC"
    rows = db.q(sql, *args)
    return {"items": [{
        "id": r["id"],
        "resource_id": r["resource_id"],
        "title": r["title"],
        "budget": float(r["budget"]),
        "spend": float(r["spend"]),
        "status": r["status"],
        "starts_at": r["starts_at"],
        "ends_at": r["ends_at"],
        "created_at": r["created_at"],
        "updated_at": r["updated_at"],
    } for r in rows], "count": len(rows)}


@route("POST", "/api/v1/ads")
def create_ad(req):
    require_feature(req, "ads", "рекламным кампаниям")
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    title = str(req.body.get("title") or "Advertising").strip()[:80] or "Advertising"
    budget = float(req.body.get("budget", 0) or 0)
    status = str(req.body.get("status") or "scheduled").lower()
    if status not in {"scheduled", "running", "paused", "completed", "draft"}:
        raise ApiError(422, "validation", "Неверный статус кампании")
    starts_at = req.body.get("starts_at")
    ends_at = req.body.get("ends_at")
    if starts_at is not None:
        parse_when(str(starts_at))
    if ends_at is not None:
        parse_when(str(ends_at))
    now_iso = db.now_iso()
    campaign_id = db.insert(
        "ad_campaigns",
        user_id=req.user["id"],
        resource_id=rid,
        title=title,
        budget=budget,
        spend=0,
        status=status,
        starts_at=starts_at,
        ends_at=ends_at,
        created_at=now_iso,
        updated_at=now_iso,
    )
    camp = db.one("SELECT * FROM ad_campaigns WHERE id=?", campaign_id)
    return 201, {
        "id": camp["id"],
        "resource_id": camp["resource_id"],
        "title": camp["title"],
        "budget": float(camp["budget"]),
        "spend": float(camp["spend"]),
        "status": camp["status"],
        "starts_at": camp["starts_at"],
        "ends_at": camp["ends_at"],
        "created_at": camp["created_at"],
        "updated_at": camp["updated_at"],
    }


@route("PUT", "/api/v1/ads/<int:id>")
def update_ad(req):
    require_feature(req, "ads", "рекламным кампаниям")
    row = db.one("SELECT * FROM ad_campaigns WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    data = {**row}
    for key in ("resource_id", "title", "budget", "status", "starts_at", "ends_at"):
        if key in req.body:
            data[key] = req.body[key]
    db.run(
        "UPDATE ad_campaigns SET resource_id=?, title=?, budget=?, status=?, starts_at=?, ends_at=?, updated_at=? WHERE id=? AND user_id=?",
        int(data.get("resource_id") or row["resource_id"]),
        str(data.get("title") or row["title"])[:80] or row["title"],
        float(data.get("budget") if data.get("budget") is not None else row["budget"]),
        str(data.get("status") or row["status"]).lower(),
        data.get("starts_at") or row["starts_at"],
        data.get("ends_at") or row["ends_at"],
        db.now_iso(),
        req.params["id"],
        req.user["id"],
    )
    updated = db.one("SELECT * FROM ad_campaigns WHERE id=?", req.params["id"])
    return {
        "id": updated["id"],
        "resource_id": updated["resource_id"],
        "title": updated["title"],
        "budget": float(updated["budget"]),
        "spend": float(updated["spend"]),
        "status": updated["status"],
        "starts_at": updated["starts_at"],
        "ends_at": updated["ends_at"],
        "created_at": updated["created_at"],
        "updated_at": updated["updated_at"],
    }


@route("DELETE", "/api/v1/ads/<int:id>")
def delete_ad(req):
    require_feature(req, "ads", "рекламным кампаниям")
    cur = db.run("DELETE FROM ad_campaigns WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


@route("GET", "/api/v1/export")
def export_data(req):
    require_feature(req, "export", "экспортом")
    kind = str(req.query.get("kind") or "resources").lower()
    if kind not in {"resources", "posts", "moderation", "ads"}:
        raise ApiError(422, "validation", "Неверный тип экспорта")
    q = {
        "resources": ("SELECT id, title, username, type, status, members, connected_at FROM resources WHERE user_id=? ORDER BY id DESC", [req.user["id"]]),
        "posts": ("SELECT id, text, created_at FROM posts WHERE user_id=? ORDER BY id DESC LIMIT 200", [req.user["id"]]),
        "moderation": ("SELECT id, resource_id, rule_id, kind, message, risk_score, created_at FROM moderation_events WHERE user_id=? ORDER BY id DESC LIMIT 200", [req.user["id"]]),
        "ads": ("SELECT id, title, budget, spend, status, starts_at, ends_at FROM ad_campaigns WHERE user_id=? ORDER BY id DESC", [req.user["id"]]),
    }
    rows = [dict(r) for r in db.q(q[kind][0], *q[kind][1])]
    headers = list(rows[0].keys()) if rows else []
    csv_lines = [",".join(headers)] if headers else []
    for row in rows:
        csv_lines.append(",".join(str(row.get(h, "")) for h in headers))
    payload = {"kind": kind, "count": len(rows), "items": rows, "csv": "\n".join(csv_lines), "filename": f"{kind}-{db.now_iso()[:10]}.csv"}
    payload[kind] = rows
    return payload


# ====================================================================== resources
def decorate_resources(user_id: int, rows) -> list[dict]:
    out = []
    week_ago = db.iso(db.days_ago(7))
    for r in rows:
        d = res_dict(r)
        snaps = db.q("SELECT members FROM snapshots WHERE resource_id=? AND taken_at>=? ORDER BY taken_at", r["id"], week_ago)
        d["members_delta_7d"] = snaps[-1]["members"] - snaps[0]["members"] if len(snaps) >= 2 else None
        d["published_total"] = db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status='published'",
                                      r["id"])["n"]
        d["scheduled_count"] = db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status='scheduled'",
                                      r["id"])["n"]
        out.append(d)
    return out


@route("GET", "/api/v1/resources")
def list_resources(req):
    uid = req.user["id"]
    sql, args = "SELECT * FROM resources WHERE user_id=?", [uid]
    if req.query.get("type"):
        types = {"channel": ("channel",), "group": ("group", "supergroup")}.get(req.query["type"], ())
        if types:
            sql += f" AND type IN ({','.join('?' * len(types))})"
            args += list(types)
    if req.query.get("status"):
        sql += " AND status=?"
        args.append(req.query["status"])
    if req.query.get("q"):
        sql += " AND (title LIKE ? OR username LIKE ?)"
        args += [f"%{req.query['q']}%"] * 2
    sql += " ORDER BY (status='disconnected'), title"
    return {"items": decorate_resources(uid, db.q(sql, *args))}


@route("GET", "/api/v1/resources/<int:id>")
def get_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    d = decorate_resources(uid, [r])[0]
    d["recent_events"] = [dict(e) for e in db.q(
        "SELECT kind, message, created_at FROM events WHERE user_id=? AND resource_id=? ORDER BY id DESC LIMIT 8",
        uid, r["id"])]
    d["automations"] = []  # stage 4
    return d


@route("POST", "/api/v1/resources/link-code")
def link_code(req):
    uid = req.user["id"]
    tg_user = req.user["telegram_id"] if "telegram_id" in req.user.keys() else 0
    info = plan_info(req.user)
    if info["resources_used"] >= info["resource_limit"]:
        raise ApiError(402, "limit", f"Лимит тарифа: {info['resource_limit']} ресурсов")
    if not telegram.is_live():
        return {"live": False, "message": "Telegram-бот не подключён (нет BOT_TOKEN или нет связи). "
                "Добавьте токен в .env и перезапустите приложение — а пока можно добавить демо-ресурс."}
    code = secrets.token_hex(4).upper()
    db.insert("link_codes", code=code, user_id=uid, created_by_telegram_id=int(tg_user or 0),
              expires_at=db.iso(db.now() + timedelta(minutes=15)))
    return {"live": True, "code": code, "bot_username": telegram.state["username"], "expires_in": 900}


@route("GET", "/api/v1/resources/link-status")
def link_status(req):
    """Polled by the UI while waiting for /connect: returns resources connected in the last 15 minutes."""
    rows = db.q("SELECT * FROM resources WHERE user_id=? AND is_demo=0 AND connected_at>=? ORDER BY id DESC",
                req.user["id"], db.iso(db.now() - timedelta(minutes=15)))
    return {"items": [res_dict(r) for r in rows]}


@route("POST", "/api/v1/resources/demo")
def add_demo_resource(req):
    uid = req.user["id"]
    if db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND is_demo=1", uid)["n"] >= 20:
        raise ApiError(409, "limit", "Слишком много демо-ресурсов")
    title = str(need(req, "title")).strip()[:80]
    rtype = req.body.get("type", "channel")
    if rtype not in ("channel", "group", "supergroup"):
        raise ApiError(422, "validation", "Тип: channel, group или supergroup")
    try:
        members = max(0, min(int(req.body.get("members", 1000)), 100_000_000))
    except (TypeError, ValueError):
        raise ApiError(422, "validation", "Число подписчиков должно быть числом")
    with db.tx():
        rid = seed.add_demo_resource(uid, {"title": title, "username": None, "type": rtype, "members": members,
                                           "rights": "full"})
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", rid))


@route("POST", "/api/v1/resources/<int:id>/check")
def check_resource(req):
    from . import scheduler
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    if r["is_demo"]:
        db.run("UPDATE resources SET last_checked_at=? WHERE id=?", db.now_iso(), r["id"])
    else:
        if not telegram.is_live():
            raise ApiError(409, "telegram_not_connected", "Бот не подключён к Telegram")
        scheduler.refresh_resource(r)
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("POST", "/api/v1/resources/<int:id>/simulate-rights")
def simulate_rights(req):
    """Demo only: toggle the 'publish' right of a demo resource to show how the product reacts to revoked rights."""
    r = resource_row(req.user["id"], req.params["id"])
    if not r["is_demo"]:
        raise ApiError(403, "not_demo", "Только для демо-ресурсов")
    caps = db.jl(r["capabilities"])
    if "publish" in caps:
        caps = [c for c in caps if c not in ("publish", "edit_messages")]
        missing, status = ["can_post_messages"], "missing_rights"
        msg = f"Права бота в «{r['title']}» изменены: не хватает can_post_messages (демо)"
    else:
        caps = ["publish", "edit_messages", "delete_messages"] if r["type"] == "channel" else \
            ["publish", "delete_messages", "restrict_members", "pin_messages"]
        missing, status = [], "active"
        msg = f"Права бота в «{r['title']}» восстановлены (демо)"
    db.run("UPDATE resources SET capabilities=?, missing_rights=?, status=?, last_checked_at=? WHERE id=?",
           json.dumps(caps), json.dumps(missing), status, db.now_iso(), r["id"])
    db.event(r["user_id"], "rights_changed", msg, r["id"])
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("DELETE", "/api/v1/resources/<int:id>")
def disconnect_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    with db.tx():
        db.run("UPDATE resources SET status='disconnected' WHERE id=?", r["id"])
        bot.cancel_pending(r["id"], "Ресурс отключён")
        db.event(uid, "resource_disconnected", f"Ресурс «{r['title']}» отключён", r["id"])
    return {"ok": True}


@route("POST", "/api/v1/resources/<int:id>/reconnect")
def reconnect_resource(req):
    uid = req.user["id"]
    r = resource_row(uid, req.params["id"])
    if r["status"] != "disconnected":
        raise ApiError(409, "bad_state", "Ресурс уже подключён")
    if not r["is_demo"]:
        raise ApiError(409, "need_link", "Подключите ресурс заново через бота (/connect КОД)")
    db.run("UPDATE resources SET status='active' WHERE id=?", r["id"])
    return res_dict(db.one("SELECT * FROM resources WHERE id=?", r["id"]))


@route("DELETE", "/api/v1/resources/<int:id>/forget")
def forget_resource(req):
    """Remove a disconnected resource and its history for good."""
    r = resource_row(req.user["id"], req.params["id"])
    if r["status"] != "disconnected":
        raise ApiError(409, "bad_state", "Сначала отключите ресурс")
    db.run("DELETE FROM resources WHERE id=?", r["id"])
    return {"ok": True}


# ====================================================================== posts
def load_targets(post_ids: list[int]) -> dict[int, list[dict]]:
    if not post_ids:
        return {}
    marks = ",".join("?" * len(post_ids))
    rows = db.q(f"SELECT t.*, r.title AS resource_title FROM post_targets t JOIN resources r ON r.id=t.resource_id "
                f"WHERE t.post_id IN ({marks}) ORDER BY t.id", *post_ids)
    out: dict[int, list[dict]] = {}
    for t in rows:
        out.setdefault(t["post_id"], []).append(target_dict(t))
    return out


def post_dict(p, targets) -> dict:
    return {"id": p["id"], "text": p["text"], "image_url": p["image_url"], "created_at": p["created_at"],
            "updated_at": p["updated_at"], "targets": targets}


def post_row(uid: int, pid: int):
    p = db.one("SELECT * FROM posts WHERE id=? AND user_id=?", pid, uid)
    if p is None:
        raise NOT_FOUND
    return p


@route("GET", "/api/v1/posts")
def list_posts(req):
    uid = req.user["id"]
    where, args = ["p.user_id=?"], [uid]
    if req.query.get("status"):
        where.append("EXISTS(SELECT 1 FROM post_targets t WHERE t.post_id=p.id AND t.status=?)")
        args.append(req.query["status"])
    if req.query.get("resource_id", "").isdigit():
        where.append("EXISTS(SELECT 1 FROM post_targets t WHERE t.post_id=p.id AND t.resource_id=?)")
        args.append(int(req.query["resource_id"]))
    if req.query.get("q"):
        where.append("p.text LIKE ?")
        args.append(f"%{req.query['q']}%")
    cond = " AND ".join(where)
    total = db.one(f"SELECT COUNT(*) n FROM posts p WHERE {cond}", *args)["n"]
    limit, offset = req.int_param("limit", 30, 1, 100), req.int_param("offset", 0, 0, 10**7)
    rows = db.q(f"SELECT p.* FROM posts p WHERE {cond} ORDER BY p.id DESC LIMIT ? OFFSET ?", *args, limit, offset)
    tmap = load_targets([r["id"] for r in rows])
    return {"total": total, "items": [post_dict(r, tmap.get(r["id"], [])) for r in rows]}


@route("GET", "/api/v1/posts/<int:id>")
def get_post(req):
    p = post_row(req.user["id"], req.params["id"])
    return post_dict(p, load_targets([p["id"]]).get(p["id"], []))


@route("POST", "/api/v1/media")
def upload_media(req):
    data = req.raw_body
    mime = req.upload_mime
    valid_signature = (mime == "image/jpeg" and data.startswith(b"\xff\xd8\xff")) or (
        mime == "image/png" and data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24) or (
        mime == "image/webp" and len(data) >= 12 and data.startswith(b"RIFF") and data[8:12] == b"WEBP")
    if not valid_signature:
        raise ApiError(415, "invalid_image", "Содержимое файла не соответствует формату изображения")
    if mime == "image/png":
        width, height = int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
        if not width or not height or width + height > 10000 or max(width, height) / min(width, height) > 20:
            raise ApiError(422, "invalid_image", "Недопустимый размер изображения")
    uid = req.user["id"]
    used = db.one("SELECT COALESCE(SUM(size),0) n FROM media_uploads WHERE user_id=?", uid)["n"]
    if used + len(data) > 100 * 1024 * 1024:
        raise ApiError(413, "storage_limit", "Достигнут лимит хранения изображений 100 MiB")
    name = Path(req.upload_name.replace("\\", "/")).name
    name = re.sub(r"[^\w.() -]", "_", name, flags=re.UNICODE).strip(" .")[:120] or "image"
    media_id = db.insert("media_uploads", user_id=uid, filename=name, mime=mime, size=len(data),
                         sha256=hashlib.sha256(data).hexdigest(), data=data, created_at=db.now_iso())
    return 201, {"id": media_id, "filename": name, "mime": mime, "size": len(data), "image_url": f"upload:{media_id}"}


@route("GET", "/api/v1/media/<int:id>")
def get_uploaded_media(req):
    row = db.one("SELECT id, filename, mime, size, data FROM media_uploads WHERE id=? AND user_id=?",
                 req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    return {"id": row["id"], "filename": row["filename"], "mime": row["mime"], "size": row["size"],
            "data": base64.b64encode(row["data"]).decode("ascii")}


def read_post_body(req, uid: int):
    """Validate the editor payload. Returns (text, image_url, resources, mode, when)."""
    text = str(req.body.get("text", "")).strip()
    image = req.body.get("image_url")
    if isinstance(image, str) and image.startswith("upload:"):
        try:
            media_id = int(image.partition(":")[2])
        except ValueError:
            raise ApiError(422, "validation", "Неверное загруженное изображение")
        if db.one("SELECT id FROM media_uploads WHERE id=? AND user_id=?", media_id, uid) is None:
            raise NOT_FOUND
    else:
        image = validate_image(image)
    if not text and not image:
        raise ApiError(422, "validation", "Добавьте текст или изображение")
    validate_text(text, bool(image))
    ids = req.body.get("resource_ids")
    if not isinstance(ids, list) or not ids or not all(isinstance(i, int) for i in ids):
        raise ApiError(422, "validation", "Выберите хотя бы один ресурс")
    ids = list(dict.fromkeys(ids))
    resources = []
    for rid in ids:
        r = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, uid)
        if r is None:
            raise NOT_FOUND
        if r["status"] == "disconnected":
            raise ApiError(422, "validation", f"Ресурс «{r['title']}» отключён")
        resources.append(r)
    mode = req.body.get("mode", "draft")
    if mode not in ("draft", "schedule", "now"):
        raise ApiError(422, "validation", "mode: draft, schedule или now")
    when = None
    if mode == "schedule":
        when = parse_when(need(req, "scheduled_at"))
        if when < db.now() - timedelta(minutes=1):
            raise ApiError(422, "past", "Время публикации уже прошло")
        if when > db.now() + timedelta(days=366):
            raise ApiError(422, "validation", "Дата слишком далеко (максимум год)")
    elif mode == "now":
        when = db.now()
    if mode != "draft":
        for r in resources:
            if r["status"] != "active" or "publish" not in db.jl(r["capabilities"]):
                raise ApiError(422, "no_rights", f"В «{r['title']}» у бота нет прав на публикацию — "
                               "исправьте права или сохраните как черновик")
    return text, image, resources, mode, when


def write_targets(uid: int, pid: int, resources, mode: str, when) -> None:
    status = "draft" if mode == "draft" else "scheduled"
    for r in resources:
        db.insert("post_targets", post_id=pid, user_id=uid, resource_id=r["id"], status=status,
                  scheduled_at=db.iso(when) if when else None)


def enforce_publication_limit(uid: int, resource_id: int, when, exclude_post_id: int | None = None) -> None:
    limit = db.one(
        "SELECT * FROM publication_limits WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY id DESC LIMIT 1",
        uid, resource_id,
    )
    if limit is None or limit["kind"] != "messages_per_day":
        return
    user = db.one("SELECT timezone FROM users WHERE id=?", uid)
    tz = user_tz(user)
    local_when = when.astimezone(tz)
    day_start = datetime(local_when.year, local_when.month, local_when.day, tzinfo=tz)
    start_utc = db.iso(day_start.astimezone(timezone.utc))
    end_utc = db.iso((day_start + timedelta(days=1)).astimezone(timezone.utc))
    exclusion = " AND post_id!=?" if exclude_post_id is not None else ""
    args = [uid, resource_id, start_utc, end_utc]
    if exclude_post_id is not None:
        args.append(exclude_post_id)
    count = db.one(
        "SELECT COUNT(*) n FROM post_targets WHERE user_id=? AND resource_id=? "
        "AND status IN ('scheduled','publishing','published') "
        "AND COALESCE(scheduled_at,published_at)>=? AND COALESCE(scheduled_at,published_at)<?" + exclusion,
        *args,
    )["n"]
    if count >= int(limit["value"]):
        raise ApiError(422, "limit_exceeded", f"Лимит публикаций для этого сообщества достигнут: {limit['value']} в день")


@route("GET", "/api/v1/publication-limits")
def list_publication_limits(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM publication_limits WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC"
    return {"items": [publication_limit_dict(r) for r in db.q(sql, *args)]}


@route("POST", "/api/v1/publication-limits")
def create_publication_limit(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    kind = str(req.body.get("kind") or "messages_per_day").lower()
    if kind not in {"messages_per_day"}:
        raise ApiError(422, "validation", "Неверный тип лимита")
    value = int(req.body.get("value", 1))
    if value <= 0:
        raise ApiError(422, "validation", "Значение лимита должно быть больше нуля")
    row = db.one("SELECT * FROM publication_limits WHERE user_id=? AND resource_id=? AND kind=?", req.user["id"], rid, kind)
    if row is None:
        row_id = db.insert("publication_limits", user_id=req.user["id"], resource_id=rid, kind=kind, value=value,
                           enabled=1, created_at=db.now_iso())
        row = db.one("SELECT * FROM publication_limits WHERE id=?", row_id)
    else:
        db.run("UPDATE publication_limits SET value=?, enabled=1 WHERE id=?", value, row["id"])
        row = db.one("SELECT * FROM publication_limits WHERE id=?", row["id"])
    return 201, publication_limit_dict(row)


@route("PUT", "/api/v1/publication-limits/<int:id>")
def update_publication_limit(req):
    row = db.one("SELECT * FROM publication_limits WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    kind = str(req.body.get("kind", row["kind"]) or row["kind"]).lower()
    value = int(req.body.get("value", row["value"]))
    if kind not in {"messages_per_day"}:
        raise ApiError(422, "validation", "Неверный тип лимита")
    if value <= 0:
        raise ApiError(422, "validation", "Значение лимита должно быть больше нуля")
    db.run("UPDATE publication_limits SET kind=?, value=? WHERE id=? AND user_id=?", kind, value, req.params["id"], req.user["id"])
    updated = db.one("SELECT * FROM publication_limits WHERE id=?", req.params["id"])
    return publication_limit_dict(updated)


@route("DELETE", "/api/v1/publication-limits/<int:id>")
def delete_publication_limit(req):
    cur = db.run("DELETE FROM publication_limits WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


def message_limit_dict(row) -> dict:
    return {
        "id": row["id"], "resource_id": row["resource_id"], "resource_title": row["resource_title"],
        "max_messages": row["max_messages"], "action": row["action"],
        "exclude_admins": bool(row["exclude_admins"]), "notify_owner": bool(row["notify_owner"]),
        "enabled": bool(row["enabled"]), "created_at": row["created_at"], "updated_at": row["updated_at"],
    }


def _message_limit_row(uid: int, resource_id: int):
    return db.one("SELECT m.*, r.title AS resource_title FROM message_limits m "
                  "JOIN resources r ON r.id=m.resource_id WHERE m.user_id=? AND m.resource_id=?", uid, resource_id)


@route("GET", "/api/v1/message-limits")
def list_message_limits(req):
    rows = db.q("SELECT m.*, r.title AS resource_title FROM message_limits m "
                "JOIN resources r ON r.id=m.resource_id WHERE m.user_id=? ORDER BY r.title", req.user["id"])
    return {"items": [message_limit_dict(r) for r in rows]}


@route("POST", "/api/v1/message-limits")
def create_message_limit(req):
    uid = req.user["id"]
    resource_id = need(req, "resource_id", int)
    resource = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", resource_id, uid)
    if resource is None:
        raise NOT_FOUND
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(422, "validation", "Лимит сообщений участников доступен только для групп")
    if resource["is_demo"]:
        raise ApiError(422, "validation", "Для автоматического лимита подключите реальную группу")
    try:
        maximum = int(req.body.get("max_messages", 20))
    except (TypeError, ValueError):
        raise ApiError(422, "validation", "Укажите целое число сообщений")
    if not 1 <= maximum <= 10000:
        raise ApiError(422, "validation", "Лимит должен быть от 1 до 10000 сообщений")
    action = str(req.body.get("action") or "delete")
    if action not in {"delete", "delete_warn", "warn"}:
        raise ApiError(422, "validation", "Выберите допустимое действие при превышении")
    now = db.now_iso()
    db.run("INSERT INTO message_limits(user_id,resource_id,max_messages,action,exclude_admins,notify_owner,enabled,created_at,updated_at) "
           "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,resource_id) DO UPDATE SET max_messages=excluded.max_messages, "
           "action=excluded.action, exclude_admins=excluded.exclude_admins, notify_owner=excluded.notify_owner, "
           "enabled=excluded.enabled, updated_at=excluded.updated_at",
           uid, resource_id, maximum, action, int(bool(req.body.get("exclude_admins", True))),
           int(bool(req.body.get("notify_owner", True))), int(bool(req.body.get("enabled", True))), now, now)
    return 201, message_limit_dict(_message_limit_row(uid, resource_id))


@route("PUT", "/api/v1/message-limits/<int:id>")
def update_message_limit(req):
    uid = req.user["id"]
    row = db.one("SELECT * FROM message_limits WHERE id=? AND user_id=?", req.params["id"], uid)
    if row is None:
        raise NOT_FOUND
    try:
        maximum = int(req.body.get("max_messages", row["max_messages"]))
    except (TypeError, ValueError):
        raise ApiError(422, "validation", "Укажите целое число сообщений")
    if not 1 <= maximum <= 10000:
        raise ApiError(422, "validation", "Лимит должен быть от 1 до 10000 сообщений")
    action = str(req.body.get("action", row["action"]))
    if action not in {"delete", "delete_warn", "warn"}:
        raise ApiError(422, "validation", "Выберите допустимое действие при превышении")
    db.run("UPDATE message_limits SET max_messages=?, action=?, exclude_admins=?, notify_owner=?, enabled=?, updated_at=? "
           "WHERE id=? AND user_id=?", maximum, action,
           int(bool(req.body.get("exclude_admins", row["exclude_admins"]))),
           int(bool(req.body.get("notify_owner", row["notify_owner"]))),
           int(bool(req.body.get("enabled", row["enabled"]))), db.now_iso(), row["id"], uid)
    return message_limit_dict(_message_limit_row(uid, row["resource_id"]))


@route("DELETE", "/api/v1/message-limits/<int:id>")
def delete_message_limit(req):
    cur = db.run("DELETE FROM message_limits WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


@route("GET", "/api/v1/message-limits/log")
def list_message_limit_events(req):
    sql = ("SELECT e.*, r.title AS resource_title FROM message_limit_events e "
           "JOIN resources r ON r.id=e.resource_id WHERE e.user_id=?")
    args = [req.user["id"]]
    if req.query.get("resource_id", "").isdigit():
        sql += " AND e.resource_id=?"
        args.append(int(req.query["resource_id"]))
    rows = db.q(sql + " ORDER BY e.id DESC LIMIT 100", *args)
    return {"items": [{"id": r["id"], "resource_id": r["resource_id"], "resource_title": r["resource_title"],
                        "sender_id": r["sender_id"], "day": r["day"], "message_count": r["message_count"],
                        "action": r["action"], "created_at": r["created_at"]} for r in rows]}


@route("POST", "/api/v1/posts")
def create_post(req):
    uid = req.user["id"]
    text, image, resources, mode, when = read_post_body(req, uid)
    with db.tx():
        if mode != "draft":
            for r in resources:
                enforce_publication_limit(uid, r["id"], when)
        pid = db.insert("posts", user_id=uid, text=text, image_url=image, created_at=db.now_iso(), updated_at=db.now_iso())
        write_targets(uid, pid, resources, mode, when)
    p = post_row(uid, pid)
    return 201, post_dict(p, load_targets([pid])[pid])


@route("PUT", "/api/v1/posts/<int:id>")
def update_post(req):
    uid = req.user["id"]
    p = post_row(uid, req.params["id"])
    locked = db.one("SELECT 1 FROM post_targets WHERE post_id=? AND status IN ('publishing','published')", p["id"])
    if locked:
        raise ApiError(409, "locked", "Опубликованный пост нельзя изменить. Создайте копию.")
    text, image, resources, mode, when = read_post_body(req, uid)
    with db.tx():
        if mode != "draft":
            for r in resources:
                enforce_publication_limit(uid, r["id"], when, exclude_post_id=p["id"])
        db.run("UPDATE posts SET text=?, image_url=?, updated_at=? WHERE id=?", text, image, db.now_iso(), p["id"])
        db.run("DELETE FROM post_targets WHERE post_id=?", p["id"])
        write_targets(uid, p["id"], resources, mode, when)
    return post_dict(post_row(uid, p["id"]), load_targets([p["id"]])[p["id"]])


@route("DELETE", "/api/v1/posts/<int:id>")
def delete_post(req):
    p = post_row(req.user["id"], req.params["id"])
    if db.one("SELECT 1 FROM post_targets WHERE post_id=? AND status='publishing'", p["id"]):
        raise ApiError(409, "busy", "Пост отправляется прямо сейчас")
    db.run("DELETE FROM posts WHERE id=?", p["id"])
    return {"ok": True}


@route("POST", "/api/v1/posts/<int:id>/duplicate")
def duplicate_post(req):
    uid = req.user["id"]
    p = post_row(uid, req.params["id"])
    with db.tx():
        pid = db.insert("posts", user_id=uid, text=p["text"], image_url=p["image_url"], created_at=db.now_iso(),
                        updated_at=db.now_iso())
        rows = db.q("SELECT DISTINCT t.resource_id FROM post_targets t JOIN resources r ON r.id=t.resource_id "
                    "WHERE t.post_id=? AND r.status!='disconnected'", p["id"])
        for r in rows:
            db.insert("post_targets", post_id=pid, user_id=uid, resource_id=r["resource_id"], status="draft")
    return 201, post_dict(post_row(uid, pid), load_targets([pid]).get(pid, []))


def target_row(uid: int, tid: int):
    t = db.one("SELECT * FROM post_targets WHERE id=? AND user_id=?", tid, uid)
    if t is None:
        raise NOT_FOUND
    return t


def _publishable(uid: int, t) -> None:
    r = db.one("SELECT * FROM resources WHERE id=?", t["resource_id"])
    if r["status"] != "active" or "publish" not in db.jl(r["capabilities"]):
        raise ApiError(422, "no_rights", f"В «{r['title']}» у бота нет прав на публикацию")


@route("POST", "/api/v1/post-targets/<int:id>/cancel")
def cancel_target(req):
    t = target_row(req.user["id"], req.params["id"])
    cur = db.run("UPDATE post_targets SET status='cancelled', error=NULL WHERE id=? AND status IN ('scheduled','draft')", t["id"])
    if cur.rowcount != 1:
        raise ApiError(409, "bad_state", f"Нельзя отменить в статусе «{t['status']}»")
    return {"ok": True}


@route("POST", "/api/v1/post-targets/<int:id>/retry")
def retry_target(req):
    """Manual retry of failed/unknown. For `unknown` the UI warns about a possible duplicate."""
    t = target_row(req.user["id"], req.params["id"])
    _publishable(req.user["id"], t)
    now = db.now()
    with db.tx():
        enforce_publication_limit(req.user["id"], t["resource_id"], now, exclude_post_id=t["post_id"])
        cur = db.run("UPDATE post_targets SET status='scheduled', scheduled_at=?, next_attempt_at=NULL, attempts=0, error=NULL "
                     "WHERE id=? AND status IN ('failed','unknown')", db.iso(now), t["id"])
        if cur.rowcount != 1:
            raise ApiError(409, "bad_state", f"Нельзя повторить в статусе «{t['status']}»")
    return {"ok": True}


@route("POST", "/api/v1/post-targets/<int:id>/publish-now")
def publish_now(req):
    t = target_row(req.user["id"], req.params["id"])
    _publishable(req.user["id"], t)
    now = db.now()
    with db.tx():
        enforce_publication_limit(req.user["id"], t["resource_id"], now, exclude_post_id=t["post_id"])
        cur = db.run("UPDATE post_targets SET status='scheduled', scheduled_at=?, next_attempt_at=NULL, error=NULL "
                     "WHERE id=? AND status IN ('draft','scheduled','cancelled')", db.iso(now), t["id"])
        if cur.rowcount != 1:
            raise ApiError(409, "bad_state", f"Нельзя опубликовать в статусе «{t['status']}»")
    return {"ok": True}


@route("GET", "/api/v1/targets")
def list_targets(req):
    """Flat list for the calendar: targets whose scheduled time lies in [from, to)."""
    uid = req.user["id"]
    start, end = req.query.get("from"), req.query.get("to")
    if not start or not end:
        raise ApiError(422, "validation", "Нужны параметры from и to")
    start, end = db.iso(parse_when(start)), db.iso(parse_when(end))
    sql = ("SELECT t.*, r.title AS resource_title, p.text AS text FROM post_targets t "
           "JOIN resources r ON r.id=t.resource_id JOIN posts p ON p.id=t.post_id "
           "WHERE t.user_id=? AND t.scheduled_at>=? AND t.scheduled_at<?")
    args = [uid, start, end]
    if req.query.get("resource_id", "").isdigit():
        sql += " AND t.resource_id=?"
        args.append(int(req.query["resource_id"]))
    sql += " ORDER BY t.scheduled_at LIMIT 1000"
    out = []
    for t in db.q(sql, *args):
        d = target_dict(t)
        d["text"] = re.sub(r"<[^>]+>", "", t["text"])[:140]
        out.append(d)
    return {"items": out}


# ====================================================================== templates

def template_dict(r) -> dict:
    vars_value = r["variables"] if "variables" in r.keys() else "[]"
    return {
        "id": r["id"],
        "name": r["name"],
        "text": r["text"],
        "category": r["category"] if "category" in r.keys() else "general",
        "is_favorite": bool(r["is_favorite"]) if "is_favorite" in r.keys() else False,
        "variables": db.jl(vars_value) if isinstance(vars_value, str) else (vars_value or []),
        "created_at": r["created_at"],
    }


@route("GET", "/api/v1/templates")
def list_templates(req):
    rows = db.q(
        "SELECT id, name, text, category, is_favorite, variables, created_at FROM templates WHERE user_id=? ORDER BY is_favorite DESC, id DESC",
        req.user["id"],
    )
    return {"items": [template_dict(r) for r in rows]}


@route("POST", "/api/v1/templates")
def create_template(req):
    name = str(need(req, "name")).strip()[:80]
    text = str(need(req, "text")).strip()
    validate_text(text, False)

    category = str(req.body.get("category") or "general").strip()[:32] or "general"
    is_favorite = bool(req.body.get("is_favorite", False))
    raw_vars = req.body.get("variables", [])
    if isinstance(raw_vars, str):
        variables = [v.strip() for v in raw_vars.split(",") if v.strip()]
    elif isinstance(raw_vars, list):
        variables = [str(v).strip() for v in raw_vars if str(v).strip()]
    else:
        variables = []
    variables = list(dict.fromkeys(variables))

    tid = db.insert(
        "templates",
        user_id=req.user["id"],
        name=name,
        text=text,
        category=category,
        is_favorite=int(is_favorite),
        variables=json.dumps(variables),
        created_at=db.now_iso(),
    )
    row = db.one("SELECT id, name, text, category, is_favorite, variables, created_at FROM templates WHERE id=?", tid)
    return 201, template_dict(row)


@route("POST", "/api/v1/templates/preview")
def preview_template(req):
    text = str(need(req, "text")).strip()
    if not text:
        raise ApiError(422, "validation", "Текст шаблона обязателен")
    variables = req.body.get("variables") or {}
    parsed = render_template_text(text, variables)
    return {"text": parsed}


@route("PUT", "/api/v1/templates/<int:id>")
def update_template(req):
    row = db.one("SELECT * FROM templates WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND

    data = dict(row)
    name = req.body.get("name", data["name"]) if req.body else data["name"]
    text = req.body.get("text", data["text"]) if req.body else data["text"]
    category = req.body.get("category", data["category"] if "category" in data else "general") if req.body else data["category"] if "category" in data else "general"
    is_favorite = req.body.get("is_favorite", bool(data["is_favorite"])) if req.body else bool(data["is_favorite"])
    raw_vars = req.body.get("variables", db.jl(data["variables"]) if data["variables"] else []) if req.body else db.jl(data["variables"]) if data["variables"] else []

    name = str(name).strip()[:80]
    text = str(text).strip()
    validate_text(text, False)
    category = str(category or "general").strip()[:32] or "general"

    if isinstance(raw_vars, str):
        variables = [v.strip() for v in raw_vars.split(",") if v.strip()]
    elif isinstance(raw_vars, list):
        variables = [str(v).strip() for v in raw_vars if str(v).strip()]
    else:
        variables = []
    variables = list(dict.fromkeys(variables))

    db.run(
        "UPDATE templates SET name=?, text=?, category=?, is_favorite=?, variables=? WHERE id=? AND user_id=?",
        name,
        text,
        category,
        int(bool(is_favorite)),
        json.dumps(variables),
        req.params["id"],
        req.user["id"],
    )
    updated = db.one("SELECT id, name, text, category, is_favorite, variables, created_at FROM templates WHERE id=?", req.params["id"])
    return template_dict(updated)


@route("DELETE", "/api/v1/templates/<int:id>")
def delete_template(req):
    cur = db.run("DELETE FROM templates WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


# ====================================================================== auto replies

def autoreply_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "name": r["name"],
        "match_type": r["match_type"],
        "match_text": r["match_text"],
        "reply_text": r["reply_text"],
        "enabled": bool(r["enabled"]),
        "priority": int(r["priority"]),
        "cooldown_minutes": int(r["cooldown_minutes"]),
        "excluded_users": db.jl(r["excluded_users"]),
        "created_at": r["created_at"],
    }


@route("GET", "/api/v1/autoreplies")
def list_autoreplies(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM autoreplies WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY priority DESC, id DESC"
    rows = db.q(sql, *args)
    return {"items": [autoreply_dict(r) for r in rows], "count": len(rows)}


@route("POST", "/api/v1/autoreplies")
def create_autoreply(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    name = str(req.body.get("name") or "Auto reply").strip()[:80] or "Auto reply"
    match_type = str(req.body.get("match_type") or "keyword").lower()
    if match_type not in {"keyword", "phrase", "exact"}:
        raise ApiError(422, "validation", "Неверный тип совпадения")
    match_text = str(req.body.get("match_text") or "").strip()
    if not match_text:
        raise ApiError(422, "validation", "Текст правила обязателен")
    reply_text = str(req.body.get("reply_text") or "").strip()
    if not reply_text:
        raise ApiError(422, "validation", "Текст ответа обязателен")
    enabled = bool(req.body.get("enabled", True))
    priority = int(req.body.get("priority", 0) or 0)
    cooldown = max(0, int(req.body.get("cooldown_minutes", 0) or 0))
    excluded = req.body.get("excluded_users", [])
    if excluded is None:
        excluded = []
    if not isinstance(excluded, list):
        raise ApiError(422, "validation", "excluded_users должен быть массивом")
    excluded = [int(x) for x in excluded if str(x).strip()]
    rid_db = db.insert(
        "autoreplies",
        user_id=req.user["id"],
        resource_id=rid,
        name=name,
        match_type=match_type,
        match_text=match_text,
        reply_text=reply_text,
        enabled=int(enabled),
        priority=priority,
        cooldown_minutes=cooldown,
        excluded_users=json.dumps(list(dict.fromkeys(excluded))),
        created_at=db.now_iso(),
    )
    row = db.one("SELECT * FROM autoreplies WHERE id=?", rid_db)
    return 201, autoreply_dict(row)


@route("PUT", "/api/v1/autoreplies/<int:id>")
def update_autoreply(req):
    row = db.one("SELECT * FROM autoreplies WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    data = {**row}
    for key in ("resource_id", "name", "match_type", "match_text", "reply_text", "enabled", "priority", "cooldown_minutes", "excluded_users"):
        if key in req.body:
            data[key] = req.body[key]
    if data.get("resource_id") is not None:
        res = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", data["resource_id"], req.user["id"])
        if res is None:
            raise NOT_FOUND
    match_type = str(data.get("match_type") or "keyword").lower()
    if match_type not in {"keyword", "phrase", "exact"}:
        raise ApiError(422, "validation", "Неверный тип совпадения")
    match_text = str(data.get("match_text") or "").strip()
    reply_text = str(data.get("reply_text") or "").strip()
    if not match_text:
        raise ApiError(422, "validation", "Текст правила обязателен")
    if not reply_text:
        raise ApiError(422, "validation", "Текст ответа обязателен")
    excluded = data.get("excluded_users", [])
    if excluded is None:
        excluded = []
    if not isinstance(excluded, list):
        raise ApiError(422, "validation", "excluded_users должен быть массивом")
    excluded = [int(x) for x in excluded if str(x).strip()]
    db.run(
        "UPDATE autoreplies SET resource_id=?, name=?, match_type=?, match_text=?, reply_text=?, enabled=?, priority=?, cooldown_minutes=?, excluded_users=? WHERE id=? AND user_id=?",
        int(data.get("resource_id") or row["resource_id"]),
        str(data.get("name") or "Auto reply")[:80] or "Auto reply",
        match_type,
        match_text,
        reply_text,
        int(bool(data.get("enabled", True))),
        int(data.get("priority", row["priority"]) or 0),
        max(0, int(data.get("cooldown_minutes", row["cooldown_minutes"]) or 0)),
        json.dumps(list(dict.fromkeys(excluded))),
        req.params["id"],
        req.user["id"],
    )
    updated = db.one("SELECT * FROM autoreplies WHERE id=?", req.params["id"])
    return autoreply_dict(updated)


@route("DELETE", "/api/v1/autoreplies/<int:id>")
def delete_autoreply(req):
    cur = db.run("DELETE FROM autoreplies WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


@route("POST", "/api/v1/autoreplies/test")
def test_autoreply(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    text = str(req.body.get("text") or "").strip()
    if not text:
        return {"matched": False, "rules": []}
    rules = db.q("SELECT * FROM autoreplies WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY priority DESC, id DESC",
                  req.user["id"], rid)
    matched = []
    lowered = text.lower()
    for rule in rules:
        needle = (rule["match_text"] or "").lower()
        ok = False
        if rule["match_type"] in {"keyword", "phrase"}:
            ok = bool(needle and needle in lowered)
        elif rule["match_type"] == "exact":
            ok = lowered == needle
        if ok:
            matched.append(autoreply_dict(rule))
    return {"matched": bool(matched), "rules": matched}


# ====================================================================== auto clean

def autoclean_rule_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "name": r["name"],
        "match_type": r["match_type"],
        "match_text": r["match_text"],
        "enabled": bool(r["enabled"]),
        "created_at": r["created_at"],
    }


def autoclean_event_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "rule_id": r["rule_id"],
        "message_id": r["message_id"],
        "message": r["message"],
        "created_at": r["created_at"],
    }


@route("GET", "/api/v1/autoclean/rules")
def list_autoclean_rules(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM autoclean_rules WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC"
    return {"items": [autoclean_rule_dict(r) for r in db.q(sql, *args)], "count": len(db.q(sql, *args))}


@route("POST", "/api/v1/autoclean/rules")
def create_autoclean_rule(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    name = str(req.body.get("name") or "Auto clean").strip()[:80] or "Auto clean"
    match_type = str(req.body.get("match_type") or "keyword").lower()
    if match_type not in {"keyword", "phrase", "link", "duplicate"}:
        raise ApiError(422, "validation", "Неверный тип правила автоочистки")
    match_text = str(req.body.get("match_text") or "").strip()
    if match_type in {"keyword", "phrase"} and not match_text:
        raise ApiError(422, "validation", "Текст правила обязателен")
    enabled = bool(req.body.get("enabled", True))
    rid_db = db.insert(
        "autoclean_rules",
        user_id=req.user["id"],
        resource_id=rid,
        name=name,
        match_type=match_type,
        match_text=match_text,
        enabled=int(enabled),
        created_at=db.now_iso(),
    )
    created = db.one("SELECT * FROM autoclean_rules WHERE id=?", rid_db)
    return 201, autoclean_rule_dict(created)


@route("PUT", "/api/v1/autoclean/rules/<int:id>")
def update_autoclean_rule(req):
    row = db.one("SELECT * FROM autoclean_rules WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    data = {**row}
    for key in ("resource_id", "name", "match_type", "match_text", "enabled"):
        if key in req.body:
            data[key] = req.body[key]
    match_type = str(data.get("match_type") or "keyword").lower()
    if match_type not in {"keyword", "phrase", "link", "duplicate"}:
        raise ApiError(422, "validation", "Неверный тип правила автоочистки")
    match_text = str(data.get("match_text") or "").strip()
    if match_type in {"keyword", "phrase"} and not match_text:
        raise ApiError(422, "validation", "Текст правила обязателен")
    db.run(
        "UPDATE autoclean_rules SET resource_id=?, name=?, match_type=?, match_text=?, enabled=? WHERE id=? AND user_id=?",
        int(data.get("resource_id") or row["resource_id"]),
        str(data.get("name") or "Auto clean")[:80] or "Auto clean",
        match_type,
        match_text,
        int(bool(data.get("enabled", True))),
        req.params["id"],
        req.user["id"],
    )
    updated = db.one("SELECT * FROM autoclean_rules WHERE id=?", req.params["id"])
    return autoclean_rule_dict(updated)


@route("DELETE", "/api/v1/autoclean/rules/<int:id>")
def delete_autoclean_rule(req):
    cur = db.run("DELETE FROM autoclean_rules WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


@route("GET", "/api/v1/autoclean/log")
def list_autoclean_log(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM autoclean_events WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC LIMIT 200"
    return {"items": [autoclean_event_dict(r) for r in db.q(sql, *args)], "count": len(db.q(sql, *args))}


@route("POST", "/api/v1/autoclean/test")
def test_autoclean(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    text = str(req.body.get("text") or "").strip()
    if not text:
        return {"matched": False, "rules": []}
    rules = db.q("SELECT * FROM autoclean_rules WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY id DESC", req.user["id"], rid)
    matched = []
    for rule in rules:
        if bot._autoclean_matches(rule, text):
            matched.append(autoclean_rule_dict(rule))
    return {"matched": bool(matched), "rules": matched}


# ====================================================================== smart moderator

def moderation_rule_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "name": r["name"],
        "enabled": bool(r["enabled"]),
        "level": r["level"],
        "match_type": r["match_type"],
        "match_text": r["match_text"],
        "action": r["action"],
        "created_at": r["created_at"],
    }


def moderation_event_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "rule_id": r["rule_id"],
        "kind": r["kind"],
        "message": r["message"],
        "risk_score": r["risk_score"],
        "created_at": r["created_at"],
    }


def _moderation_resource(req, resource_id: int):
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", resource_id, req.user["id"])
    if row is None:
        raise NOT_FOUND
    return row


@route("GET", "/api/v1/moderation/rules")
def list_moderation_rules(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM moderation_rules WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC"
    return {"items": [moderation_rule_dict(r) for r in db.q(sql, *args)]}


@route("POST", "/api/v1/moderation/rules")
def create_moderation_rule(req):
    rid = need(req, "resource_id", int)
    _moderation_resource(req, rid)
    name = str(req.body.get("name") or "Rule").strip()[:80] or "Rule"
    level = str(req.body.get("level") or "standard").lower()
    match_type = str(req.body.get("match_type") or "keyword").lower()
    match_text = str(req.body.get("match_text") or "").strip()
    action = str(req.body.get("action") or "warn").lower()
    enabled = bool(req.body.get("enabled", True))
    if level not in {"soft", "standard", "strict"}:
        raise ApiError(422, "validation", "Неверный уровень строгости")
    if match_type not in {"keyword", "phrase", "link", "repeated", "suspicious_link"}:
        raise ApiError(422, "validation", "Неверный тип правила")
    if match_type in {"keyword", "phrase", "link", "suspicious_link"} and not match_text:
        raise ApiError(422, "validation", "Текст правила обязателен")
    if action not in {"warn", "delete", "ban"}:
        raise ApiError(422, "validation", "Недопустимое действие")

    rid_db = db.insert(
        "moderation_rules",
        user_id=req.user["id"],
        resource_id=rid,
        name=name,
        enabled=int(enabled),
        level=level,
        match_type=match_type,
        match_text=match_text,
        action=action,
        created_at=db.now_iso(),
    )
    row = db.one("SELECT * FROM moderation_rules WHERE id=?", rid_db)
    return 201, moderation_rule_dict(row)


@route("PUT", "/api/v1/moderation/rules/<int:id>")
def update_moderation_rule(req):
    row = db.one("SELECT * FROM moderation_rules WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise NOT_FOUND
    data = {**row}
    for key in ("name", "level", "match_type", "match_text", "action", "enabled"):
        if key in req.body:
            data[key] = req.body[key]
    level = str(data.get("level") or "standard").lower()
    match_type = str(data.get("match_type") or "keyword").lower()
    action = str(data.get("action") or "warn").lower()
    if level not in {"soft", "standard", "strict"}:
        raise ApiError(422, "validation", "Неверный уровень строгости")
    if match_type not in {"keyword", "phrase", "link", "repeated", "suspicious_link"}:
        raise ApiError(422, "validation", "Неверный тип правила")
    if action not in {"warn", "delete", "ban"}:
        raise ApiError(422, "validation", "Недопустимое действие")
    db.run(
        "UPDATE moderation_rules SET name=?, enabled=?, level=?, match_type=?, match_text=?, action=? WHERE id=? AND user_id=?",
        str(data.get("name") or "Rule")[:80],
        int(bool(data.get("enabled", True))),
        level,
        match_type,
        str(data.get("match_text") or ""),
        action,
        req.params["id"],
        req.user["id"],
    )
    updated = db.one("SELECT * FROM moderation_rules WHERE id=?", req.params["id"])
    return moderation_rule_dict(updated)


@route("DELETE", "/api/v1/moderation/rules/<int:id>")
def delete_moderation_rule(req):
    cur = db.run("DELETE FROM moderation_rules WHERE id=? AND user_id=?", req.params["id"], req.user["id"])
    if cur.rowcount != 1:
        raise NOT_FOUND
    return {"ok": True}


@route("GET", "/api/v1/moderation/log")
def list_moderation_log(req):
    resource_id = req.query.get("resource_id")
    sql = "SELECT * FROM moderation_events WHERE user_id=?"
    args = [req.user["id"]]
    if resource_id and resource_id.isdigit():
        sql += " AND resource_id=?"
        args.append(int(resource_id))
    sql += " ORDER BY id DESC LIMIT 200"
    rows = db.q(sql, *args)
    return {"items": [moderation_event_dict(r) for r in rows], "count": len(rows)}


@route("POST", "/api/v1/moderation/scan")
def scan_moderation_message(req):
    rid = need(req, "resource_id", int)
    _moderation_resource(req, rid)
    text = str(req.body.get("text") or "").strip()
    if not text:
        return {"status": "clean", "score": 0, "matches": [], "level": "standard", "action": "warn"}
    report = bot.analyze_moderation(req.user["id"], rid, text)
    matches = [{k: v for k, v in item.items() if k != "rule_id"} for item in report["matches"]]

    db.insert(
        "moderation_events",
        user_id=req.user["id"],
        resource_id=rid,
        rule_id=next((item["rule_id"] for item in report["matches"] if item.get("rule_id")), None),
        kind=report["status"],
        message=f"Проверка модерации: {report['status']} для сообщения длиной {len(text)} символов",
        risk_score=report["score"],
        created_at=db.now_iso(),
    )
    return {"status": report["status"], "score": report["score"], "matches": matches,
            "level": "standard", "action": report["status"]}


# ====================================================================== anti-scam

def scam_domain_dict(r) -> dict:
    return {
        "id": r["id"],
        "domain": r["domain"],
        "kind": r["kind"],
        "created_at": r["created_at"],
    }


def scam_event_dict(r) -> dict:
    return {
        "id": r["id"],
        "resource_id": r["resource_id"],
        "resource_title": r["resource_title"] if "resource_title" in r.keys() else None,
        "status": r["status"],
        "risk_score": r["risk_score"],
        "message": r["message"],
        "threats": db.jl(r["threat_json"]),
        "created_at": r["created_at"],
    }


@route("GET", "/api/v1/anti-scam/domains")
def list_scam_domains(req):
    rows = db.q("SELECT * FROM scam_domains WHERE user_id=? ORDER BY id DESC", req.user["id"])
    return {"items": [scam_domain_dict(r) for r in rows]}


@route("POST", "/api/v1/anti-scam/domains")
def create_scam_domain(req):
    domain = str(req.body.get("domain") or "").strip().lower()
    if not domain:
        raise ApiError(422, "validation", "Домен обязателен")
    kind = str(req.body.get("kind") or "review").lower()
    if kind not in {"trusted", "blocked", "review"}:
        raise ApiError(422, "validation", "Недопустимый тип домена")
    domain = re.sub(r"^https?://", "", domain)
    domain = domain.strip("/")
    domain = domain.split("/")[0].split("?")[0].split("#")[0]
    if "." not in domain:
        raise ApiError(422, "validation", "Домен должен содержать доменную зону")
    row = db.one("SELECT * FROM scam_domains WHERE user_id=? AND domain=?", req.user["id"], domain)
    if row is None:
        row_id = db.insert("scam_domains", user_id=req.user["id"], domain=domain, kind=kind, created_at=db.now_iso())
        row = db.one("SELECT * FROM scam_domains WHERE id=?", row_id)
    else:
        db.run("UPDATE scam_domains SET kind=? WHERE id=? AND user_id=?", kind, row["id"], req.user["id"])
        row = db.one("SELECT * FROM scam_domains WHERE id=?", row["id"])
    return 201, scam_domain_dict(row)


@route("GET", "/api/v1/anti-scam/history")
def list_scam_history(req):
    rows = db.q("SELECT e.*, r.title AS resource_title FROM scam_events e "
                "LEFT JOIN resources r ON r.id=e.resource_id WHERE e.user_id=? ORDER BY e.id DESC LIMIT 200",
                req.user["id"])
    return {"items": [scam_event_dict(r) for r in rows], "count": len(rows)}


@route("POST", "/api/v1/anti-scam/check")
def check_scam_message(req):
    rid = need(req, "resource_id", int)
    row = db.one("SELECT * FROM resources WHERE id=? AND user_id=?", rid, req.user["id"])
    if row is None:
        raise NOT_FOUND
    text = str(req.body.get("text") or "").strip()
    if not text:
        return {"status": "safe", "risk_score": 0, "threats": []}
    report = bot.analyze_anti_scam(req.user["id"], text)
    db.insert(
        "scam_events",
        user_id=req.user["id"],
        resource_id=rid,
        status=report["status"],
        risk_score=report["risk_score"],
        message=f"Проверка угроз: {report['status']} ({report['risk_score']} pts)",
        threat_json=json.dumps(report["threats"], ensure_ascii=False),
        created_at=db.now_iso(),
    )
    return {"status": report["status"], "risk_score": report["risk_score"], "threats": report["threats"]}


# ====================================================================== analytics & dashboard
def local_day(iso_str: str, tz: ZoneInfo) -> str:
    return db.parse_iso(iso_str).astimezone(tz).strftime("%Y-%m-%d")


def day_labels(days: int, tz: ZoneInfo) -> list[str]:
    today = datetime.now(tz).date()
    return [(today - timedelta(days=i)).isoformat() for i in range(days - 1, -1, -1)]


def member_series(resource_ids: list[int], labels: list[str], tz: ZoneInfo) -> dict[int, list]:
    """Per resource: last snapshot of each local day, forward-filled; None before the first snapshot."""
    result = {}
    since = db.iso(db.now() - timedelta(days=len(labels) + 2))
    for rid in resource_ids:
        by_day = {}
        for s in db.q("SELECT members, taken_at FROM snapshots WHERE resource_id=? AND taken_at>=? ORDER BY taken_at", rid, since):
            by_day[local_day(s["taken_at"], tz)] = s["members"]
        prior = db.one("SELECT members FROM snapshots WHERE resource_id=? AND taken_at<? ORDER BY taken_at DESC LIMIT 1", rid, since)
        last = prior["members"] if prior else None
        series = []
        for d in labels:
            last = by_day.get(d, last)
            series.append(last)
        result[rid] = series
    return result


def total_series(series: dict[int, list], n: int) -> list:
    out = []
    for i in range(n):
        vals = [s[i] for s in series.values() if s[i] is not None]
        out.append(sum(vals) if vals else None)
    return out


def growth(series: dict[int, list]):
    delta, base = 0, 0
    for s in series.values():
        vals = [v for v in s if v is not None]
        if len(vals) >= 2 and s[0] is not None:  # only resources with data at the window start
            delta += vals[-1] - vals[0]
            base += vals[0]
    return delta, (round(delta / base * 100, 2) if base else None)


def published_per_day(uid: int, labels: list[str], tz: ZoneInfo, resource_ids=None) -> list[int]:
    sql = "SELECT published_at FROM post_targets WHERE user_id=? AND status='published' AND published_at>=?"
    args = [uid, db.iso(db.now() - timedelta(days=len(labels) + 2))]
    if resource_ids is not None:
        sql += f" AND resource_id IN ({','.join('?' * len(resource_ids)) or 'NULL'})"
        args += resource_ids
    counts = {d: 0 for d in labels}
    for r in db.q(sql, *args):
        d = local_day(r["published_at"], tz)
        if d in counts:
            counts[d] += 1
    return [counts[d] for d in labels]


def selected_resources(uid: int, rid_param: str):
    rows = db.q("SELECT * FROM resources WHERE user_id=? AND status!='disconnected' ORDER BY title", uid)
    if rid_param.isdigit():
        rows = [r for r in rows if r["id"] == int(rid_param)]
        if not rows:
            raise NOT_FOUND
    return rows


def source_label(rows) -> str:
    live = any(not r["is_demo"] for r in rows)
    demo = any(r["is_demo"] for r in rows)
    parts = []
    if live:
        parts.append("Telegram Bot API: getChatMemberCount, снимки MarketPilot")
    if demo:
        parts.append("демо-данные (сгенерированы)")
    return "; ".join(parts) or "нет данных"


@route("GET", "/api/v1/dashboard")
def dashboard(req):
    uid, tz = req.user["id"], user_tz(req.user)
    days = req.int_param("days", 30, 1, 90)
    rows = selected_resources(uid, req.query.get("resource_id", ""))
    if req.query.get("type") in ("channel", "group"):
        want = ("channel",) if req.query["type"] == "channel" else ("group", "supergroup")
        rows = [r for r in rows if r["type"] in want]
    ids = [r["id"] for r in rows]
    labels = day_labels(days, tz)
    series = member_series(ids, labels, tz)
    totals = total_series(series, len(labels))
    delta, pct = growth(series)
    since = db.iso(db.now() - timedelta(days=days))
    marks = ",".join("?" * len(ids)) or "NULL"

    def count(extra: str, *args) -> int:
        return db.one(f"SELECT COUNT(*) n FROM post_targets WHERE user_id=? AND resource_id IN ({marks}) AND {extra}",
                      uid, *ids, *args)["n"]

    published = count("status='published' AND published_at>=?", since)
    upcoming = count("status='scheduled'")
    attention_targets = count("status IN ('failed','unknown') AND scheduled_at>=?", since)
    attention_res = sum(1 for r in rows if r["status"] == "missing_rights")
    ev_sql = "SELECT * FROM events WHERE user_id=?"
    ev_args = [uid]
    if req.query.get("kind"):
        ev_sql += " AND kind=?"
        ev_args.append(req.query["kind"])
    events = [dict(e) for e in db.q(ev_sql + " ORDER BY id DESC LIMIT 12", *ev_args)]
    upcoming_list = [dict(t, text=re.sub(r"<[^>]+>", "", t["text"])[:100]) for t in db.q(
        "SELECT t.id, t.post_id, t.scheduled_at, t.status, r.title AS resource_title, p.text AS text FROM post_targets t "
        "JOIN resources r ON r.id=t.resource_id JOIN posts p ON p.id=t.post_id "
        f"WHERE t.user_id=? AND t.status='scheduled' AND t.resource_id IN ({marks}) ORDER BY t.scheduled_at LIMIT 5",
        uid, *ids)]
    src = source_label(rows)
    return {
        "period_days": days, "labels": labels,
        "kpis": {
            "channels": {"value": sum(1 for r in rows if r["type"] == "channel"), "source": "MarketPilot"},
            "groups": {"value": sum(1 for r in rows if r["type"] != "channel"), "source": "MarketPilot"},
            "members": {"value": sum(r["members"] or 0 for r in rows), "source": src, "period": "сейчас",
                        "delta": delta, "delta_pct": pct},
            "published": {"value": published, "source": "журнал публикаций MarketPilot", "period": f"{days} дн."},
            "scheduled": {"value": upcoming, "source": "планировщик MarketPilot", "period": "впереди"},
            "attention": {"value": attention_targets + attention_res, "source": "журнал публикаций и проверка прав",
                          "period": f"{days} дн."},
        },
        "members_series": totals,
        "published_series": published_per_day(uid, labels, tz, ids),
        "events": events, "upcoming": upcoming_list,
        "views_available": False,
        "views_note": "Просмотры публикаций недоступны через Telegram Bot API и не отображаются.",
    }


@route("GET", "/api/v1/analytics")
def analytics(req):
    uid, tz = req.user["id"], user_tz(req.user)
    days = req.int_param("days", 30, 1, 90)
    rows = selected_resources(uid, req.query.get("resource_id", ""))
    ids = [r["id"] for r in rows]
    labels = day_labels(days, tz)
    series = member_series(ids, labels, tz)
    delta, pct = growth(series)
    since = db.iso(db.now() - timedelta(days=days))

    table = []
    for r in rows:
        s = series[r["id"]]
        vals = [v for v in s if v is not None]
        counts = {k: db.one("SELECT COUNT(*) n FROM post_targets WHERE resource_id=? AND status=? AND scheduled_at>=?",
                            r["id"], k, since)["n"] for k in ("published", "failed", "unknown")}
        finished = sum(counts.values())
        table.append({
            "id": r["id"], "title": r["title"], "type": r["type"], "is_demo": bool(r["is_demo"]),
            "members": r["members"], "delta": vals[-1] - vals[0] if len(vals) >= 2 and s[0] is not None else None,
            "published": counts["published"], "failed": counts["failed"], "unknown": counts["unknown"],
            "success_rate": round(counts["published"] / finished * 100) if finished else None,
        })

    hours = [0] * 24
    weekdays = [0] * 7
    sql = (f"SELECT published_at FROM post_targets WHERE user_id=? AND status='published' AND published_at>=? "
           f"AND resource_id IN ({','.join('?' * len(ids)) or 'NULL'})")
    for r in db.q(sql, uid, since, *ids):
        local = db.parse_iso(r["published_at"]).astimezone(tz)
        hours[local.hour] += 1
        weekdays[local.weekday()] += 1

    groups = [r for r in rows if r["type"] != "channel"]
    activity = None
    if groups:
        agg = {d: [0, 0, 0] for d in labels}
        for g in groups:
            for s in db.q("SELECT day, messages, joins, leaves FROM group_stats WHERE resource_id=?", g["id"]):
                if s["day"] in agg:
                    agg[s["day"]][0] += s["messages"]
                    agg[s["day"]][1] += s["joins"]
                    agg[s["day"]][2] += s["leaves"]
        activity = {"messages": [agg[d][0] for d in labels], "joins": [agg[d][1] for d in labels],
                    "leaves": [agg[d][2] for d in labels], "groups": len(groups),
                    "source": "события бота (счётчики; тексты сообщений не хранятся)"}

    tips = []
    if sum(hours) >= 5:
        best = max(range(24), key=lambda h: hours[h])
        tips.append(f"Чаще всего публикации выходят в {best:02d}:00 — это ваше «привычное» окно.")
    failed_total = sum(t["failed"] + t["unknown"] for t in table)
    if failed_total:
        tips.append(f"За период {failed_total} публикаций завершились ошибкой или без подтверждения — проверьте раздел «Публикации».")
    if any(r["status"] == "missing_rights" for r in rows):
        tips.append("В части ресурсов боту не хватает прав — публикации туда блокируются.")
    return {
        "period_days": days, "labels": labels, "source": source_label(rows),
        "members_series": total_series(series, len(labels)),
        "members_by_resource": [{"id": r["id"], "title": r["title"], "values": series[r["id"]]} for r in rows],
        "growth": {"delta": delta, "pct": pct},
        "published_series": published_per_day(uid, labels, tz, ids),
        "table": table, "hours": hours, "weekdays": weekdays, "group_activity": activity, "tips": tips,
        "limitations": ["Просмотры постов и охваты недоступны через Telegram Bot API — они не показываются и не оцениваются.",
                        "Динамика подписчиков строится по снимкам getChatMemberCount, которые делает MarketPilot "
                        f"(раз в {cfg.SNAPSHOT_INTERVAL_MIN // 60} ч); история до подключения ресурса недоступна.",
                        "Активность групп считается по событиям, которые видит бот (нужны права администратора)."],
    }


@route("GET", "/api/v1/notifications")
def notifications(req):
    """Event feed with unread tracking (users.notif_seen = id of the last event the user has seen)."""
    uid = req.user["id"]
    seen = db.one("SELECT notif_seen FROM users WHERE id=?", uid)["notif_seen"]
    rows = db.q("SELECT id, kind, message, resource_id, created_at FROM events WHERE user_id=? ORDER BY id DESC LIMIT ?",
                uid, req.int_param("limit", 50, 1, 200))
    unread = db.one("SELECT COUNT(*) n FROM events WHERE user_id=? AND id>?", uid, seen)["n"]
    return {"unread": unread, "notify": bool(req.user["notify"]),
            "items": [dict(r, unread=r["id"] > seen) for r in rows]}


@route("POST", "/api/v1/notifications/read")
def notifications_read(req):
    uid = req.user["id"]
    top = db.one("SELECT COALESCE(MAX(id), 0) m FROM events WHERE user_id=?", uid)["m"]
    db.run("UPDATE users SET notif_seen=? WHERE id=?", top, uid)
    return {"ok": True, "unread": 0}


@route("GET", "/api/v1/events")
def list_events(req):
    uid = req.user["id"]
    sql, args = "SELECT * FROM events WHERE user_id=?", [uid]
    if req.query.get("kind"):
        sql += " AND kind=?"
        args.append(req.query["kind"])
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(req.int_param("limit", 50, 1, 200))
    return {"items": [dict(e) for e in db.q(sql, *args)]}
