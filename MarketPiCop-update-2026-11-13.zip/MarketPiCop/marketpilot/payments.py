"""YooKassa client for marketplace payments. Secrets stay in server configuration."""
import base64
import json
import urllib.error
import urllib.parse
import urllib.request

from .config import cfg


class PaymentProviderError(Exception):
    def __init__(self, message: str, ambiguous: bool = False):
        super().__init__(message)
        self.ambiguous = ambiguous


def configured() -> bool:
    return bool(cfg.YOOKASSA_MARKETPLACE_ENABLED and cfg.YOOKASSA_SHOP_ID and cfg.YOOKASSA_SECRET_KEY)


def money(amount_minor: int) -> str:
    return f"{amount_minor // 100}.{amount_minor % 100:02d}"


def commission(amount_minor: int) -> int:
    return (amount_minor * cfg.PLATFORM_COMMISSION_BPS + 5000) // 10000


def _request(method: str, path: str, payload: dict | None = None, idempotency_key: str = "") -> dict:
    if not configured():
        raise PaymentProviderError("Платежи YooKassa не настроены или marketplace не активирован")
    credentials = f"{cfg.YOOKASSA_SHOP_ID}:{cfg.YOOKASSA_SECRET_KEY}".encode()
    headers = {
        "Authorization": "Basic " + base64.b64encode(credentials).decode("ascii"),
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if idempotency_key:
        headers["Idempotence-Key"] = idempotency_key
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    request = urllib.request.Request(cfg.YOOKASSA_API_URL + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            result = json.loads(response.read() or b"{}")
    except urllib.error.HTTPError as error:
        try:
            details = json.loads(error.read() or b"{}")
            description = str(details.get("description") or details.get("type") or "ошибка провайдера")
        except (ValueError, UnicodeDecodeError):
            description = "ошибка провайдера"
        raise PaymentProviderError(f"YooKassa отклонила запрос: {description[:160]}") from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise PaymentProviderError("Нет ответа от YooKassa; состояние платежа нужно сверить перед повтором", ambiguous=True) from None
    if not isinstance(result, dict):
        raise PaymentProviderError("YooKassa вернула неожиданный ответ")
    return result


def create_payment(*, amount_minor: int, seller_account_id: str, payment_id: int,
                   subscription_id: int, return_url: str, save_payment_method: bool,
                   idempotency_key: str, payment_method_id: str = "") -> dict:
    if not cfg.COMMUNITY_PAYMENTS_ENABLED:
        raise PaymentProviderError("Приём платежей за подписки временно отключён")
    if amount_minor < 100:
        raise PaymentProviderError("Минимальная сумма платежа — 1 рубль")
    platform_fee = commission(amount_minor)
    payload = {
        "amount": {"value": money(amount_minor), "currency": "RUB"},
        "capture": True,
        "description": f"Подписка MarketPilot #{subscription_id}"[:128],
        "metadata": {"payment_id": str(payment_id), "subscription_id": str(subscription_id)},
        "save_payment_method": bool(save_payment_method),
        "transfers": [{
            "account_id": str(seller_account_id),
            "amount": {"value": money(amount_minor), "currency": "RUB"},
            "platform_fee_amount": {"value": money(platform_fee), "currency": "RUB"},
        }],
    }
    if payment_method_id:
        payload["payment_method_id"] = payment_method_id
    else:
        payload["confirmation"] = {"type": "redirect", "return_url": return_url}
    return _request("POST", "/payments", payload, idempotency_key)


def get_payment(provider_payment_id: str) -> dict:
    return _request("GET", "/payments/" + urllib.parse.quote(provider_payment_id, safe=""))


def create_refund(*, provider_payment_id: str, amount_minor: int, payment_id: int,
                  idempotency_key: str) -> dict:
    payload = {
        "payment_id": provider_payment_id,
        "amount": {"value": money(amount_minor), "currency": "RUB"},
        "description": f"Возврат MarketPilot #{payment_id}"[:128],
    }
    return _request("POST", "/refunds", payload, idempotency_key)


def get_refund(provider_refund_id: str) -> dict:
    return _request("GET", "/refunds/" + urllib.parse.quote(provider_refund_id, safe=""))
