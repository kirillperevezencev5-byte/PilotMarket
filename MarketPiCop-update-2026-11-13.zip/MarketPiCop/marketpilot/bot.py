"""Telegram bot: long polling (no public HTTPS needed for local use) and update handlers."""
import json
import logging
import random
import re
import threading
import time
from collections import Counter
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from . import db, security, telegram
from .config import cfg
from .telegram import TelegramError, TelegramNetworkError

log = logging.getLogger("marketpilot.bot")

ALLOWED_UPDATES = ["message", "channel_post", "my_chat_member", "chat_member"]
CHAT_TYPES = {"channel": "channel", "group": "group", "supergroup": "supergroup"}


# ---------- helpers ----------
def miniapp_url(page: str | None = None) -> str | None:
    """Telegram only opens Mini Apps over HTTPS (no localhost / plain http)."""
    base = cfg.PUBLIC_URL
    if not base.startswith("https://"):
        return None
    return base + "/app/" + (f"?p={page}" if page else "")


def webapp_markup(page: str | None = None, text: str = "🚀 Открыть приложение"):
    """Inline keyboard with a web_app button: opens the Mini App inside Telegram (no external browser)."""
    url = miniapp_url(page)
    if not url:
        return None
    return {"inline_keyboard": [[{"text": text, "web_app": {"url": url}}]]}


def say(chat_id, text, parse_mode=None, reply_markup=None):
    c = telegram.client()
    if not c:
        return
    try:
        c.send_message(chat_id, text, parse_mode=parse_mode, reply_markup=reply_markup)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("send to %s failed: %s", chat_id, e)


def notify_owner(user_id: int, text: str, page: str = "notifications") -> None:
    """Send a Telegram notification to the owner of a workspace (skipped for demo users / notifications off).
    When the Mini App is configured the message carries a button that opens the relevant section."""
    user = db.one("SELECT * FROM users WHERE id=?", user_id)
    if user and not user["is_demo"] and user["notify"] and telegram.is_live():
        say(user["telegram_id"], text, reply_markup=webapp_markup(page, "🚀 Открыть"))


def _today() -> str:
    return db.now().strftime("%Y-%m-%d")


def _bump(resource_id: int, field: str) -> None:
    db.run(
        f"INSERT INTO group_stats(resource_id, day, {field}) VALUES(?,?,1) "
        f"ON CONFLICT(resource_id, day) DO UPDATE SET {field} = {field} + 1",
        resource_id, _today(),
    )


# ---------- handlers ----------
def handle_update(upd: dict) -> None:
    if "message" in upd:
        handle_message(upd["message"])
    elif "channel_post" in upd:
        handle_channel_post(upd["channel_post"])
    elif "my_chat_member" in upd:
        handle_my_chat_member(upd["my_chat_member"])
    elif "chat_member" in upd:
        handle_chat_member(upd["chat_member"])


def _select_autoreply(rule, text: str, sender_id: int | None) -> bool:
    if not bool(rule["enabled"]):
        return False
    excluded = db.jl(rule["excluded_users"] if "excluded_users" in rule.keys() else "[]")
    if sender_id is not None and sender_id in excluded:
        return False
    if rule["cooldown_minutes"]:
        cutoff = db.iso(db.now() - __import__("datetime").timedelta(minutes=int(rule["cooldown_minutes"])))
        event = db.one(
            "SELECT 1 FROM autoreply_events WHERE user_id=? AND resource_id=? AND rule_id=? AND sender_id=? AND created_at>? LIMIT 1",
            rule["user_id"], rule["resource_id"], rule["id"], sender_id or 0, cutoff,
        )
        if event:
            return False
    needle = str(rule["match_text"] or "").strip()
    if not needle:
        return False
    lowered = text.lower()
    n = needle.lower()
    match_type = str(rule["match_type"] or "keyword").lower()
    if match_type == "exact":
        return lowered == n
    if match_type == "phrase":
        return n in lowered
    return n in lowered


def extract_message_links(message: dict, text: str) -> list[str]:
    links = []
    for field in ("entities", "caption_entities"):
        for entity in message.get(field) or []:
            if entity.get("type") == "text_link" and entity.get("url"):
                links.append(str(entity["url"]))
            elif entity.get("type") == "url":
                raw = text.encode("utf-16-le")
                start = int(entity.get("offset", 0)) * 2
                end = start + int(entity.get("length", 0)) * 2
                value = raw[start:end].decode("utf-16-le", errors="ignore").strip()
                if value:
                    links.append(value)
    links.extend(re.findall(r"(?i)(?:https?://|www\.)[^\s<>]+", text))
    result = []
    seen = set()
    for link in links:
        link = link.strip().rstrip(".,);!?")
        normalized = link if re.match(r"(?i)^https?://", link) else "https://" + link
        if normalized not in seen:
            result.append(normalized)
            seen.add(normalized)
    return result


def _autoclean_matches(rule, text: str, links: list[str] | None = None) -> bool:
    if not bool(rule["enabled"]):
        return False
    match_type = str(rule["match_type"] or "keyword").lower()
    needle = str(rule["match_text"] or "").strip().lower()
    lowered = text.lower()
    if match_type in {"keyword", "phrase"}:
        return bool(needle and needle in lowered)
    if match_type == "link":
        return bool(links or re.search(r"(?:https?://|www\.)\S+", text, re.IGNORECASE))
    if match_type == "duplicate":
        if not needle:
            needle = lowered
        recent = db.one(
            "SELECT 1 FROM autoclean_events WHERE user_id=? AND resource_id=? AND message=? AND created_at>? LIMIT 1",
            rule["user_id"], rule["resource_id"], text[:200], db.iso(db.now() - __import__("datetime").timedelta(minutes=15)),
        )
        return bool(recent or (needle in lowered and lowered.count(needle) > 1))
    return False


def analyze_moderation(user_id: int, resource_id: int, text: str) -> dict:
    lowered = text.lower()
    rules = db.q("SELECT * FROM moderation_rules WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY id DESC",
                 user_id, resource_id)
    matches = []
    score = 0
    level_weights = {"soft": 1, "standard": 2, "strict": 3}
    for rule in rules:
        rule_text = (rule["match_text"] or "").lower()
        match_type = rule["match_type"]
        matched = False
        if match_type in {"keyword", "phrase"}:
            matched = bool(rule_text and rule_text in lowered)
        elif match_type == "link":
            matched = bool(re.search(r"https?://\S+", text, re.IGNORECASE))
        elif match_type == "repeated":
            words = [w for w in re.findall(r"[A-Za-zА-Яа-я0-9]+", lowered) if len(w) > 3]
            matched = any(count >= 3 for count in Counter(words).values())
        elif match_type == "suspicious_link":
            matched = bool(re.search(r"https?://(?:[A-Za-z0-9-]+\.)+(?:ru|com|net|xyz|top|club|ga|cf|info)", lowered))
        if matched:
            matches.append({"rule": rule["name"], "level": rule["level"], "action": rule["action"],
                            "type": match_type, "rule_id": rule["id"]})
            score += 2 + level_weights.get(rule["level"], 2)
            score += 2 if rule["action"] == "delete" else 4 if rule["action"] == "ban" else 0

    if not matches:
        if re.search(r"https?://\S+", text, re.IGNORECASE):
            matches.append({"rule": "default_link", "level": "standard", "action": "warn", "type": "link"})
            score += 2
        if re.search(r"(buy now|click here|free money|urgent|limited offer)", lowered):
            matches.append({"rule": "default_keyword", "level": "standard", "action": "warn", "type": "keyword"})
            score += 2

    status = "delete" if score >= 7 else "ban" if score >= 4 else "warn" if score >= 2 else "clean"
    return {"status": status, "score": score, "matches": matches}


def analyze_anti_scam(user_id: int, text: str, links: list[str] | None = None) -> dict:
    links = links if links is not None else extract_message_links({}, text)
    domains = []
    for link in links:
        host = urlparse(link.rstrip(".,);!?")).hostname
        if host:
            domains.append(host.lower().rstrip("."))

    blocked = {r["domain"].lower().rstrip(".") for r in db.q(
        "SELECT domain FROM scam_domains WHERE user_id=? AND kind='blocked'", user_id)}
    trusted = {r["domain"].lower().rstrip(".") for r in db.q(
        "SELECT domain FROM scam_domains WHERE user_id=? AND kind='trusted'", user_id)}
    threats = []
    score = 0
    has_blocked_domain = False
    for domain in domains:
        blocked_match = next((d for d in blocked if domain == d or domain.endswith("." + d)), None)
        trusted_match = any(domain == d or domain.endswith("." + d) for d in trusted)
        if blocked_match:
            threats.append({"type": "blocked_domain", "domain": domain, "severity": "high"})
            score += 8
            has_blocked_domain = True
        elif not trusted_match and "." in domain:
            threats.append({"type": "unverified_domain", "domain": domain, "severity": "medium"})
            score += 2

    patterns = [("urgent", 2), ("verify account", 3), ("click here", 2), ("free money", 3),
                ("limited time", 2), ("winner", 2), ("claim reward", 3), ("security alert", 3)]
    lowered = text.lower()
    for pattern, points in patterns:
        if pattern in lowered:
            threats.append({"type": "pattern", "pattern": pattern, "severity": "medium"})
            score += points

    status = "blocked" if has_blocked_domain or score >= 8 else "review" if score >= 4 else "unknown" if domains else "safe"
    return {"status": status, "risk_score": score, "threats": threats, "blocked_domain": has_blocked_domain}


def _is_exempt_sender(chat_id: int, sender: dict | None) -> bool | None:
    sender_id = sender.get("id") if sender else None
    if not sender_id or (sender and sender.get("is_bot")) or (sender and sender.get("id") == telegram.state.get("bot_id")):
        return True
    try:
        member = telegram.client().chat_member(chat_id, sender_id)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("cannot verify moderation target %s in %s: %s", sender_id, chat_id, e)
        return None
    return member.get("status") in ("creator", "administrator")


def _record_scam_event(resource, report: dict) -> None:
    db.insert("scam_events", user_id=resource["user_id"], resource_id=resource["id"],
              status=report["status"], risk_score=report["risk_score"],
              message=f"Автоматическая проверка угроз: {report['status']} ({report['risk_score']} pts)",
              threat_json=json.dumps(report["threats"], ensure_ascii=False), created_at=db.now_iso())


def process_automatic_protection(message: dict, text: str, links: list[str] | None = None) -> bool:
    """Scan incoming messages and apply configured moderation and blocked-domain actions."""
    chat = message.get("chat") or {}
    chat_type = chat.get("type")
    if chat_type not in ("group", "supergroup", "channel") or not message.get("message_id"):
        return False
    sender = message.get("from") or {}
    if sender.get("is_bot") or sender.get("id") == telegram.state.get("bot_id"):
        return False
    links = links if links is not None else extract_message_links(message, text)
    if not text and not links:
        return False
    resources = db.q("SELECT * FROM resources WHERE chat_id=? AND status='active' AND is_demo=0", chat["id"])
    if len(resources) != 1:
        if len(resources) > 1:
            log.error("automatic protection skipped for chat %s: multiple active owners", chat["id"])
        return False
    resource = resources[0]
    uid, rid = resource["user_id"], resource["id"]
    report = analyze_anti_scam(uid, text, links)
    if report["status"] != "safe":
        _record_scam_event(resource, report)
        domains = sorted({item.get("domain") for item in report["threats"] if item.get("domain")})
        db.event(uid, "anti_scam_risk", f"Риск-ссылка в «{resource['title']}»: " + ", ".join(domains or [report["status"]]), rid)
        notify_owner(uid, f"⚠️ Риск ссылки в «{resource['title']}»: {report['status']}. "
                     f"Домены: {', '.join(domains) if domains else 'обнаружен подозрительный текст'}.", "tools")

    if report["blocked_domain"]:
        can_remove = chat_type == "channel" or _is_exempt_sender(chat["id"], sender) is False
        if can_remove:
            try:
                telegram.client().call("deleteMessage", chat_id=chat["id"], message_id=int(message["message_id"]))
                return True
            except (TelegramError, TelegramNetworkError) as e:
                log.warning("anti-scam could not delete message in %s: %s", chat["id"], e)

    if chat_type == "channel" or not text:
        return False
    moderation = analyze_moderation(uid, rid, text + " " + " ".join(links))
    if not moderation["matches"]:
        return False
    configured = [m for m in moderation["matches"] if m.get("rule_id")]
    if not configured:
        return False
    if _is_exempt_sender(chat["id"], sender) is not False:
        return False
    actions = [m["action"] for m in configured]
    action = "ban" if "ban" in actions else "delete" if "delete" in actions else "warn"
    rule_id = next((m["rule_id"] for m in configured if m["action"] == action), configured[0]["rule_id"])
    message_id, user_id = int(message["message_id"]), int(sender["id"])
    try:
        if action == "delete":
            telegram.client().call("deleteMessage", chat_id=chat["id"], message_id=message_id)
        elif action == "ban":
            telegram.client().call("banChatMember", chat_id=chat["id"], user_id=user_id)
        else:
            telegram.client().call("sendMessage", chat_id=chat["id"], text="Сообщение нарушает правила группы.",
                                   reply_to_message_id=message_id)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("moderation action %s failed in chat %s: %s", action, chat["id"], e)
    db.insert("moderation_events", user_id=uid, resource_id=rid, rule_id=rule_id, kind=action,
              message=f"Автомодерация: {action} для сообщения длиной {len(text)} символов",
              risk_score=moderation["score"], created_at=db.now_iso())
    return action in ("delete", "ban")


def process_member_message_limit(message: dict) -> bool:
    """Count one member's group messages per owner-local day and apply their configured quota."""
    chat = message.get("chat") or {}
    sender = message.get("from") or {}
    if chat.get("type") not in ("group", "supergroup") or not message.get("message_id"):
        return False
    sender_id = sender.get("id")
    if not sender_id or sender.get("is_bot") or sender_id == telegram.state.get("bot_id"):
        return False
    configs = db.q("SELECT r.id resource_id,r.user_id,r.title resource_title,u.timezone,"
                   "m.max_messages,m.action,m.exclude_admins,m.notify_owner,m.enabled "
                   "FROM resources r JOIN users u ON u.id=r.user_id "
                   "LEFT JOIN message_limits m ON m.resource_id=r.id AND m.user_id=r.user_id "
                   "WHERE r.chat_id=? AND r.status='active' AND r.is_demo=0", chat["id"])
    if len(configs) != 1:
        if len(configs) > 1:
            log.error("message quota skipped for chat %s: multiple active owners", chat["id"])
        return False
    config = dict(configs[0])
    subscription = db.one(
        "SELECT p.limits_json FROM community_subscriptions s "
        "JOIN community_plans p ON p.id=s.plan_id JOIN resources r ON r.id=s.resource_id "
        "JOIN users u ON u.id=s.buyer_user_id WHERE r.chat_id=? AND u.telegram_id=? "
        "AND s.status IN ('active','cancelled') AND s.starts_at<=? AND s.ends_at>?",
        chat["id"], sender_id, db.now_iso(), db.now_iso(),
    )
    plan_quota = None
    if subscription:
        plan_quota = json.loads(subscription["limits_json"] or "{}").get("max_messages_per_day")
    if plan_quota is not None:
        config.update(max_messages=plan_quota, action="delete", exclude_admins=1, notify_owner=1, enabled=1)
    if not config["enabled"] or config["max_messages"] is None:
        return False
    if config["exclude_admins"] and _is_exempt_sender(chat["id"], sender) is not False:
        return False
    try:
        day = db.now().astimezone(ZoneInfo(config["timezone"] or "UTC")).date().isoformat()
    except Exception:
        day = db.now().date().isoformat()
    user_id, resource_id, message_id = config["user_id"], config["resource_id"], int(message["message_id"])
    warning_due = False
    exceeded = False
    with db.tx():
        current = db.one("SELECT count,last_message_id FROM message_limit_counters "
                         "WHERE user_id=? AND resource_id=? AND sender_id=? AND day=?",
                         user_id, resource_id, sender_id, day)
        if current and message_id <= current["last_message_id"]:
            return True
        count = (current["count"] if current else 0) + 1
        now = db.now_iso()
        db.run("INSERT INTO message_limit_counters(user_id,resource_id,sender_id,day,count,last_message_id,updated_at) "
               "VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,resource_id,sender_id,day) DO UPDATE SET "
               "count=excluded.count,last_message_id=excluded.last_message_id,updated_at=excluded.updated_at",
               user_id, resource_id, sender_id, day, count, message_id, now)
        exceeded = count > int(config["max_messages"])
        if exceeded:
            db.insert("message_limit_events", user_id=user_id, resource_id=resource_id, sender_id=sender_id,
                      day=day, message_id=message_id, message_count=count, action=config["action"], created_at=now)
            warning_due = count == int(config["max_messages"]) + 1

    if not exceeded:
        return False
    delete_message = config["action"] in ("delete", "delete_warn")
    if delete_message:
        try:
            telegram.client().call("deleteMessage", chat_id=chat["id"], message_id=message_id)
        except (TelegramError, TelegramNetworkError) as e:
            log.warning("message quota could not delete message in %s: %s", chat["id"], e)
    if warning_due and config["action"] in ("delete_warn", "warn"):
        say(chat["id"], f"Лимит участника: не более {config['max_messages']} сообщений в день. "
            + ("Превышение удалено." if delete_message else "Пожалуйста, остановите отправку."))
    if warning_due and config["notify_owner"]:
        notify_owner(user_id, f"⚠️ В группе «{config['resource_title']}» участник {sender_id} превысил "
                     f"дневной лимит: {count}/{config['max_messages']} сообщений.", "tools")
    db.event(user_id, "message_limit_exceeded", f"Участник {sender_id}: {count}/{config['max_messages']} сообщений за день",
             resource_id)
    return delete_message


def process_autoclean(chat_id: int, text: str, message_id: int | None = None, sender: dict | None = None,
                      links: list[str] | None = None) -> None:
    if not text or not message_id:
        return
    sender_id = int(sender["id"]) if sender and sender.get("id") is not None else None
    if sender_id is not None and sender_id == telegram.state.get("bot_id"):
        return
    resources = db.q("SELECT * FROM resources WHERE chat_id=? AND status='active'", chat_id)
    if not resources:
        return
    c = telegram.client()
    if not c:
        return
    for res in sorted(resources, key=lambda r: r["id"]):
        rules = db.q(
            "SELECT * FROM autoclean_rules WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY id DESC",
            res["user_id"], res["id"],
        )
        for rule in rules:
            if not _autoclean_matches(rule, text, links):
                continue
            try:
                c.call("deleteMessage", chat_id=chat_id, message_id=int(message_id))
            except (TelegramError, TelegramNetworkError):
                pass
            db.insert(
                "autoclean_events",
                user_id=res["user_id"],
                resource_id=res["id"],
                rule_id=rule["id"],
                message_id=int(message_id),
                message=text[:200],
                created_at=db.now_iso(),
            )
            return


def process_autoreplies(chat_id: int, text: str, sender: dict | None = None) -> None:
    if not text or text.startswith("/"):
        return
    sender_id = int(sender["id"]) if sender and sender.get("id") is not None else None
    if sender_id is not None and sender_id == telegram.state.get("bot_id"):
        return
    resources = db.q("SELECT * FROM resources WHERE chat_id=? AND status='active'", chat_id)
    if not resources:
        return
    for res in sorted(resources, key=lambda r: r["id"]):
        rules = db.q(
            "SELECT * FROM autoreplies WHERE user_id=? AND resource_id=? AND enabled=1 ORDER BY priority DESC, id DESC",
            res["user_id"], res["id"],
        )
        for rule in rules:
            if not _select_autoreply(rule, text, sender_id):
                continue
            replies = [line.strip() for line in str(rule["reply_text"]).splitlines() if line.strip()]
            if not replies:
                continue
            reply = random.choice(replies)
            say(chat_id, reply)
            db.insert(
                "autoreply_events",
                user_id=res["user_id"],
                resource_id=res["id"],
                rule_id=rule["id"],
                sender_id=sender_id or 0,
                message=text[:200],
                created_at=db.now_iso(),
            )
            return


def handle_message(msg: dict) -> None:
    chat = msg["chat"]
    if "migrate_to_chat_id" in msg or "migrate_from_chat_id" in msg:
        _handle_group_migration(msg)
        return
    text = (msg.get("text") or msg.get("caption") or "").strip()
    if chat["type"] == "private":
        if text.startswith("/start login_"):
            return confirm_login(msg, text[len("/start login_"):].strip())
        if text.startswith(("/start", "/help", "/app")):
            return send_welcome(chat["id"])
        return
    if chat["type"] in ("group", "supergroup", "channel"):
        if text.startswith("/connect"):
            parts = text.split()
            if len(parts) >= 2:
                link_resource(chat, parts[1].split("@")[0], msg.get("from") or {})
            return
        links = extract_message_links(msg, text)
        quota_removed = process_member_message_limit(msg)
        protection_removed = process_automatic_protection(msg, text, links)
        if not quota_removed and not protection_removed:
            process_autoclean(chat["id"], text, msg.get("message_id"), msg.get("from"), links)
            process_autoreplies(chat["id"], text, msg.get("from"))
        # privacy: only counters are stored, never message content
        res = db.q("SELECT id FROM resources WHERE chat_id=? AND status!='disconnected'", chat["id"])
        for r in res:
            _bump(r["id"], "messages")


def send_welcome(chat_id: int) -> None:
    web = cfg.PUBLIC_URL or f"http://{cfg.HOST}:{cfg.PORT}"
    text = ("Привет! Я MarketPilot — помогаю управлять Telegram-каналами и группами: публикации по расписанию, "
            "аналитика и уведомления в одном приложении.\n\n")
    markup = webapp_markup()
    if markup:
        text += "Нажмите кнопку ниже, чтобы открыть приложение прямо в Telegram."
    else:
        text += (f"Веб-панель: {web}\n\nМини-приложение в Telegram пока не настроено: для него нужен HTTPS-адрес "
                 "(переменная PUBLIC_URL). См. docs/MINIAPP.md.")
    text += ("\n\nЧтобы подключить канал или группу: откройте «Работа» → «Ресурсы» → «Подключить», добавьте меня "
             "администратором и отправьте в чате команду /connect КОД.")
    say(chat_id, text, reply_markup=markup)


def configure_bot() -> None:
    """Commands and the chat menu button ("🚀 Открыть") that launches the Mini App for every user."""
    c = telegram.client()
    try:
        c.call("setMyCommands", commands=[
            {"command": "start", "description": "Запустить бота и открыть приложение"},
            {"command": "app", "description": "🚀 Открыть приложение"},
            {"command": "help", "description": "Помощь"},
        ])
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("setMyCommands failed: %s", e)
    url = miniapp_url()
    if not url:
        log.warning("PUBLIC_URL is not an https:// address -> Mini App buttons are disabled (see docs/MINIAPP.md)")
        return
    try:
        c.call("setChatMenuButton", menu_button={"type": "web_app", "text": "🚀 Открыть", "web_app": {"url": url}})
        log.info("Mini App menu button set: %s", url)
    except (TelegramError, TelegramNetworkError) as e:
        log.warning("setChatMenuButton failed: %s", e)


def _handle_group_migration(msg: dict) -> None:
    chat = msg["chat"]
    if "migrate_to_chat_id" in msg:
        old_chat_id, new_chat_id = chat["id"], int(msg["migrate_to_chat_id"])
    else:
        old_chat_id, new_chat_id = int(msg["migrate_from_chat_id"]), chat["id"]
    for resource in db.q("SELECT * FROM resources WHERE chat_id=? AND status!='disconnected'", old_chat_id):
        existing = db.one("SELECT id FROM resources WHERE user_id=? AND chat_id=? AND id!=?",
                          resource["user_id"], new_chat_id, resource["id"])
        if existing:
            log.warning("cannot migrate resource %s: destination chat is already connected", resource["id"])
            continue
        db.run("UPDATE resources SET chat_id=?,type='supergroup',title=?,username=NULL,last_checked_at=? WHERE id=?",
               new_chat_id, chat.get("title") or resource["title"], db.now_iso(), resource["id"])
        db.event(resource["user_id"], "resource_migrated",
                 f"«{resource['title']}» преобразована в супергруппу; настройки тарифа сохранены", resource["id"])


def handle_channel_post(post: dict) -> None:
    text = (post.get("text") or post.get("caption") or "").strip()
    if text.startswith("/connect"):
        parts = text.split()
        if len(parts) >= 2:
            link_resource(post["chat"], parts[1], {})
    if post.get("chat", {}).get("type") in ("channel", "group", "supergroup"):
        links = extract_message_links(post, text)
        protection_removed = process_automatic_protection(post, text, links)
        quota_removed = process_member_message_limit(post)
        if not quota_removed and not protection_removed:
            process_autoclean(post["chat"]["id"], text, post.get("message_id"), post.get("from"), links)
            process_autoreplies(post["chat"]["id"], text, post.get("from"))


def confirm_login(msg: dict, raw_token: str) -> None:
    row = db.one("SELECT * FROM login_tokens WHERE token_hash=?", security.hash_token(raw_token))
    chat_id = msg["chat"]["id"]
    if row is None or row["consumed"] or row["expires_at"] < db.now_iso():
        return say(chat_id, "Ссылка для входа устарела. Обновите страницу входа и попробуйте снова.")
    user = security.upsert_telegram_user(msg["from"])
    db.run("UPDATE login_tokens SET user_id=?, confirmed=1 WHERE token_hash=?", user["id"], row["token_hash"])
    say(chat_id, "✅ Вход подтверждён. Вернитесь в браузер.")


def link_resource(chat: dict, code: str, sender: dict) -> None:
    c = telegram.client()
    link = db.one("SELECT * FROM link_codes WHERE code=?", code.upper())
    if link is None or link["used"] or link["expires_at"] < db.now_iso():
        return say(chat["id"], "Код недействителен или истёк. Создайте новый в панели MarketPilot.")

    sender_id = sender.get("id")
    created_by_tg = int(link["created_by_telegram_id"]) if "created_by_telegram_id" in link.keys() else 0
    if sender_id and created_by_tg and created_by_tg != int(sender_id):
        return say(chat["id"], "Код привязан к другому Telegram-аккаунту. Подключать чужие чаты запрещено.")

    rtype = CHAT_TYPES.get(chat["type"])
    if rtype is None:
        return
    try:
        if sender_id:  # in groups only an admin may link the chat
            who = c.chat_member(chat["id"], sender_id)
            if who.get("status") not in ("creator", "administrator"):
                return say(chat["id"], "Подключить чат может только администратор.")
        me = telegram.state["bot_id"]
        member = c.chat_member(chat["id"], me)
        count = c.member_count(chat["id"])
    except (TelegramError, TelegramNetworkError) as e:
        return say(chat["id"], f"Не удалось проверить права бота: {e}")

    caps, missing = telegram.evaluate_rights(rtype, member)
    status = "active" if "publish" in caps else "missing_rights"
    user_id = link["user_id"]
    user = db.one("SELECT * FROM users WHERE id=?", user_id)
    if user is None:
        return say(chat["id"], "Ссылка устарела: владелец аккаунта больше не существует.")
    from .config import PLANS
    limit = PLANS.get(user["plan"], PLANS["free"])["resources"]
    existing = db.one("SELECT * FROM resources WHERE user_id=? AND chat_id=?", user_id, chat["id"])
    foreign = db.one("SELECT * FROM resources WHERE chat_id=? AND user_id!=? AND status!='disconnected' LIMIT 1", chat["id"], user_id)
    if foreign is not None:
        return say(chat["id"], "Этот чат уже подключён к другому аккаунту MarketPilot.")
    used = db.one("SELECT COUNT(*) n FROM resources WHERE user_id=? AND status!='disconnected' AND is_demo=0", user_id)["n"]
    if (existing is None or existing["status"] == "disconnected") and used >= limit:
        return say(chat["id"], f"Достигнут лимит тарифа: {limit} ресурсов.")

    with db.tx():
        if existing:
            db.run("UPDATE resources SET title=?, username=?, type=?, status=?, capabilities=?, missing_rights=?, "
                   "members=?, last_checked_at=?, is_demo=0 WHERE id=?",
                   chat.get("title", ""), chat.get("username"), rtype, status, json.dumps(caps), json.dumps(missing),
                   count, db.now_iso(), existing["id"])
            rid = existing["id"]
        else:
            rid = db.insert("resources", user_id=user_id, chat_id=chat["id"], title=chat.get("title", ""),
                            username=chat.get("username"), type=rtype, status=status,
                            capabilities=json.dumps(caps), missing_rights=json.dumps(missing), members=count,
                            connected_at=db.now_iso(), last_checked_at=db.now_iso())
        db.insert("snapshots", resource_id=rid, members=count, taken_at=db.now_iso())
        db.run("UPDATE link_codes SET used=1 WHERE code=?", link["code"])
        db.event(user_id, "resource_connected", f"Подключён ресурс «{chat.get('title', '')}»", rid)
    if status == "active":
        say(chat["id"], "✅ Ресурс подключён к MarketPilot.")
    else:
        say(chat["id"], "Ресурс подключён, но боту не хватает прав: " + ", ".join(missing))


def handle_my_chat_member(upd: dict) -> None:
    """Rights of the bot changed or the bot was removed."""
    chat = upd["chat"]
    new = upd["new_chat_member"]
    rtype = CHAT_TYPES.get(chat["type"])
    if rtype is None:
        return
    for res in db.q("SELECT * FROM resources WHERE chat_id=? AND status!='disconnected'", chat["id"]):
        if new["status"] in ("left", "kicked"):
            caps, missing, status = [], ["administrator"], "disconnected"
            msg = f"Бот удалён из «{res['title']}», ресурс отключён"
        else:
            caps, missing = telegram.evaluate_rights(rtype, new)
            status = "active" if "publish" in caps else "missing_rights"
            msg = (f"Права бота в «{res['title']}» изменены" +
                   (f": не хватает {', '.join(missing)}" if missing else ""))
        db.run("UPDATE resources SET status=?, capabilities=?, missing_rights=?, last_checked_at=? WHERE id=?",
               status, json.dumps(caps), json.dumps(missing), db.now_iso(), res["id"])
        db.event(res["user_id"], "rights_changed", msg, res["id"])
        if status == "disconnected":
            cancel_pending(res["id"], "bot removed from chat")
        if status != "active":
            notify_owner(res["user_id"], "⚠️ " + msg)


def handle_chat_member(upd: dict) -> None:
    old, new = upd["old_chat_member"]["status"], upd["new_chat_member"]["status"]
    present = ("member", "administrator", "creator", "restricted")
    joined = old not in present and new in present
    left = old in present and new not in present
    if not (joined or left):
        return
    for r in db.q("SELECT id FROM resources WHERE chat_id=? AND status!='disconnected'", upd["chat"]["id"]):
        _bump(r["id"], "joins" if joined else "leaves")
    member_user_id = (upd["new_chat_member"].get("user") or {}).get("id")
    if joined and member_user_id is not None:
        from . import marketplace
        marketplace.queue_member_permissions(upd["chat"]["id"], member_user_id)


def cancel_pending(resource_id: int, reason: str) -> None:
    db.run("UPDATE post_targets SET status='cancelled', error=? WHERE resource_id=? AND status IN ('scheduled','draft')",
           reason, resource_id)


# ---------- polling loop ----------
def poll_forever(stop: threading.Event) -> None:
    c = telegram.client()
    if not c:
        return
    # 1. connect (retry until it works; the app stays usable in demo mode meanwhile)
    while not stop.is_set():
        try:
            me = c.get_me()
            telegram.state.update(connected=True, username=me.get("username", ""), bot_id=me["id"], error=None)
            if not cfg.BOT_USERNAME:
                cfg.BOT_USERNAME = me.get("username", "")
            try:
                c.call("deleteWebhook", http_timeout=15)  # polling and webhook are mutually exclusive
            except (TelegramError, TelegramNetworkError):
                pass
            log.info("Telegram connected as @%s", telegram.state["username"])
            configure_bot()
            break
        except TelegramError as e:
            telegram.state.update(connected=False, error=f"Telegram: {e.description or e.code}")
            log.error("Telegram rejected the bot token: %s", e)
        except TelegramNetworkError as e:
            telegram.state.update(connected=False, error=f"Нет связи с Telegram: {e}")
            log.warning("cannot reach Telegram: %s", e)
        stop.wait(30)

    # 2. updates
    offset = int(db.get_meta("tg_offset", "0"))
    while not stop.is_set():
        try:
            updates = _get_updates(c, offset)
            for upd in updates:
                offset = upd["update_id"] + 1
                try:
                    handle_update(upd)
                except Exception:
                    log.exception("update %s failed", upd.get("update_id"))
                db.set_meta("tg_offset", offset)
            telegram.state.update(connected=True, error=None)
        except TelegramError as e:
            telegram.state["error"] = f"Telegram: {e.description or e.code}"
            log.error("getUpdates: %s", e)
            stop.wait(10 if e.code != 429 else (e.retry_after or 5))
        except TelegramNetworkError as e:
            telegram.state.update(connected=False, error=f"Нет связи с Telegram: {e}")
            stop.wait(5)


def _get_updates(c, offset):
    # long polling: server holds the request up to 25 s, socket timeout must be larger
    req_params = {"offset": offset, "limit": 50, "timeout": 25, "allowed_updates": ALLOWED_UPDATES}
    return c.call("getUpdates", http_timeout=40, **req_params)
