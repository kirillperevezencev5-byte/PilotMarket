"""Tiny HTTP framework on top of http.server: JSON routes, cookie/bearer sessions, static files, security headers."""
import json
import logging
import mimetypes
import re
import secrets
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import db, security
from .config import ROOT, cfg

log = logging.getLogger("marketpilot.http")
STATIC = ROOT / "static"
COOKIE = "mp_session"

ROUTES: list[tuple[str, re.Pattern, callable, bool]] = []
ROUTE_TEMPLATES: dict[int, str] = {}  # id(compiled pattern) -> original path template (low-cardinality audit key)
MUTATING = ("POST", "PUT", "PATCH", "DELETE")
ROLE_LEVEL = {"viewer": 0, "moderator": 1, "admin": 2, "owner": 3}


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str = ""):
        super().__init__(message or code)
        self.status, self.code, self.message = status, code, message or code


def route(method: str, path: str, public: bool = False):
    pattern = re.compile("^" + re.sub(r"<int:(\w+)>", r"(?P<\1>\\d+)", path) + "$")

    def deco(fn):
        ROUTES.append((method, pattern, fn, public))
        ROUTE_TEMPLATES[id(pattern)] = path
        return fn

    return deco


class Request:
    def __init__(self, handler: BaseHTTPRequestHandler, method: str, url):
        self.handler = handler
        self.method = method
        self.path = url.path
        self.query = {k: v[0] for k, v in parse_qs(url.query).items()}
        self.headers = handler.headers
        self.ip = handler.client_address[0]
        self.body: dict = {}
        self.raw_body = b""
        self.upload_name = ""
        self.upload_mime = ""
        self.user = None
        self.actor_user = None
        self.workspace_id = None
        self.workspace_role = None
        self.workspace_owner_id = None
        self.params: dict = {}
        self.new_cookies: list[str] = []
        self.session_token = ""
        self.request_id = secrets.token_hex(6)
        self.route_template = ""

    def int_param(self, name: str, default: int, lo: int, hi: int) -> int:
        try:
            value = int(self.query.get(name, default))
        except ValueError:
            value = default
        return max(lo, min(hi, value))

    def set_session(self, raw: str) -> None:
        parts = [f"{COOKIE}={raw}", "Path=/", "HttpOnly", "SameSite=Lax", f"Max-Age={cfg.SESSION_DAYS * 86400}"]
        if cfg.COOKIE_SECURE:
            parts.append("Secure")
        self.new_cookies.append("; ".join(parts))

    def clear_session(self) -> None:
        self.new_cookies.append(f"{COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")


def _read_cookie(header: str, name: str) -> str:
    for part in (header or "").split(";"):
        k, _, v = part.strip().partition("=")
        if k == name:
            return v
    return ""


def require_role(req: Request, workspace_id: int, minimum_role: str) -> str:
    """Return the member's role or reject access to a workspace operation."""
    member = db.one("SELECT role FROM workspace_members WHERE workspace_id=? AND user_id=?",
                    workspace_id, req.actor_user["id"])
    if member is None or ROLE_LEVEL.get(member["role"], -1) < ROLE_LEVEL[minimum_role]:
        raise ApiError(403, "workspace_forbidden", "Недостаточно прав в рабочем пространстве")
    return member["role"]


def _minimum_workspace_role(method: str, path: str) -> str:
    if path.startswith(("/api/v1/community-plans/", "/api/v1/community-subscriptions/")) and method == "POST":
        return "viewer"
    if path.startswith("/api/v1/marketplace/") or path.startswith("/api/v1/community-payments/"):
        return "viewer"
    if path.startswith("/api/v1/communities/") and method == "GET":
        return "viewer"
    if path.startswith(("/api/v1/moderation/", "/api/v1/anti-scam/", "/api/v1/autoclean/",
                        "/api/v1/autoreplies", "/api/v1/message-limits")):
        return "moderator" if method != "GET" else "viewer"
    if path.startswith(("/api/v1/billing/", "/api/v1/subscriptions")) and method != "GET":
        return "owner"
    return "viewer" if method == "GET" else "admin"


CSP = ("default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: https: http:; connect-src 'self'; "
       "frame-ancestors 'self' https://web.telegram.org https://*.telegram.org")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "MarketPilot"

    def log_message(self, fmt, *args):  # quieter default logging
        log.debug("%s %s", self.address_string(), fmt % args)

    def handle(self):
        try:
            super().handle()
        finally:
            db.close_thread()  # one short-lived thread per connection: release its SQLite handle

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_OPTIONS(self):
        origin = self.headers.get("Origin")
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Workspace-ID, X-Requested-With")
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
        self.end_headers()

    # ---- core ----
    def _dispatch(self, method: str):
        url = urlparse(self.path)
        if not url.path.startswith("/api/"):
            if method != "GET":
                return self._json(405, {"error": "method_not_allowed"})
            return self._static(url.path)
        req = Request(self, method, url)
        try:
            self._check_origin()
            for m, pattern, fn, public in ROUTES:
                if m != method:
                    continue
                match = pattern.match(url.path)
                if not match:
                    continue
                req.params = {k: int(v) for k, v in match.groupdict().items()}
                req.route_template = ROUTE_TEMPLATES.get(id(pattern), url.path)
                token = ""
                auth = self.headers.get("Authorization", "")
                if auth.lower().startswith("bearer "):
                    token = auth[7:].strip()
                req.session_token = token or _read_cookie(self.headers.get("Cookie", ""), COOKIE)
                row = security.user_for_session(req.session_token)
                if row is not None:
                    req.user = row
                    req.actor_user = row
                if not public and req.user is None:
                    raise ApiError(401, "unauthorized", "Требуется вход")
                is_workspace_api = req.route_template.startswith("/api/v1/workspaces")
                is_personal_api = req.route_template.startswith(("/api/v1/me", "/api/v1/settings"))
                if req.user is not None and not is_workspace_api and not is_personal_api:
                    workspace_header = self.headers.get("X-Workspace-ID", "").strip()
                    try:
                        workspace_id = int(workspace_header) if workspace_header else db.ensure_workspace(req.actor_user["id"])
                    except ValueError:
                        raise ApiError(400, "bad_workspace", "Неверный идентификатор рабочего пространства")
                    role = require_role(req, workspace_id, _minimum_workspace_role(method, url.path))
                    workspace = db.one("SELECT id, owner_user_id FROM workspaces WHERE id=?", workspace_id)
                    req.workspace_id = workspace_id
                    req.workspace_role = role
                    req.workspace_owner_id = workspace["owner_user_id"]
                    if workspace["owner_user_id"] != req.actor_user["id"]:
                        req.user = db.one("SELECT * FROM users WHERE id=?", workspace["owner_user_id"])
                self._read_body(req)
                result = fn(req)
                status, payload = result if isinstance(result, tuple) else (200, result)
                self._audit(req, status)
                return self._json(status, payload, req.new_cookies, req.request_id)
            raise ApiError(404, "not_found", "Not found")
        except ApiError as e:
            self._audit(req, e.status, error=e.code)
            self._json(e.status, {"error": e.code, "message": e.message, "request_id": req.request_id},
                       req.new_cookies, req.request_id)
        except Exception as e:  # noqa: BLE001
            log.error("unhandled error [%s]: %s", req.request_id, traceback.format_exc())
            self._audit(req, 500, error=f"{type(e).__name__}: {e}", force=True)
            self._json(500, {"error": "internal", "message": "Internal error", "request_id": req.request_id},
                       None, req.request_id)

    def _audit(self, req: "Request", status: int, error: str = "", force: bool = False) -> None:
        """Journal every state-changing call of a signed-in user, plus any failure (4xx/5xx) of theirs."""
        if not req.route_template and not force:
            return
        if req.method not in MUTATING and status < 400:
            return
        if req.user is None and not force:
            return
        actor = req.actor_user or req.user
        uid = actor["id"] if actor is not None else None
        db.audit(uid, f"{req.method} {req.route_template or req.path}", method=req.method, status=status,
                 resource_id=req.params.get("resource_id") or (req.params.get("id") if "/resources/" in req.route_template else None),
             entity_id=req.params.get("id"), ip=req.ip, request_id=req.request_id, error=error,
             workspace_id=req.workspace_id)

    def _check_origin(self):
        origin = self.headers.get("Origin")
        if origin and self.command not in ("GET", "OPTIONS"):
            host = self.headers.get("Host", "")
            if urlparse(origin).netloc != host and not (cfg.PUBLIC_URL and origin.rstrip("/") == cfg.PUBLIC_URL):
                raise ApiError(403, "bad_origin", "Cross-origin request rejected")

    def _read_body(self, req: Request):
        length = int(self.headers.get("Content-Length") or 0)
        if req.path == "/api/v1/media" and req.method == "POST":
            if length <= 0:
                raise ApiError(400, "empty_upload", "Выберите изображение")
            if length > 10 * 1024 * 1024:
                raise ApiError(413, "too_large", "Изображение должно быть не больше 10 MiB")
            req.upload_mime = (self.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            if req.upload_mime not in {"image/jpeg", "image/png", "image/webp"}:
                raise ApiError(415, "bad_media_type", "Поддерживаются JPEG, PNG и WebP")
            req.raw_body = self.rfile.read(length)
            req.upload_name = unquote(self.headers.get("X-File-Name", "image"))
            return
        if length > 1_000_000:
            raise ApiError(413, "too_large", "Request too large")
        if length == 0:
            return
        raw = self.rfile.read(length)
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            raise ApiError(415, "bad_content_type", "JSON required")
        try:
            body = json.loads(raw)
        except ValueError:
            raise ApiError(400, "bad_json", "Invalid JSON")
        if not isinstance(body, dict):
            raise ApiError(400, "bad_json", "JSON object expected")
        req.body = body

    def _headers(self, extra=None):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", CSP)
        for c in extra or []:
            self.send_header("Set-Cookie", c)

    def _json(self, status: int, payload, cookies=None, request_id: str = ""):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if request_id:
            self.send_header("X-Request-ID", request_id)
        self._headers(cookies)
        self.end_headers()
        self.wfile.write(data)

    def _static(self, path: str):
        if path == "/app":
            self.send_response(301)
            self.send_header("Location", "/app/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        rel = path.lstrip("/") or "index.html"
        target = (STATIC / rel).resolve()
        if target.is_dir():
            target = target / "index.html"
        if STATIC.resolve() not in target.parents and target != STATIC.resolve():
            return self._json(404, {"error": "not_found"})
        if not target.is_file():
            if "." in Path(rel).name:  # missing asset
                return self._json(404, {"error": "not_found"})
            target = STATIC / "index.html"  # SPA fallback
        data = target.read_bytes()
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if target.suffix in (".js", ".css", ".html", ".svg"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self._headers()
        self.end_headers()
        self.wfile.write(data)


def make_server() -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer((cfg.HOST, cfg.PORT), Handler)
    srv.daemon_threads = True
    return srv


def serve_in_thread(srv: ThreadingHTTPServer) -> threading.Thread:
    t = threading.Thread(target=srv.serve_forever, name="http", daemon=True)
    t.start()
    return t
