"""SQLite storage. One connection per thread, WAL mode, schema created on start.

Tenant model for v0.1: one workspace per user, so `user_id` is the tenant key on every table.
Every query in api.py filters by the session user's id.
"""
import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import cfg

_local = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegram_id INTEGER UNIQUE,
  first_name TEXT NOT NULL DEFAULT '',
  username TEXT,
  language TEXT NOT NULL DEFAULT 'ru',
  timezone TEXT NOT NULL DEFAULT 'Europe/Moscow',
  is_demo INTEGER NOT NULL DEFAULT 0,
  notify INTEGER NOT NULL DEFAULT 1,
  notif_seen INTEGER NOT NULL DEFAULT 0,
  plan TEXT NOT NULL DEFAULT 'beta',
  theme TEXT NOT NULL DEFAULT 'light',
  ui_density TEXT NOT NULL DEFAULT 'comfortable',
  security_mode TEXT NOT NULL DEFAULT 'standard',
  created_at TEXT NOT NULL,
  last_seen_at TEXT
);
CREATE TABLE IF NOT EXISTS workspaces(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  owner_user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workspace_members(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK(role IN ('owner','admin','moderator','viewer')),
  joined_at TEXT NOT NULL,
  UNIQUE(workspace_id, user_id)
);
CREATE INDEX IF NOT EXISTS ix_workspace_members_user ON workspace_members(user_id, workspace_id);
CREATE TABLE IF NOT EXISTS workspace_invitations(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK(role IN ('admin','moderator','viewer')),
  invited_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  used_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  revoked_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_workspace_invitations_workspace ON workspace_invitations(workspace_id, created_at DESC);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS login_tokens(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  confirmed INTEGER NOT NULL DEFAULT 0,
  consumed INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS resources(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  chat_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  username TEXT,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  capabilities TEXT NOT NULL DEFAULT '[]',
  missing_rights TEXT NOT NULL DEFAULT '[]',
  is_demo INTEGER NOT NULL DEFAULT 0,
  members INTEGER,
  connected_at TEXT NOT NULL,
  last_checked_at TEXT,
  UNIQUE(user_id, chat_id)
);
CREATE INDEX IF NOT EXISTS ix_resources_chat ON resources(chat_id);
CREATE TABLE IF NOT EXISTS link_codes(
  code TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_by_telegram_id INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT NOT NULL,
  used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL DEFAULT '',
  image_url TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS media_uploads(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  data BLOB NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_media_user ON media_uploads(user_id, id DESC);
CREATE TABLE IF NOT EXISTS post_targets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  scheduled_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TEXT,
  message_id INTEGER,
  error TEXT,
  published_at TEXT,
  started_at TEXT,
  UNIQUE(post_id, resource_id)
);
CREATE INDEX IF NOT EXISTS ix_targets_due ON post_targets(status, scheduled_at);
CREATE TABLE IF NOT EXISTS templates(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autoreplies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT '',
  match_type TEXT NOT NULL DEFAULT 'keyword',
  match_text TEXT NOT NULL DEFAULT '',
  reply_text TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  priority INTEGER NOT NULL DEFAULT 0,
  cooldown_minutes INTEGER NOT NULL DEFAULT 0,
  excluded_users TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autoreply_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  rule_id INTEGER REFERENCES autoreplies(id) ON DELETE SET NULL,
  sender_id INTEGER NOT NULL DEFAULT 0,
  message TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autoclean_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT '',
  match_type TEXT NOT NULL DEFAULT 'keyword',
  match_text TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS autoclean_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  rule_id INTEGER REFERENCES autoclean_rules(id) ON DELETE SET NULL,
  message_id INTEGER NOT NULL DEFAULT 0,
  message TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS publication_limits(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'messages_per_day',
  value INTEGER NOT NULL DEFAULT 1,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  UNIQUE(user_id, resource_id, kind)
);
CREATE TABLE IF NOT EXISTS message_limits(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  max_messages INTEGER NOT NULL DEFAULT 20,
  action TEXT NOT NULL DEFAULT 'delete',
  exclude_admins INTEGER NOT NULL DEFAULT 1,
  notify_owner INTEGER NOT NULL DEFAULT 1,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(user_id, resource_id)
);
CREATE TABLE IF NOT EXISTS message_limit_counters(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  sender_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  last_message_id INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id, resource_id, sender_id, day)
);
CREATE TABLE IF NOT EXISTS message_limit_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  sender_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  message_id INTEGER NOT NULL,
  message_count INTEGER NOT NULL,
  action TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_message_limit_events ON message_limit_events(user_id, created_at);
CREATE TABLE IF NOT EXISTS scam_domains(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  domain TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'review',
  created_at TEXT NOT NULL,
  UNIQUE(user_id, domain)
);
CREATE TABLE IF NOT EXISTS scam_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER REFERENCES resources(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'review',
  risk_score INTEGER NOT NULL DEFAULT 0,
  message TEXT NOT NULL,
  threat_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS moderation_rules(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  level TEXT NOT NULL DEFAULT 'standard',
  match_type TEXT NOT NULL DEFAULT 'keyword',
  match_text TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL DEFAULT 'warn',
  created_at TEXT NOT NULL,
  UNIQUE(user_id, resource_id, name)
);
CREATE TABLE IF NOT EXISTS moderation_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  rule_id INTEGER REFERENCES moderation_rules(id) ON DELETE SET NULL,
  kind TEXT NOT NULL DEFAULT 'warning',
  message TEXT NOT NULL,
  risk_score INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS snapshots(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  members INTEGER NOT NULL,
  taken_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_snap ON snapshots(resource_id, taken_at);
CREATE TABLE IF NOT EXISTS group_stats(
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  messages INTEGER NOT NULL DEFAULT 0,
  joins INTEGER NOT NULL DEFAULT 0,
  leaves INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(resource_id, day)
);
CREATE TABLE IF NOT EXISTS subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'free',
  status TEXT NOT NULL DEFAULT 'active',
  started_at TEXT NOT NULL,
  ends_at TEXT,
  auto_renew INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_plans(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
  currency TEXT NOT NULL DEFAULT 'RUB' CHECK(currency = 'RUB'),
  duration_days INTEGER NOT NULL CHECK(duration_days BETWEEN 1 AND 3650),
  max_members INTEGER,
  limits_json TEXT NOT NULL DEFAULT '{}',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_community_plans_resource ON community_plans(resource_id, active, id DESC);
CREATE TABLE IF NOT EXISTS community_chat_settings(
  resource_id INTEGER PRIMARY KEY REFERENCES resources(id) ON DELETE CASCADE,
  permissions_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_merchants(
  resource_id INTEGER PRIMARY KEY REFERENCES resources(id) ON DELETE CASCADE,
  workspace_id INTEGER REFERENCES workspaces(id),
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  yookassa_account_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pending','active','suspended')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  plan_id INTEGER NOT NULL REFERENCES community_plans(id),
  buyer_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK(status IN ('pending','active','cancelled','expired','refund_pending','refunded','payment_failed')),
  starts_at TEXT,
  ends_at TEXT,
  auto_renew INTEGER NOT NULL DEFAULT 0,
  payment_method_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_community_subscriptions_expiry ON community_subscriptions(status, ends_at);
CREATE INDEX IF NOT EXISTS ix_community_subscriptions_buyer ON community_subscriptions(buyer_user_id, id DESC);
CREATE TABLE IF NOT EXISTS community_payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  subscription_id INTEGER NOT NULL REFERENCES community_subscriptions(id),
  plan_id INTEGER NOT NULL REFERENCES community_plans(id),
  resource_id INTEGER NOT NULL REFERENCES resources(id),
  buyer_user_id INTEGER NOT NULL REFERENCES users(id),
  owner_user_id INTEGER NOT NULL REFERENCES users(id),
  provider TEXT NOT NULL DEFAULT 'yookassa' CHECK(provider = 'yookassa'),
  provider_payment_id TEXT UNIQUE,
  idempotency_key TEXT NOT NULL UNIQUE,
  amount_minor INTEGER NOT NULL,
  provider_fee_minor INTEGER NOT NULL DEFAULT 0,
  commission_minor INTEGER NOT NULL,
  owner_amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'RUB' CHECK(currency = 'RUB'),
  status TEXT NOT NULL CHECK(status IN ('pending','waiting_for_capture','succeeded','canceled','refunded','refund_pending','unknown')),
  confirmation_url TEXT,
  payment_method_id TEXT,
  is_recurring INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  paid_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_community_payments_buyer ON community_payments(buyer_user_id, id DESC);
CREATE INDEX IF NOT EXISTS ix_community_payments_owner ON community_payments(owner_user_id, id DESC);
CREATE TABLE IF NOT EXISTS community_refunds(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  payment_id INTEGER NOT NULL REFERENCES community_payments(id),
  owner_user_id INTEGER NOT NULL REFERENCES users(id),
  requested_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  amount_minor INTEGER NOT NULL,
  provider_refund_id TEXT UNIQUE,
  idempotency_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK(status IN ('requested','approved','pending','succeeded','failed','rejected')),
  reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS community_ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  owner_user_id INTEGER NOT NULL REFERENCES users(id),
  resource_id INTEGER NOT NULL REFERENCES resources(id),
  payment_id INTEGER REFERENCES community_payments(id),
  refund_id INTEGER REFERENCES community_refunds(id),
  currency TEXT NOT NULL CHECK(currency = 'RUB'),
  kind TEXT NOT NULL CHECK(kind IN ('sale','commission','provider_fee','refund','payout')),
  amount_minor INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(payment_id, kind),
  UNIQUE(refund_id, kind)
);
CREATE INDEX IF NOT EXISTS ix_community_ledger_owner ON community_ledger(owner_user_id, currency, id DESC);
CREATE TABLE IF NOT EXISTS billing_webhook_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,
  event_key TEXT NOT NULL,
  event_type TEXT NOT NULL,
  processed_at TEXT NOT NULL,
  UNIQUE(provider, event_key)
);
CREATE TABLE IF NOT EXISTS community_access_jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  subscription_id INTEGER NOT NULL REFERENCES community_subscriptions(id) ON DELETE CASCADE,
  action TEXT NOT NULL CHECK(action IN ('invite','revoke')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','done','failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(subscription_id, action)
);
CREATE INDEX IF NOT EXISTS ix_community_access_jobs_due ON community_access_jobs(status, id);
CREATE TABLE IF NOT EXISTS community_permission_jobs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  subscription_id INTEGER NOT NULL UNIQUE REFERENCES community_subscriptions(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','done','failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_community_permission_jobs_due ON community_permission_jobs(status, id);
CREATE TABLE IF NOT EXISTS community_subscription_notices(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workspace_id INTEGER REFERENCES workspaces(id),
  subscription_id INTEGER NOT NULL REFERENCES community_subscriptions(id) ON DELETE CASCADE,
  notice_type TEXT NOT NULL CHECK(notice_type IN ('expiring','payment_failed','expired')),
  ends_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(subscription_id, notice_type, ends_at)
);
CREATE TABLE IF NOT EXISTS ad_campaigns(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT '',
  budget REAL NOT NULL DEFAULT 0,
  spend REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'scheduled',
  starts_at TEXT,
  ends_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  resource_id INTEGER REFERENCES resources(id) ON DELETE SET NULL,
  kind TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_events_user ON events(user_id, created_at);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  action TEXT NOT NULL,
  method TEXT NOT NULL DEFAULT '',
  status INTEGER NOT NULL DEFAULT 0,
  resource_id INTEGER,
  entity_id INTEGER,
  ip TEXT NOT NULL DEFAULT '',
  request_id TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_audit_user ON audit_log(user_id, id DESC);
CREATE INDEX IF NOT EXISTS ix_audit_created ON audit_log(created_at);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
"""


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def now_iso() -> str:
    return iso(now())


def parse_iso(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def conn() -> sqlite3.Connection:
    c = getattr(_local, "conn", None)
    if c is None:
        Path(cfg.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(cfg.DB_PATH, timeout=30, isolation_level=None)  # autocommit; use tx() for groups
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA foreign_keys=ON")
        c.execute("PRAGMA busy_timeout=30000")
        _local.conn = c
    return c


def close_thread() -> None:
    """Close this thread's connection (HTTP handler threads are short-lived)."""
    c = getattr(_local, "conn", None)
    if c is not None:
        try:
            c.close()
        finally:
            _local.conn = None


def init() -> None:
    conn().executescript(SCHEMA)
    # lightweight migrations for databases created by earlier versions
    user_cols = {r["name"] for r in conn().execute("PRAGMA table_info(users)")}
    for col, ddl in {
        "notif_seen": "ALTER TABLE users ADD COLUMN notif_seen INTEGER NOT NULL DEFAULT 0",
        "theme": "ALTER TABLE users ADD COLUMN theme TEXT NOT NULL DEFAULT 'light'",
        "ui_density": "ALTER TABLE users ADD COLUMN ui_density TEXT NOT NULL DEFAULT 'comfortable'",
        "security_mode": "ALTER TABLE users ADD COLUMN security_mode TEXT NOT NULL DEFAULT 'standard'",
    }.items():
        if col not in user_cols:
            conn().execute(ddl)

    template_cols = {r["name"] for r in conn().execute("PRAGMA table_info(templates)")}
    for col, ddl in {
        "category": "ALTER TABLE templates ADD COLUMN category TEXT NOT NULL DEFAULT 'general'",
        "is_favorite": "ALTER TABLE templates ADD COLUMN is_favorite INTEGER NOT NULL DEFAULT 0",
        "variables": "ALTER TABLE templates ADD COLUMN variables TEXT NOT NULL DEFAULT '[]'",
    }.items():
        if col not in template_cols:
            conn().execute(ddl)

    limit_table = {r["name"] for r in conn().execute("SELECT name FROM sqlite_master WHERE type='table' AND name='publication_limits'")}
    if "publication_limits" not in limit_table:
        conn().execute("CREATE TABLE IF NOT EXISTS publication_limits( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, kind TEXT NOT NULL DEFAULT 'messages_per_day', value INTEGER NOT NULL DEFAULT 1, enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, UNIQUE(user_id, resource_id, kind))")
    limit_cols = {r["name"] for r in conn().execute("PRAGMA table_info(publication_limits)")}
    for col, ddl in {
        "kind": "ALTER TABLE publication_limits ADD COLUMN kind TEXT NOT NULL DEFAULT 'messages_per_day'",
        "value": "ALTER TABLE publication_limits ADD COLUMN value INTEGER NOT NULL DEFAULT 1",
        "enabled": "ALTER TABLE publication_limits ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1",
        "created_at": "ALTER TABLE publication_limits ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
    }.items():
        if col not in limit_cols:
            conn().execute(ddl)

    link_code_cols = {r["name"] for r in conn().execute("PRAGMA table_info(link_codes)")}
    for col, ddl in {
      "created_by_telegram_id": "ALTER TABLE link_codes ADD COLUMN created_by_telegram_id INTEGER NOT NULL DEFAULT 0",
    }.items():
      if col not in link_code_cols:
        conn().execute(ddl)

    for table_name, create_sql in {
        "autoreplies": "CREATE TABLE IF NOT EXISTS autoreplies( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, name TEXT NOT NULL DEFAULT '', match_type TEXT NOT NULL DEFAULT 'keyword', match_text TEXT NOT NULL DEFAULT '', reply_text TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, priority INTEGER NOT NULL DEFAULT 0, cooldown_minutes INTEGER NOT NULL DEFAULT 0, excluded_users TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL)",
        "autoreply_events": "CREATE TABLE IF NOT EXISTS autoreply_events( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, rule_id INTEGER REFERENCES autoreplies(id) ON DELETE SET NULL, sender_id INTEGER NOT NULL DEFAULT 0, message TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)",
        "autoclean_rules": "CREATE TABLE IF NOT EXISTS autoclean_rules( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, name TEXT NOT NULL DEFAULT '', match_type TEXT NOT NULL DEFAULT 'keyword', match_text TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)",
        "autoclean_events": "CREATE TABLE IF NOT EXISTS autoclean_events( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, rule_id INTEGER REFERENCES autoclean_rules(id) ON DELETE SET NULL, message_id INTEGER NOT NULL DEFAULT 0, message TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)",
        "subscriptions": "CREATE TABLE IF NOT EXISTS subscriptions( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, plan TEXT NOT NULL DEFAULT 'free', status TEXT NOT NULL DEFAULT 'active', started_at TEXT NOT NULL, ends_at TEXT, auto_renew INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)",
        "ad_campaigns": "CREATE TABLE IF NOT EXISTS ad_campaigns( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, resource_id INTEGER NOT NULL REFERENCES resources(id) ON DELETE CASCADE, title TEXT NOT NULL DEFAULT '', budget REAL NOT NULL DEFAULT 0, spend REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'scheduled', starts_at TEXT, ends_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
    }.items():
        tables = {r["name"] for r in conn().execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))}
        if table_name not in tables:
            conn().execute(create_sql)

    for table_name, cols in {
        "autoreplies": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "name TEXT NOT NULL DEFAULT ''",
            "match_type TEXT NOT NULL DEFAULT 'keyword'",
            "match_text TEXT NOT NULL DEFAULT ''",
            "reply_text TEXT NOT NULL DEFAULT ''",
            "enabled INTEGER NOT NULL DEFAULT 1",
            "priority INTEGER NOT NULL DEFAULT 0",
            "cooldown_minutes INTEGER NOT NULL DEFAULT 0",
            "excluded_users TEXT NOT NULL DEFAULT '[]'",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "autoreply_events": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "rule_id INTEGER",
            "sender_id INTEGER NOT NULL DEFAULT 0",
            "message TEXT NOT NULL DEFAULT ''",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "autoclean_rules": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "name TEXT NOT NULL DEFAULT ''",
            "match_type TEXT NOT NULL DEFAULT 'keyword'",
            "match_text TEXT NOT NULL DEFAULT ''",
            "enabled INTEGER NOT NULL DEFAULT 1",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "autoclean_events": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "rule_id INTEGER",
            "message_id INTEGER NOT NULL DEFAULT 0",
            "message TEXT NOT NULL DEFAULT ''",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "subscriptions": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "plan TEXT NOT NULL DEFAULT 'free'",
            "status TEXT NOT NULL DEFAULT 'active'",
            "started_at TEXT NOT NULL DEFAULT ''",
            "ends_at TEXT",
            "auto_renew INTEGER NOT NULL DEFAULT 0",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "ad_campaigns": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "title TEXT NOT NULL DEFAULT ''",
            "budget REAL NOT NULL DEFAULT 0",
            "spend REAL NOT NULL DEFAULT 0",
            "status TEXT NOT NULL DEFAULT 'scheduled'",
            "starts_at TEXT",
            "ends_at TEXT",
            "created_at TEXT NOT NULL DEFAULT ''",
            "updated_at TEXT NOT NULL DEFAULT ''",
        ],
        "moderation_rules": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "name TEXT NOT NULL DEFAULT ''",
            "enabled INTEGER NOT NULL DEFAULT 1",
            "level TEXT NOT NULL DEFAULT 'standard'",
            "match_type TEXT NOT NULL DEFAULT 'keyword'",
            "match_text TEXT NOT NULL DEFAULT ''",
            "action TEXT NOT NULL DEFAULT 'warn'",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
        "moderation_events": [
            "user_id INTEGER NOT NULL DEFAULT 0",
            "resource_id INTEGER NOT NULL DEFAULT 0",
            "rule_id INTEGER",
            "kind TEXT NOT NULL DEFAULT 'warning'",
            "message TEXT NOT NULL DEFAULT ''",
            "risk_score INTEGER NOT NULL DEFAULT 0",
            "created_at TEXT NOT NULL DEFAULT ''",
        ],
    }.items():
        available = {r["name"] for r in conn().execute(f"PRAGMA table_info({table_name})")}
        if not available:
            continue
        for col in cols:
            name = col.split()[0]
            if name not in available:
                conn().execute(f"ALTER TABLE {table_name} ADD COLUMN {col}")

    _init_workspaces()


WORKSPACE_USER_TABLES = (
    "resources", "posts", "media_uploads", "post_targets", "templates", "autoreplies", "autoreply_events",
    "autoclean_rules", "autoclean_events", "publication_limits", "message_limits", "message_limit_counters",
    "message_limit_events", "scam_domains", "scam_events", "moderation_rules", "moderation_events",
    "subscriptions", "ad_campaigns", "events", "audit_log",
)
WORKSPACE_RESOURCE_TABLES = ("snapshots", "group_stats")


def _init_workspaces() -> None:
    """Backfill one personal workspace per user and attach legacy records idempotently."""
    c = conn()
    with tx():
        for user in c.execute("SELECT id, first_name FROM users").fetchall():
            workspace = c.execute("SELECT id FROM workspaces WHERE owner_user_id=?", (user["id"],)).fetchone()
            if workspace is None:
                created = now_iso()
                cur = c.execute("INSERT INTO workspaces(name, owner_user_id, created_at, updated_at) VALUES(?,?,?,?)",
                                (user["first_name"].strip() or "Рабочее пространство", user["id"], created, created))
                workspace_id = cur.lastrowid
            else:
                workspace_id = workspace["id"]
            c.execute("INSERT OR IGNORE INTO workspace_members(workspace_id, user_id, role, joined_at) VALUES(?,?,?,?)",
                      (workspace_id, user["id"], "owner", now_iso()))

        for table in WORKSPACE_USER_TABLES:
            columns = {row["name"] for row in c.execute(f"PRAGMA table_info({table})")}
            if not columns:
                continue
            if "workspace_id" not in columns:
                c.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER REFERENCES workspaces(id)")
            c.execute(f"UPDATE {table} SET workspace_id=(SELECT id FROM workspaces WHERE owner_user_id={table}.user_id) "
                      f"WHERE workspace_id IS NULL AND user_id IS NOT NULL")
            c.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_workspace ON {table}(workspace_id)")
            c.execute(f"""CREATE TRIGGER IF NOT EXISTS trg_{table}_workspace_insert
                AFTER INSERT ON {table}
                WHEN NEW.workspace_id IS NULL AND NEW.user_id IS NOT NULL
                BEGIN
                  UPDATE {table} SET workspace_id=(SELECT id FROM workspaces WHERE owner_user_id=NEW.user_id)
                  WHERE rowid=NEW.rowid;
                END""")

        for table in WORKSPACE_RESOURCE_TABLES:
            columns = {row["name"] for row in c.execute(f"PRAGMA table_info({table})")}
            if not columns:
                continue
            if "workspace_id" not in columns:
                c.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER REFERENCES workspaces(id)")
            c.execute(f"UPDATE {table} SET workspace_id=(SELECT w.id FROM resources r "
                      f"JOIN workspaces w ON w.owner_user_id=r.user_id WHERE r.id={table}.resource_id) "
                      "WHERE workspace_id IS NULL")
            c.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_workspace ON {table}(workspace_id)")
            c.execute(f"""CREATE TRIGGER IF NOT EXISTS trg_{table}_workspace_insert
                AFTER INSERT ON {table}
                WHEN NEW.workspace_id IS NULL
                BEGIN
                  UPDATE {table} SET workspace_id=(SELECT w.id FROM resources r
                    JOIN workspaces w ON w.owner_user_id=r.user_id WHERE r.id=NEW.resource_id)
                  WHERE rowid=NEW.rowid;
                END""")
        for table in ("community_merchants", "community_plans", "community_subscriptions",
                      "community_payments", "community_refunds", "community_ledger"):
            columns = {row["name"] for row in c.execute(f"PRAGMA table_info({table})")}
            if not columns:
                continue
            if table == "community_refunds" and "owner_user_id" not in columns:
                c.execute("ALTER TABLE community_refunds ADD COLUMN owner_user_id INTEGER NOT NULL DEFAULT 0")
                c.execute("UPDATE community_refunds SET owner_user_id=(SELECT owner_user_id FROM community_payments "
                          "WHERE community_payments.id=community_refunds.payment_id) WHERE owner_user_id=0")
            if "workspace_id" not in columns:
                c.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER REFERENCES workspaces(id)")
            c.execute(f"UPDATE {table} SET workspace_id=(SELECT id FROM workspaces "
                      f"WHERE owner_user_id={table}.owner_user_id) WHERE workspace_id IS NULL")
            c.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_workspace ON {table}(workspace_id)")

        for table in ("community_access_jobs", "community_subscription_notices"):
            columns = {row["name"] for row in c.execute(f"PRAGMA table_info({table})")}
            if not columns:
                continue
            if "workspace_id" not in columns:
                c.execute(f"ALTER TABLE {table} ADD COLUMN workspace_id INTEGER REFERENCES workspaces(id)")
            c.execute(f"UPDATE {table} SET workspace_id=(SELECT workspace_id FROM community_subscriptions "
                      f"WHERE community_subscriptions.id={table}.subscription_id) WHERE workspace_id IS NULL")
            c.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_workspace ON {table}(workspace_id)")


def ensure_workspace(user_id: int) -> int:
    """Return the user's personal workspace, creating it for newly authenticated users."""
    row = one("SELECT id FROM workspaces WHERE owner_user_id=?", user_id)
    if row:
        return int(row["id"])
    user = one("SELECT first_name FROM users WHERE id=?", user_id)
    if user is None:
        raise ValueError("workspace owner does not exist")
    created = now_iso()
    with tx():
        run("INSERT OR IGNORE INTO workspaces(name, owner_user_id, created_at, updated_at) VALUES(?,?,?,?)",
            user["first_name"].strip() or "Рабочее пространство", user_id, created, created)
        row = one("SELECT id FROM workspaces WHERE owner_user_id=?", user_id)
        run("INSERT OR IGNORE INTO workspace_members(workspace_id, user_id, role, joined_at) VALUES(?,?,?,?)",
            row["id"], user_id, "owner", created)
    return int(row["id"])


class tx:
    """with db.tx(): ...  -> BEGIN IMMEDIATE ... COMMIT / ROLLBACK."""

    def __enter__(self):
        conn().execute("BEGIN IMMEDIATE")

    def __exit__(self, exc_type, exc, tb):
        conn().execute("ROLLBACK" if exc_type else "COMMIT")
        return False


def q(sql: str, *args) -> list[sqlite3.Row]:
    return conn().execute(sql, args).fetchall()


def one(sql: str, *args):
    return conn().execute(sql, args).fetchone()


def run(sql: str, *args) -> sqlite3.Cursor:
    return conn().execute(sql, args)


def insert(table: str, **values) -> int:
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    cur = conn().execute(f"INSERT INTO {table}({cols}) VALUES({marks})", tuple(values.values()))
    return cur.lastrowid


def get_meta(key: str, default=None):
    row = one("SELECT value FROM meta WHERE key=?", key)
    return row["value"] if row else default


def set_meta(key: str, value) -> None:
    run("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", key, str(value))


def jl(value) -> list:
    return json.loads(value) if value else []


def event(user_id: int, kind: str, message: str, resource_id: int | None = None) -> None:
    insert("events", user_id=user_id, resource_id=resource_id, kind=kind, message=message, created_at=now_iso())


def audit(user_id, action: str, *, method: str = "", status: int = 0, resource_id=None, entity_id=None,
          ip: str = "", request_id: str = "", error: str = "", workspace_id: int | None = None) -> None:
    """Unified action journal. Never raises: a logging failure must not break the user's request.
    Stores only metadata (route, ids, status), never request bodies or message texts."""
    try:
        if user_id is not None and one("SELECT 1 FROM users WHERE id=?", user_id) is None:
            user_id = None  # e.g. the account was just deleted
        if user_id is None and not error:
            return
        insert("audit_log", user_id=user_id, action=action[:120], method=method, status=status,
               resource_id=resource_id, entity_id=entity_id, ip=ip[:64], request_id=request_id,
             error=error[:300], created_at=now_iso(), workspace_id=workspace_id)
    except Exception:  # noqa: BLE001
        import logging
        logging.getLogger("marketpilot.db").exception("audit write failed")


def purge_audit(days: int) -> int:
    cutoff = iso(now() - timedelta(days=days))
    return run("DELETE FROM audit_log WHERE created_at<?", cutoff).rowcount


def days_ago(n: int) -> datetime:
    return now() - timedelta(days=n)
