"""Telegram Bot API client (stdlib only) + rights evaluation.

Network errors are split in two: failures before the request reached Telegram (safe to retry) and
failures after it was sent (ambiguous: the message may be delivered -> do NOT auto-retry).
"""
import json
import socket
import threading
import time
import urllib.error
import urllib.request

from .config import cfg


class TelegramError(Exception):
    def __init__(self, code: int, description: str, retry_after: int | None = None):
        super().__init__(f"{code}: {description}")
        self.code, self.description, self.retry_after = code, description, retry_after

    @property
    def permanent(self) -> bool:
        return self.code in (400, 401, 403, 404)


class TelegramNetworkError(Exception):
    def __init__(self, message: str, ambiguous: bool):
        super().__init__(message)
        self.ambiguous = ambiguous


class RateLimiter:
    """Global rps + minimum interval per chat (single process)."""

    def __init__(self, rps: int, chat_interval: float):
        self.rps, self.chat_interval = rps, chat_interval
        self._start = time.monotonic()
        self._count = 0
        self._last: dict[int, float] = {}
        self._lock = threading.Lock()

    def acquire(self, chat_id: int) -> None:
        while True:
            with self._lock:
                now = time.monotonic()
                if now - self._start >= 1.0:
                    self._start, self._count = now, 0
                chat_wait = self._last.get(chat_id, 0) + self.chat_interval - now
                if self._count < self.rps and chat_wait <= 0:
                    self._count += 1
                    self._last[chat_id] = now
                    return
                wait = max(chat_wait, self._start + 1.0 - now, 0.01)
            time.sleep(wait)


class TelegramClient:
    def __init__(self, token: str, base: str):
        self.token, self.base = token, base
        self.limiter = RateLimiter(cfg.TG_GLOBAL_RPS, cfg.TG_CHAT_INTERVAL)

    def call(self, method: str, chat_id: int | None = None, http_timeout: float = 30, **params):
        if chat_id is not None:
            self.limiter.acquire(chat_id)
            params["chat_id"] = chat_id
        req = urllib.request.Request(
            f"{self.base}/bot{self.token}/{method}",
            data=json.dumps(params).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=http_timeout) as resp:
                data = json.loads(resp.read())
        except urllib.error.HTTPError as e:  # Telegram returns JSON bodies on 4xx
            try:
                data = json.loads(e.read())
            except Exception:
                raise TelegramError(e.code, str(e))
        except urllib.error.URLError as e:
            reason = e.reason
            before_send = isinstance(reason, (ConnectionRefusedError, socket.gaierror))
            raise TelegramNetworkError(f"{type(reason).__name__}: {reason}", ambiguous=not before_send)
        except (TimeoutError, socket.timeout, ConnectionError, OSError) as e:
            raise TelegramNetworkError(f"{type(e).__name__}: {e}", ambiguous=True)
        if not data.get("ok"):
            retry_after = (data.get("parameters") or {}).get("retry_after")
            raise TelegramError(data.get("error_code", 0), data.get("description", ""), retry_after)
        return data["result"]

    # helpers
    def get_me(self):
        return self.call("getMe", http_timeout=15)

    def send_message(self, chat_id, text, parse_mode="HTML", reply_markup=None):
        params = {"text": text}
        if parse_mode:
            params["parse_mode"] = parse_mode
        if reply_markup:
            params["reply_markup"] = reply_markup
        return self.call("sendMessage", chat_id, **params)

    def send_photo(self, chat_id, photo_url, caption="", parse_mode="HTML"):
        params = {"photo": photo_url}
        if caption:
            params["caption"] = caption
            if parse_mode:
                params["parse_mode"] = parse_mode
        return self.call("sendPhoto", chat_id, **params)

    def send_photo_file(self, chat_id, data: bytes, filename: str, mime: str, caption="", parse_mode="HTML"):
        boundary = "----MarketPilot" + str(int(time.time() * 1000000))
        safe_name = filename.encode("ascii", errors="ignore").decode() or "image"
        fields = {"chat_id": str(chat_id)}
        if caption:
            fields["caption"] = caption
            if parse_mode:
                fields["parse_mode"] = parse_mode
        chunks = []
        for key, value in fields.items():
            chunks.extend((f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n\r\n".encode(),
                           str(value).encode(), b"\r\n"))
        chunks.extend((f"--{boundary}\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"{safe_name}\"\r\n"
                       f"Content-Type: {mime}\r\n\r\n".encode(), data, f"\r\n--{boundary}--\r\n".encode()))
        body = b"".join(chunks)
        self.limiter.acquire(chat_id)
        req = urllib.request.Request(f"{self.base}/bot{self.token}/sendPhoto", data=body,
                                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            try:
                result = json.loads(e.read())
            except Exception:
                raise TelegramError(e.code, str(e))
        except urllib.error.URLError as e:
            reason = e.reason
            before_send = isinstance(reason, (ConnectionRefusedError, socket.gaierror))
            raise TelegramNetworkError(f"{type(reason).__name__}: {reason}", ambiguous=not before_send)
        except (TimeoutError, socket.timeout, ConnectionError, OSError) as e:
            raise TelegramNetworkError(f"{type(e).__name__}: {e}", ambiguous=True)
        if not result.get("ok"):
            retry_after = (result.get("parameters") or {}).get("retry_after")
            raise TelegramError(result.get("error_code", 0), result.get("description", ""), retry_after)
        return result["result"]

    def member_count(self, chat_id) -> int:
        return self.call("getChatMemberCount", chat_id, http_timeout=15)

    def get_chat(self, chat_id) -> dict:
        return self.call("getChat", chat_id, http_timeout=15)

    def chat_member(self, chat_id, user_id) -> dict:
        return self.call("getChatMember", chat_id, http_timeout=15, user_id=user_id)

    def create_chat_invite_link(self, chat_id, expire_date: int, member_limit: int = 1) -> str:
        result = self.call("createChatInviteLink", chat_id, http_timeout=15,
                           expire_date=expire_date, member_limit=member_limit)
        return result["invite_link"]

    def ban_chat_member(self, chat_id, user_id) -> None:
        self.call("banChatMember", chat_id, http_timeout=15, user_id=user_id)

    def unban_chat_member(self, chat_id, user_id) -> None:
        self.call("unbanChatMember", chat_id, http_timeout=15, user_id=user_id, only_if_banned=True)

    def restrict_chat_member(self, chat_id, user_id, permissions: dict) -> None:
        self.call("restrictChatMember", chat_id, http_timeout=15, user_id=user_id, permissions=permissions)

    def set_chat_permissions(self, chat_id, permissions: dict) -> None:
        self.call("setChatPermissions", chat_id, http_timeout=15,
                  permissions=permissions, use_independent_chat_permissions=True)


_client: TelegramClient | None = None


def client() -> TelegramClient | None:
    global _client
    if _client is None and cfg.BOT_TOKEN:
        _client = TelegramClient(cfg.BOT_TOKEN, cfg.TG_API_BASE)
    return _client


# live connection state shown in the UI (updated by bot.py)
state = {"connected": False, "username": "", "bot_id": None, "error": None}


def is_live() -> bool:
    return bool(state["connected"])


# ---------- rights ----------
FEATURE_RIGHTS = {
    "channel": {"publish": ["can_post_messages"], "edit_messages": ["can_edit_messages"],
                "delete_messages": ["can_delete_messages"]},
    "group": {"publish": [], "delete_messages": ["can_delete_messages"],
              "restrict_members": ["can_restrict_members"], "pin_messages": ["can_pin_messages"]},
}
FEATURE_RIGHTS["supergroup"] = FEATURE_RIGHTS["group"]

CHAT_PERMISSION_FIELDS = (
    "can_send_messages", "can_send_audios", "can_send_documents", "can_send_photos",
    "can_send_videos", "can_send_video_notes", "can_send_voice_notes", "can_send_polls",
    "can_send_other_messages", "can_add_web_page_previews", "can_change_info",
    "can_invite_users", "can_pin_messages", "can_manage_topics",
)


def evaluate_rights(resource_type: str, member: dict) -> tuple[list[str], list[str]]:
    """(capabilities, missing_rights) from the bot's own getChatMember result."""
    if member.get("status") != "administrator":
        return [], ["administrator"]
    caps, missing = [], set()
    for feature, needed in FEATURE_RIGHTS[resource_type].items():
        lacking = [r for r in needed if not member.get(r)]
        if lacking:
            missing.update(lacking)
        else:
            caps.append(feature)
    return caps, sorted(missing)
